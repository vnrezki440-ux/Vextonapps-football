import React, { useEffect, useState } from 'react';
import { AnimatedLoader } from './AnimatedLoader';
import { sound } from '../utils/audio';

interface SplashScreenProps {
  onFinish: () => void;
  autoSkip?: boolean;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onFinish, autoSkip = false }) => {
  const [progress, setProgress] = useState(0);
  const [statusText, setStatusText] = useState('Инициализация базы данных...');

  useEffect(() => {
    if (autoSkip) {
      onFinish();
      return;
    }

    // 3 seconds total splash (3000ms)
    const startTime = Date.now();
    const duration = 3000;

    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const currentPct = Math.min(100, Math.floor((elapsed / duration) * 100));
      setProgress(currentPct);

      if (currentPct < 30) {
        setStatusText('Загрузка профилей игроков...');
      } else if (currentPct < 65) {
        setStatusText('Расчёт тактических схем и сыгранности...');
      } else if (currentPct < 90) {
        setStatusText('Синхронизация локального хранилища...');
      } else {
        setStatusText('Готово к матчу!');
      }

      if (elapsed >= duration) {
        clearInterval(interval);
        sound.playWhistle();
        onFinish();
      }
    }, 40);

    return () => clearInterval(interval);
  }, [autoSkip, onFinish]);

  const handleSkip = () => {
    sound.playTap();
    onFinish();
  };

  return (
    <div
      data-testid="splash-screen"
      className="fixed inset-0 z-50 flex flex-col items-center justify-between bg-gradient-to-b from-[#050814] via-[#09112a] to-[#04060d] text-white p-6 select-none overflow-hidden"
    >
      {/* Background ambient neon glow spheres */}
      <div className="absolute top-1/4 -left-20 w-72 h-72 bg-cyan-500/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 -right-20 w-80 h-80 bg-blue-600/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Top Android App Indicator */}
      <div className="w-full max-w-sm flex justify-between items-center text-xs text-cyan-400/80 font-mono pt-2">
        <span className="flex items-center gap-1.5 tracking-wider">
          <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping inline-block" />
          VEXTON ENGINE v2.4
        </span>
        <button
          onClick={handleSkip}
          className="px-2.5 py-1 rounded-full bg-cyan-950/60 border border-cyan-500/30 text-cyan-300 text-[11px] hover:bg-cyan-900/50 transition-colors"
        >
          Пропустить ›
        </button>
      </div>

      {/* Center Branding & Mascot */}
      <div className="flex flex-col items-center text-center my-auto">
        {/* Animated Brand Emblem */}
        <div className="relative mb-6">
          <div className="w-28 h-28 rounded-2xl bg-gradient-to-tr from-cyan-600 via-blue-600 to-indigo-700 p-0.5 shadow-[0_0_40px_rgba(6,182,212,0.5)]">
            <div className="w-full h-full bg-[#080e22] rounded-2xl flex flex-col items-center justify-center relative overflow-hidden border border-cyan-400/30">
              {/* Tactical grid background inside icon */}
              <div
                className="absolute inset-0 opacity-20"
                style={{
                  backgroundImage:
                    'linear-gradient(rgba(6, 182, 212, 0.4) 1px, transparent 1px), linear-gradient(90deg, rgba(6, 182, 212, 0.4) 1px, transparent 1px)',
                  backgroundSize: '12px 12px',
                }}
              />
              <span className="text-4xl filter drop-shadow-[0_0_12px_rgba(6,182,212,0.8)]">⚽</span>
              <span className="text-[10px] tracking-widest font-black uppercase text-cyan-300 mt-1 font-mono">
                TACTICS
              </span>
            </div>
          </div>
          {/* Pulsing ring around badge */}
          <div className="absolute -inset-2 rounded-3xl border border-cyan-400/30 animate-pulse pointer-events-none" />
        </div>

        {/* Brand Name */}
        <h1 className="text-4xl font-extrabold tracking-wider font-heading uppercase text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-blue-200 to-cyan-400 drop-shadow-[0_0_20px_rgba(6,182,212,0.6)]">
          VextonApps
        </h1>
        <div className="mt-1 flex items-center gap-2">
          <div className="h-px w-6 bg-cyan-500/60" />
          <span className="text-xs font-semibold tracking-[0.3em] uppercase text-cyan-400">
            Футбольный Менеджер
          </span>
          <div className="h-px w-6 bg-cyan-500/60" />
        </div>
        <p className="mt-2 text-xs text-slate-400 max-w-xs">
          Создание, тактический анализ и управление идеальным составом вашей мечты
        </p>

        {/* Animated Loader Component */}
        <div className="mt-8">
          <AnimatedLoader size="md" accent="cyan" text="" />
        </div>
      </div>

      {/* Bottom Progress Bar & Timer */}
      <div className="w-full max-w-sm flex flex-col gap-2 pb-4">
        <div className="flex justify-between items-center text-xs font-mono text-slate-400">
          <span className="text-cyan-300/90 text-[11px] truncate">{statusText}</span>
          <span className="font-bold text-cyan-400">{progress}%</span>
        </div>

        {/* Progress Bar with glowing neon cap */}
        <div className="relative w-full h-2 bg-slate-900 rounded-full overflow-hidden border border-cyan-900/50">
          <div
            className="h-full bg-gradient-to-r from-blue-600 via-cyan-400 to-emerald-400 transition-all duration-75 ease-out rounded-full shadow-[0_0_12px_rgba(6,182,212,0.8)]"
            style={{ width: `${progress}%` }}
          />
        </div>

        <div className="flex justify-between items-center text-[10px] text-slate-500 pt-1">
          <span>Локальное хранилище данных</span>
          <span>© 2026 VextonApps</span>
        </div>
      </div>
    </div>
  );
};
