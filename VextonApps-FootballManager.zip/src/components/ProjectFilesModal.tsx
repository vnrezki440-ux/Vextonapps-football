import React, { useState } from 'react';
import { PROJECT_CATALOG, ProjectFileEntry } from '../utils/projectFilesCatalog';
import { downloadFullZipBlob, downloadFileBlob, PROJECT_ZIP_SIZE_MB } from '../utils/projectZipData';
import { sound } from '../utils/audio';
import {
  X,
  Download,
  FileCode,
  Copy,
  Check,
  Search,
  FolderArchive,
  Layers,
  ChevronDown,
  ChevronUp,
  FileText,
  Shield,
  Smartphone,
  ExternalLink,
} from 'lucide-react';

interface ProjectFilesModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ProjectFilesModal: React.FC<ProjectFilesModalProps> = ({ isOpen, onClose }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [expandedFile, setExpandedFile] = useState<string | null>(null);
  const [copiedPath, setCopiedPath] = useState<string | null>(null);
  const [downloadSuccessToast, setDownloadSuccessToast] = useState<string | null>(null);

  if (!isOpen) return null;

  const filteredFiles = PROJECT_CATALOG.filter((f) => {
    const matchesSearch =
      f.path.toLowerCase().includes(searchQuery.toLowerCase()) ||
      f.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      f.filename.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCategory = selectedCategory === 'all' || f.category === selectedCategory;

    return matchesSearch && matchesCategory;
  });

  const handleDownloadFullZip = () => {
    sound.playSuccess();
    downloadFullZipBlob('VextonApps-FootballManager.zip');
    showDownloadToast('Архив VextonApps-FootballManager.zip сформирован и сохранён!');
  };

  const handleDownloadSingleFile = (file: ProjectFileEntry) => {
    sound.playTap();
    downloadFileBlob(file.filename, file.content, file.mimeType);
    showDownloadToast(`Файл ${file.filename} скачан!`);
  };

  const handleCopyCode = async (file: ProjectFileEntry) => {
    try {
      await navigator.clipboard.writeText(file.content);
      sound.playSuccess();
      setCopiedPath(file.path);
      setTimeout(() => setCopiedPath(null), 2200);
    } catch {
      // fallback
    }
  };

  const showDownloadToast = (msg: string) => {
    setDownloadSuccessToast(msg);
    setTimeout(() => setDownloadSuccessToast(null), 2500);
  };

  const getCategoryBadge = (cat: ProjectFileEntry['category']) => {
    switch (cat) {
      case 'android':
        return { label: 'Android', color: 'bg-emerald-950 text-emerald-300 border-emerald-500/40' };
      case 'config':
        return { label: 'Конфиг', color: 'bg-blue-950 text-blue-300 border-blue-500/40' };
      case 'src':
        return { label: 'React Core', color: 'bg-cyan-950 text-cyan-300 border-cyan-500/40' };
      case 'components':
        return { label: 'Компонент', color: 'bg-purple-950 text-purple-300 border-purple-500/40' };
      case 'docs':
        return { label: 'Документ', color: 'bg-amber-950 text-amber-300 border-amber-500/40' };
      default:
        return { label: 'Файл', color: 'bg-slate-900 text-slate-300 border-slate-700' };
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-150 overflow-y-auto"
      onClick={onClose}
      data-testid="project-files-modal"
    >
      <div
        className="relative w-full max-w-lg rounded-3xl bg-gradient-to-b from-[#0a142e] via-[#070e24] to-[#040816] border-2 border-cyan-500/50 p-4 sm:p-5 shadow-[0_0_45px_rgba(6,182,212,0.4)] text-white my-auto max-h-[94vh] flex flex-col overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-slate-700/60 pb-3 flex-shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-cyan-500/20 border border-cyan-400/50 flex items-center justify-center text-cyan-300 shadow-[0_0_12px_rgba(6,182,212,0.3)]">
              <FolderArchive className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-black font-heading uppercase text-white tracking-wide">
                Центр экспорта файлов и ZIP
              </h3>
              <p className="text-[11px] text-cyan-400/90 font-mono">
                Прямая выгрузка из памяти устройства (без Cookie check)
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playTap();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-300 transition-colors"
            aria-label="Закрыть"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Modal Content */}
        <div className="flex-1 overflow-y-auto no-scrollbar py-3 flex flex-col gap-3.5">
          {/* Main One-Click ZIP Download Hero Card */}
          <div className="rounded-2xl p-4 bg-gradient-to-r from-blue-950/90 via-slate-900 to-cyan-950/90 border-2 border-cyan-400 shadow-[0_0_25px_rgba(6,182,212,0.3)] relative overflow-hidden">
            <div className="flex items-start justify-between mb-2">
              <div>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-400 text-[10px] font-mono font-bold text-emerald-300">
                  Рекомендуемый способ
                </span>
                <h4 className="text-base font-black font-heading text-white mt-1 uppercase">
                  Скачать весь проект одним ZIP
                </h4>
                <p className="text-xs text-slate-300 mt-0.5">
                  Полный архив исходного кода ({PROJECT_ZIP_SIZE_MB}), готовый к сборке в APK.
                </p>
              </div>

              <div className="w-11 h-11 rounded-xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-cyan-300 flex-shrink-0">
                <FolderArchive className="w-6 h-6" />
              </div>
            </div>

            <div className="text-[11px] text-cyan-300/90 font-mono bg-black/40 p-2 rounded-xl mb-3 border border-cyan-500/20">
              ⚡ <b>Прямой Blob-экспорт</b>: генерируется мгновенно в браузере без HTTP-запросов к серверу — исключает ошибку «Cookie check» и страницу входа Google.
            </div>

            <button
              onClick={handleDownloadFullZip}
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-cyan-400 via-teal-400 to-emerald-400 hover:from-cyan-300 hover:to-emerald-300 text-slate-950 font-black text-xs sm:text-sm font-mono flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(6,182,212,0.5)] active:scale-95 transition-all cursor-pointer"
            >
              <Download className="w-4 h-4 text-slate-950" />
              <span>СКАЧАТЬ ВЕСЬ ПРОЕКТ (ZIP-АРХИВ)</span>
            </button>
          </div>

          {/* Section: Individual File Downloader */}
          <div className="flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-mono font-bold uppercase tracking-wider text-slate-200 block">
                  Скачать файлы по отдельности
                </span>
                <span className="text-[10px] text-slate-400 font-mono">
                  Выберите любой файл для скачивания или копирования кода
                </span>
              </div>
              <span className="px-2 py-0.5 rounded-lg bg-slate-900 border border-slate-700 text-[10px] font-mono text-cyan-400">
                {filteredFiles.length} из {PROJECT_CATALOG.length}
              </span>
            </div>

            {/* Search Input */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-cyan-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Поиск файла (например: AndroidManifest, package.json)..."
                className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-900/90 border border-slate-700 focus:border-cyan-400 text-xs text-white placeholder:text-slate-500 outline-none transition-all font-mono"
              />
            </div>

            {/* Category Filter Chips */}
            <div className="flex gap-1.5 overflow-x-auto pb-1 no-scrollbar">
              {[
                { key: 'all', label: 'Все файлы' },
                { key: 'android', label: '🤖 Android' },
                { key: 'config', label: '⚙️ Конфигурация' },
                { key: 'src', label: '⚛️ React Core' },
                { key: 'components', label: '🧩 Компоненты' },
                { key: 'docs', label: '📄 Документация' },
              ].map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => {
                    sound.playTap();
                    setSelectedCategory(tab.key);
                  }}
                  className={`px-2.5 py-1 rounded-xl text-[11px] font-mono font-bold transition-all flex-shrink-0 ${
                    selectedCategory === tab.key
                      ? 'bg-cyan-500 text-slate-950 shadow-[0_0_10px_rgba(6,182,212,0.5)]'
                      : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-slate-200'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* File List */}
            <div className="flex flex-col gap-2 max-h-72 overflow-y-auto no-scrollbar pt-1">
              {filteredFiles.map((file) => {
                const isExpanded = expandedFile === file.path;
                const isCopied = copiedPath === file.path;
                const badge = getCategoryBadge(file.category);

                return (
                  <div
                    key={file.path}
                    className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-cyan-500/40 transition-all flex flex-col gap-2"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className={`px-1.5 py-0.5 rounded text-[9px] font-mono font-bold border ${badge.color}`}>
                            {badge.label}
                          </span>
                          <span className="font-mono text-xs font-black text-cyan-300 truncate">
                            {file.filename}
                          </span>
                          <span className="text-[10px] text-slate-500 font-mono">
                            ({(file.size / 1024).toFixed(1)} КБ)
                          </span>
                        </div>
                        <span className="text-[11px] text-slate-400 block truncate mt-0.5">
                          {file.description}
                        </span>
                        <span className="text-[9px] text-slate-600 font-mono block truncate">
                          {file.path}
                        </span>
                      </div>

                      {/* Quick Action Buttons */}
                      <div className="flex items-center gap-1.5 flex-shrink-0">
                        {/* Download Single File */}
                        <button
                          onClick={() => handleDownloadSingleFile(file)}
                          className="px-2.5 py-1.5 rounded-xl bg-cyan-600/30 hover:bg-cyan-600/50 text-cyan-300 border border-cyan-400/40 text-[11px] font-mono font-bold flex items-center gap-1 active:scale-95 transition-all"
                          title="Скачать этот файл"
                        >
                          <Download className="w-3.5 h-3.5" />
                          <span className="hidden sm:inline">Скачать</span>
                        </button>

                        {/* Copy Code */}
                        <button
                          onClick={() => handleCopyCode(file)}
                          className={`p-1.5 rounded-xl border text-[11px] font-mono transition-all ${
                            isCopied
                              ? 'bg-emerald-500/30 text-emerald-300 border-emerald-400'
                              : 'bg-slate-800 text-slate-300 border-slate-700 hover:text-white'
                          }`}
                          title="Скопировать код в буфер"
                        >
                          {isCopied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                        </button>

                        {/* Expand / View Code */}
                        <button
                          onClick={() => {
                            sound.playTap();
                            setExpandedFile(isExpanded ? null : file.path);
                          }}
                          className="p-1.5 rounded-xl bg-slate-800 text-slate-400 border border-slate-700 hover:text-slate-200"
                          title="Просмотреть код"
                        >
                          {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </div>

                    {/* Collapsible Code Viewer */}
                    {isExpanded && (
                      <div className="mt-1 pt-2 border-t border-slate-800/80 animate-in fade-in duration-150">
                        <div className="flex items-center justify-between text-[10px] font-mono text-slate-400 mb-1">
                          <span>Предварительный просмотр содержимого:</span>
                          <button
                            onClick={() => handleCopyCode(file)}
                            className="text-cyan-400 hover:underline flex items-center gap-0.5"
                          >
                            <Copy className="w-2.5 h-2.5" /> Скопировать весь текст
                          </button>
                        </div>
                        <pre className="p-2.5 rounded-xl bg-black/80 border border-slate-800 text-[10px] font-mono text-emerald-400 overflow-x-auto max-h-48 whitespace-pre leading-relaxed select-text">
                          {file.content}
                        </pre>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="pt-3 border-t border-slate-800 flex items-center justify-between flex-shrink-0 text-[11px] font-mono text-slate-400">
          <span className="truncate">VextonApps • Офлайн-исходники для Capacitor APK</span>
          <button
            onClick={() => {
              sound.playTap();
              onClose();
            }}
            className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold transition-colors"
          >
            Закрыть
          </button>
        </div>

        {/* Global Toast within modal */}
        {downloadSuccessToast && (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 z-50 px-3.5 py-1.5 rounded-xl bg-emerald-950/95 border border-emerald-400 text-emerald-300 font-mono text-xs font-bold shadow-[0_0_15px_rgba(16,185,129,0.5)] animate-in fade-in slide-in-from-top-2">
            ✓ {downloadSuccessToast}
          </div>
        )}
      </div>
    </div>
  );
};
