import React, { useState, useEffect } from 'react';
import {
  ArrowLeft,
  Volume2,
  VolumeX,
  Settings,
  Shield,
  Wifi,
  Battery,
  Sparkles,
} from 'lucide-react';
import { AppView, ThemeAccent } from '../types/football';
import { sound } from '../utils/audio';

interface HeaderNavProps {
  currentView: AppView;
  onNavigate: (view: AppView) => void;
  accent: ThemeAccent;
  soundEnabled: boolean;
  onToggleSound: () => void;
  teamName: string;
}

export const HeaderNav: React.FC<HeaderNavProps> = ({
  currentView,
  onNavigate,
  accent,
  soundEnabled,
  onToggleSound,
  teamName,
}) => {
  const [currentTime, setCurrentTime] = useState('12:00');

  useEffect(() => {
    const update = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })
      );
    };
    update();
    const interval = setInterval(update, 30000);
    return () => clearInterval(interval);
  }, []);

  const getScreenTitle = (view: AppView) => {
    switch (view) {
      case 'menu':
        return 'Главное меню';
      case 'pitch':
        return 'Тактическое поле';
      case 'data':
        return 'База данных состава';
      case 'editor':
        return 'Редактирование';
      case 'settings':
        return 'Настройки';
      case 'support':
        return 'Поддержка';
      case 'report':
        return 'Сообщить о пользователе';
      default:
        return 'VextonApps';
    }
  };

  const accentBorder = {
    cyan: 'border-cyan-500/30',
    emerald: 'border-emerald-500/30',
    purple: 'border-purple-500/30',
    amber: 'border-amber-500/30',
  }[accent];

  const accentText = {
    cyan: 'text-cyan-400',
    emerald: 'text-emerald-400',
    purple: 'text-purple-400',
    amber: 'text-amber-400',
  }[accent];

  return (
    <header className="sticky top-0 z-40 bg-[#070b19]/90 backdrop-blur-md border-b border-slate-800/80 w-full select-none">
      {/* Android Top System Bar */}
      <div className="flex items-center justify-between px-4 py-1 text-[11px] font-mono text-slate-400 border-b border-white/5">
        <div className="flex items-center gap-1 font-semibold text-slate-300">
          <span>{currentTime}</span>
          <span className="text-[9px] text-cyan-400 ml-1">● 5G</span>
        </div>
        <div className="flex items-center gap-2">
          <Wifi className="w-3.5 h-3.5 text-slate-400" />
          <div className="flex items-center gap-0.5">
            <span className="text-[10px]">100%</span>
            <Battery className="w-3.5 h-3.5 text-emerald-400" />
          </div>
        </div>
      </div>

      {/* Main Nav Bar */}
      <div className="flex items-center justify-between px-3 py-2.5">
        <div className="flex items-center gap-2">
          {currentView !== 'menu' ? (
            <button
              onClick={() => {
                sound.playTap();
                onNavigate('menu');
              }}
              className="flex items-center justify-center w-8 h-8 rounded-lg bg-slate-800/80 hover:bg-slate-700/80 text-cyan-400 border border-slate-700/60 active:scale-95 transition-transform"
              aria-label="Вернуться в главное меню"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
          ) : (
            <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-600 to-blue-700 text-white shadow-[0_0_12px_rgba(6,182,212,0.4)]">
              <Shield className="w-4 h-4" />
            </div>
          )}

          <div className="flex flex-col">
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-black uppercase tracking-wider text-slate-100 font-heading">
                VextonApps
              </span>
              <span className={`text-[10px] font-mono font-semibold px-1.5 py-0.2 rounded bg-slate-800/80 border ${accentBorder} ${accentText}`}>
                {teamName}
              </span>
            </div>
            <span className="text-[11px] font-medium text-slate-400 leading-tight">
              {getScreenTitle(currentView)}
            </span>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => {
              onToggleSound();
              sound.playTap();
            }}
            className="w-8 h-8 flex items-center justify-center rounded-lg bg-slate-800/60 hover:bg-slate-700/60 text-slate-300 border border-slate-700/40 active:scale-95 transition-transform"
            aria-label={soundEnabled ? 'Выключить звук' : 'Включить звук'}
          >
            {soundEnabled ? (
              <Volume2 className="w-4 h-4 text-cyan-400" />
            ) : (
              <VolumeX className="w-4 h-4 text-slate-500" />
            )}
          </button>

          {currentView !== 'settings' && (
            <button
              onClick={() => {
                sound.playTap();
                onNavigate('settings');
              }}
              className="w-8 h-8 flex items-center justify-center rounded-lg bg-slate-800/60 hover:bg-slate-700/60 text-slate-300 border border-slate-700/40 active:scale-95 transition-transform"
              aria-label="Открыть настройки"
            >
              <Settings className="w-4 h-4 text-slate-300" />
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
