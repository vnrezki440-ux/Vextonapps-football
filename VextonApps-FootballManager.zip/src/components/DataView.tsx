import React, { useState } from 'react';
import { Player, PositionCategory } from '../types/football';
import {
  POSITION_CATEGORIES,
  calculateSquadStats,
  calculateAverageRating,
  getStarters,
  getBenchPlayers,
  resetSquadToDefault,
} from '../utils/squadUtils';
import {
  Search,
  Plus,
  Edit2,
  Trash2,
  Download,
  Upload,
  RotateCcw,
  Users,
  Shield,
  Zap,
  Check,
  Copy,
  SlidersHorizontal,
  FolderArchive,
  FileCode,
} from 'lucide-react';
import { sound } from '../utils/audio';
import { downloadFullZipBlob } from '../utils/projectZipData';

interface DataViewProps {
  players: Player[];
  onSelectPlayer: (player: Player) => void;
  onEditPlayer: (player: Player) => void;
  onDeletePlayer: (id: string) => void;
  onAddNewPlayer: () => void;
  onImportSquad: (players: Player[]) => void;
  onResetSquad: () => void;
  onOpenFilesModal?: () => void;
}

export const DataView: React.FC<DataViewProps> = ({
  players,
  onSelectPlayer,
  onEditPlayer,
  onDeletePlayer,
  onAddNewPlayer,
  onImportSquad,
  onResetSquad,
  onOpenFilesModal,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [sortBy, setSortBy] = useState<'rating' | 'number' | 'name'>('rating');
  const [showJsonModal, setShowJsonModal] = useState(false);
  const [jsonText, setJsonText] = useState('');
  const [copySuccess, setCopySuccess] = useState(false);
  const [importError, setImportError] = useState('');
  const [confirmReset, setConfirmReset] = useState(false);

  const teamStats = calculateSquadStats(players);
  const avgOvr = calculateAverageRating(players);
  const starters = getStarters(players);
  const bench = getBenchPlayers(players);

  // Filter players
  const filteredPlayers = players
    .filter((p) => {
      const matchesSearch =
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.surname.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.number.toString().includes(searchQuery) ||
        p.position.toLowerCase().includes(searchQuery.toLowerCase());

      if (!matchesSearch) return false;

      if (selectedCategory === 'ALL') return true;
      if (selectedCategory === 'STARTERS') return p.isStarter;
      if (selectedCategory === 'BENCH') return !p.isStarter;

      return POSITION_CATEGORIES[p.position] === selectedCategory;
    })
    .sort((a, b) => {
      if (sortBy === 'rating') return b.rating - a.rating;
      if (sortBy === 'number') return a.number - b.number;
      return a.surname.localeCompare(b.surname);
    });

  const handleExportJson = () => {
    sound.playTap();
    const str = JSON.stringify(players, null, 2);
    setJsonText(str);
    setShowJsonModal(true);
  };

  const handleCopyClipboard = async () => {
    try {
      await navigator.clipboard.writeText(jsonText);
      setCopySuccess(true);
      sound.playSuccess();
      setTimeout(() => setCopySuccess(false), 2000);
    } catch {
      // fallback
    }
  };

  const handleApplyImport = () => {
    try {
      const parsed = JSON.parse(jsonText);
      if (Array.isArray(parsed) && parsed.length > 0) {
        onImportSquad(parsed);
        sound.playSuccess();
        setShowJsonModal(false);
        setImportError('');
      } else {
        setImportError('Некорректный формат JSON (ожидался массив игроков)');
      }
    } catch (err) {
      setImportError('Ошибка парсинга JSON: проверьте синтаксис');
    }
  };

  return (
    <div className="w-full max-w-md mx-auto px-3 py-3 pb-24 select-none" data-testid="data-view">
      {/* Top Analytics Summary */}
      <div className="glass-panel rounded-2xl p-4 border border-emerald-500/30 mb-4 shadow-[0_0_20px_rgba(16,185,129,0.15)]">
        <div className="flex items-center justify-between mb-3 border-b border-slate-700/60 pb-2">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-300">
              <Users className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white font-heading uppercase">
                Аналитика состава
              </h3>
              <span className="text-[10px] text-slate-400 font-mono">
                {players.length} игроков • {starters.length} в основе • {bench.length} на банке
              </span>
            </div>
          </div>
          <div className="text-right">
            <span className="text-[10px] font-mono text-slate-400 uppercase block">Ср. рейтинг</span>
            <span className="text-lg font-black text-amber-300 font-mono-stat">{avgOvr} OVR</span>
          </div>
        </div>

        {/* 6 stats summary pills */}
        <div className="grid grid-cols-6 gap-1 text-center font-mono">
          <div className="p-1.5 rounded-lg bg-slate-900/80 border border-slate-800">
            <span className="text-[9px] text-slate-400 block">PAC</span>
            <span className="text-xs font-bold text-amber-300">{teamStats.pace}</span>
          </div>
          <div className="p-1.5 rounded-lg bg-slate-900/80 border border-slate-800">
            <span className="text-[9px] text-slate-400 block">SHO</span>
            <span className="text-xs font-bold text-red-400">{teamStats.shooting}</span>
          </div>
          <div className="p-1.5 rounded-lg bg-slate-900/80 border border-slate-800">
            <span className="text-[9px] text-slate-400 block">PAS</span>
            <span className="text-xs font-bold text-blue-400">{teamStats.passing}</span>
          </div>
          <div className="p-1.5 rounded-lg bg-slate-900/80 border border-slate-800">
            <span className="text-[9px] text-slate-400 block">DRI</span>
            <span className="text-xs font-bold text-emerald-400">{teamStats.dribbling}</span>
          </div>
          <div className="p-1.5 rounded-lg bg-slate-900/80 border border-slate-800">
            <span className="text-[9px] text-slate-400 block">DEF</span>
            <span className="text-xs font-bold text-indigo-400">{teamStats.defending}</span>
          </div>
          <div className="p-1.5 rounded-lg bg-slate-900/80 border border-slate-800">
            <span className="text-[9px] text-slate-400 block">PHY</span>
            <span className="text-xs font-bold text-orange-400">{teamStats.physical}</span>
          </div>
        </div>
      </div>

      {/* Download ZIP Archive Banner */}
      <div className="rounded-2xl p-3.5 bg-gradient-to-r from-blue-950/90 via-slate-900 to-cyan-950/80 border-2 border-cyan-400/60 shadow-[0_0_20px_rgba(6,182,212,0.25)] mb-3">
        <div className="flex items-center justify-between mb-1.5">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-cyan-300">
              <FolderArchive className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-black font-heading text-white uppercase tracking-wide">
                Исходный код проекта (ZIP и файлы)
              </h4>
              <p className="text-[10px] text-cyan-400/90 font-mono">
                Для сборки APK на Android • Прямой Blob-экспорт
              </p>
            </div>
          </div>
          <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-400 text-[9px] font-mono font-bold text-emerald-300">
            Без Cookie check
          </span>
        </div>

        <p className="text-[11px] text-slate-300 mb-2.5 leading-tight">
          Скачайте весь проект одним архивом или скачайте любой файл отдельно (<span className="text-cyan-300 font-mono">AndroidManifest.xml</span>, <span className="text-cyan-300 font-mono">package.json</span>, <span className="text-cyan-300 font-mono">App.tsx</span>).
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          <button
            onClick={() => {
              sound.playSuccess();
              downloadFullZipBlob();
            }}
            className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-cyan-400 via-teal-400 to-emerald-400 hover:from-cyan-300 hover:to-emerald-300 text-slate-950 font-black text-xs font-mono flex items-center justify-center gap-1.5 shadow-[0_0_15px_rgba(6,182,212,0.4)] active:scale-95 transition-all cursor-pointer"
          >
            <Download className="w-4 h-4 text-slate-950" />
            <span>Скачать весь ZIP (0.47 MB)</span>
          </button>

          <button
            onClick={() => {
              sound.playTap();
              onOpenFilesModal?.();
            }}
            className="w-full py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-cyan-500/40 font-black text-xs font-mono flex items-center justify-center gap-1.5 active:scale-95 transition-all cursor-pointer"
          >
            <FileCode className="w-4 h-4 text-cyan-400" />
            <span>Файлы по отдельности</span>
          </button>
        </div>
      </div>

      {/* Action Row: Add Player & Import/Export */}
      <div className="flex items-center gap-2 mb-3">
        <button
          onClick={() => {
            sound.playTap();
            onAddNewPlayer();
          }}
          className="flex-1 py-2 px-3 rounded-xl bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 text-white text-xs font-bold font-mono flex items-center justify-center gap-1.5 shadow-[0_0_12px_rgba(16,185,129,0.3)] active:scale-95 transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>Добавить игрока</span>
        </button>

        <button
          onClick={handleExportJson}
          className="py-2 px-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 border border-slate-700 text-xs font-bold flex items-center gap-1 active:scale-95 transition-all"
          title="Экспорт / Импорт JSON"
        >
          <Download className="w-3.5 h-3.5 text-cyan-400" />
          <span className="text-[11px] font-mono">JSON</span>
        </button>

        {confirmReset ? (
          <button
            onClick={() => {
              sound.playWhistle();
              onResetSquad();
              setConfirmReset(false);
            }}
            className="py-2 px-2.5 rounded-xl bg-red-600 text-white text-xs font-bold font-mono active:scale-95 transition-all animate-pulse"
          >
            Сбросить?
          </button>
        ) : (
          <button
            onClick={() => {
              sound.playTap();
              setConfirmReset(true);
              setTimeout(() => setConfirmReset(false), 4000);
            }}
            className="py-2 px-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-400 border border-slate-700 text-xs active:scale-95 transition-all"
            title="Сбросить к исходному составу"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* Search Input */}
      <div className="relative mb-2.5">
        <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Поиск по имени, номеру (#) или позиции..."
          className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-900/80 border border-slate-700 focus:border-emerald-400 text-xs text-white outline-none font-medium transition-colors"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white text-xs"
          >
            ✕
          </button>
        )}
      </div>

      {/* Category Filter Tabs */}
      <div className="flex gap-1.5 overflow-x-auto pb-1 no-scrollbar mb-2.5 text-xs font-mono font-bold">
        {[
          { key: 'ALL', label: 'Все' },
          { key: 'STARTERS', label: 'Основа' },
          { key: 'BENCH', label: 'Запас' },
          { key: 'GK', label: 'ВРТ' },
          { key: 'DEF', label: 'ЗАЩ' },
          { key: 'MID', label: 'ПОЛ' },
          { key: 'ATT', label: 'НАП' },
        ].map((tab) => (
          <button
            key={tab.key}
            onClick={() => {
              sound.playTap();
              setSelectedCategory(tab.key);
            }}
            className={`px-2.5 py-1 rounded-lg flex-shrink-0 transition-colors ${
              selectedCategory === tab.key
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/40 shadow-sm'
                : 'bg-slate-900/60 text-slate-400 border border-slate-800 hover:text-slate-300'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Sorting bar */}
      <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 mb-2 px-1">
        <span>Найдено: {filteredPlayers.length}</span>
        <div className="flex items-center gap-1.5">
          <span>Сорт:</span>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as 'rating' | 'number' | 'name')}
            className="bg-slate-900 border border-slate-700 rounded-md px-1.5 py-0.5 text-slate-300 text-[11px] outline-none"
          >
            <option value="rating">Рейтинг (OVR)</option>
            <option value="number">Номер (#)</option>
            <option value="name">Фамилия (А-Я)</option>
          </select>
        </div>
      </div>

      {/* Players List Cards */}
      <div className="flex flex-col gap-2">
        {filteredPlayers.map((player) => (
          <div
            key={player.id}
            onClick={() => onSelectPlayer(player)}
            className="group glass-panel rounded-xl p-2.5 border border-slate-800 hover:border-emerald-500/40 flex items-center justify-between gap-2 cursor-pointer active:scale-[0.99] transition-all"
            role="button"
            tabIndex={0}
            aria-label={`${player.name} ${player.surname}, ${player.position}, rating ${player.rating}`}
          >
            {/* Left: OVR, Number & Flag */}
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-slate-800 to-slate-900 border border-slate-700 flex flex-col items-center justify-center p-0.5">
                <span className="text-xs font-mono font-black text-amber-300 leading-tight">
                  {player.rating}
                </span>
                <span className="text-[8px] font-mono font-bold text-cyan-300 uppercase leading-none">
                  {player.position}
                </span>
              </div>

              <div className="flex flex-col">
                <div className="flex items-center gap-1.5 text-xs text-slate-300">
                  <span>{player.flag}</span>
                  <span className="font-bold text-white group-hover:text-emerald-300 transition-colors">
                    {player.name} {player.surname}
                  </span>
                  {player.isCaptain && (
                    <span className="text-[9px] font-black bg-amber-500 text-black px-1 rounded-sm">
                      C
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-2 text-[10px] text-slate-400 font-mono mt-0.5">
                  <span className="text-cyan-400">#{player.number}</span>
                  <span>•</span>
                  <span>{player.isStarter ? 'Основа' : 'Запас'}</span>
                  <span>•</span>
                  <span>PAC {player.pace} / DEF {player.defending}</span>
                </div>
              </div>
            </div>

            {/* Right: Quick Edit & Delete */}
            <div className="flex items-center gap-1">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  sound.playTap();
                  onEditPlayer(player);
                }}
                className="w-7 h-7 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-cyan-300 flex items-center justify-center transition-colors"
                title="Редактировать"
              >
                <Edit2 className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  sound.playWhistle();
                  onDeletePlayer(player.id);
                }}
                className="w-7 h-7 rounded-lg bg-slate-800/80 hover:bg-red-900/60 text-slate-400 hover:text-red-300 flex items-center justify-center transition-colors"
                title="Удалить игрока"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}

        {filteredPlayers.length === 0 && (
          <div className="glass-panel rounded-2xl p-6 text-center text-slate-400 text-xs">
            Игроки не найдены по запросу «{searchQuery}».
          </div>
        )}
      </div>

      {/* JSON Import/Export Modal */}
      {showJsonModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-md animate-in fade-in"
          onClick={() => setShowJsonModal(false)}
        >
          <div
            className="w-full max-w-md rounded-2xl bg-[#09122a] border border-cyan-500/40 p-4 text-white shadow-2xl flex flex-col gap-3"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-slate-700 pb-2">
              <h3 className="text-sm font-bold font-heading uppercase text-cyan-300">
                Экспорт / Импорт состава JSON
              </h3>
              <button
                onClick={() => setShowJsonModal(false)}
                className="text-slate-400 hover:text-white text-xs"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-400">
              Вы можете скопировать текущий состав или вставить собственный JSON для импорта.
            </p>

            <textarea
              value={jsonText}
              onChange={(e) => setJsonText(e.target.value)}
              rows={8}
              className="w-full p-2.5 rounded-xl bg-slate-950 font-mono text-[11px] text-cyan-300 border border-slate-700 focus:border-cyan-400 outline-none select-text"
            />

            {importError && (
              <span className="text-xs text-red-400">{importError}</span>
            )}

            <div className="flex items-center justify-between pt-1">
              <button
                onClick={handleCopyClipboard}
                className="py-1.5 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-mono flex items-center gap-1.5 text-slate-200"
              >
                {copySuccess ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copySuccess ? 'Скопировано!' : 'Копировать'}</span>
              </button>

              <button
                onClick={handleApplyImport}
                className="py-1.5 px-3 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-mono font-bold flex items-center gap-1.5 shadow-[0_0_10px_rgba(16,185,129,0.4)]"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Импортировать в базу</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
