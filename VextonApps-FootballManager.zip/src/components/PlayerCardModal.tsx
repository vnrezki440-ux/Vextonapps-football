import React, { useState } from 'react';
import { Player } from '../types/football';
import {
  PES_CATEGORIES,
  getPesRatingColor,
  getOrGeneratePesStats,
} from '../utils/squadUtils';
import {
  X,
  Edit2,
  Trash2,
  Crown,
  ArrowLeftRight,
  Shield,
  Check,
  User,
  Sparkles,
} from 'lucide-react';
import { sound } from '../utils/audio';

interface PlayerCardModalProps {
  player: Player | null;
  onClose: () => void;
  onEdit: (player: Player) => void;
  onDelete: (id: string) => void;
  onToggleCaptain: (id: string) => void;
  onToggleStarter: (id: string) => void;
  photoUrl?: string | null;
}

export const PlayerCardModal: React.FC<PlayerCardModalProps> = ({
  player,
  onClose,
  onEdit,
  onDelete,
  onToggleCaptain,
  onToggleStarter,
  photoUrl,
}) => {
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>(PES_CATEGORIES[0].title);

  if (!player) return null;

  const pes = getOrGeneratePesStats(player);
  const ratingColor = getPesRatingColor(player.rating);
  const photo = photoUrl || player.photoUrl;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-md animate-in fade-in duration-200 overflow-y-auto"
      onClick={onClose}
      data-testid="player-card-modal"
    >
      <div
        className="relative w-full max-w-md rounded-3xl bg-gradient-to-b from-[#0c1836] via-[#09112a] to-[#050814] border-2 border-cyan-500/40 p-4 sm:p-5 shadow-[0_0_40px_rgba(6,182,212,0.35)] text-white overflow-hidden my-auto max-h-[94vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Glow ambient */}
        <div className="absolute top-0 right-0 w-44 h-44 bg-cyan-500/15 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-44 h-44 bg-indigo-600/15 rounded-full blur-2xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={() => {
            sound.playTap();
            onClose();
          }}
          className="absolute top-4 right-4 w-8 h-8 rounded-full bg-slate-800/80 hover:bg-slate-700/80 border border-white/10 flex items-center justify-center text-slate-300 active:scale-95 transition-all z-20"
          aria-label="Закрыть"
        >
          <X className="w-4 h-4" />
        </button>

        {/* PES Card Header: Large Rating + Photo + Name */}
        <div className="relative z-10 border-b border-slate-700/60 pb-3 flex items-start gap-3.5">
          {/* Photo Frame */}
          <div className="relative w-20 h-24 rounded-2xl bg-gradient-to-br from-slate-800 to-slate-900 border-2 border-slate-700 overflow-hidden flex-shrink-0 flex items-center justify-center shadow-[0_4px_16px_rgba(0,0,0,0.5)]">
            {photo ? (
              <img src={photo} alt={player.surname} className="w-full h-full object-cover" />
            ) : (
              <div className="flex flex-col items-center justify-center text-slate-400">
                <User className="w-8 h-8 text-cyan-400" />
                <span className="text-[10px] font-mono">#{player.number}</span>
              </div>
            )}
            <div className="absolute bottom-0 inset-x-0 bg-black/85 text-[9px] font-mono font-bold text-center text-cyan-300 py-0.5">
              {player.position}
            </div>
          </div>

          {/* Player Info & Large PES Overall Rating */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-xs text-slate-400">
                <span>{player.flag}</span>
                <span>{player.nationality}</span>
                <span className="text-cyan-400 font-mono font-bold">#{player.number}</span>
              </div>

              {/* Large PES Rating Badge */}
              <div
                className={`px-3 py-1 rounded-xl text-center border shadow-lg ${ratingColor.badgeClass} ${ratingColor.borderClass}`}
              >
                <span className="text-2xl font-black font-mono-stat leading-none">
                  {player.rating}
                </span>
                <span className="text-[9px] font-mono uppercase block -mt-0.5 leading-none">
                  OVR
                </span>
              </div>
            </div>

            <h3 className="text-xl font-black font-heading tracking-wide uppercase text-white truncate mt-0.5">
              {player.name} {player.surname}
            </h3>

            {/* Position Badges */}
            <div className="flex items-center gap-1.5 mt-1 flex-wrap">
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-cyan-950 border border-cyan-400/50 text-cyan-300 font-mono">
                {player.position}
              </span>
              {player.secondaryPositions &&
                player.secondaryPositions.map((sp) => (
                  <span
                    key={sp}
                    className="text-[10px] font-semibold px-1.5 py-0.5 rounded-md bg-slate-800 text-slate-300 border border-slate-700 font-mono"
                  >
                    {sp}
                  </span>
                ))}
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 border border-slate-700">
                Нога: {player.preferredFoot}
              </span>
            </div>
          </div>
        </div>

        {/* Individual Abilities (Индивидуальные способности) */}
        {player.skills && player.skills.length > 0 && (
          <div className="pt-2 pb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider text-amber-400 font-bold block mb-1 flex items-center gap-1">
              <Sparkles className="w-3 h-3" /> Способности:
            </span>
            <div className="flex flex-wrap gap-1">
              {player.skills.map((sk) => (
                <span
                  key={sk}
                  className="px-2 py-0.5 rounded-md bg-amber-950/50 border border-amber-400/30 text-amber-300 text-[10px] font-medium"
                >
                  ★ {sk}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* PES Characteristics Section */}
        <div className="flex-1 overflow-y-auto no-scrollbar my-2">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[10px] font-mono uppercase tracking-wider text-cyan-400 font-bold">
              Характеристики PES:
            </span>
            <span className="text-[9px] font-mono text-slate-400">
              <span className="text-emerald-400 font-bold">80-99</span> •{' '}
              <span className="text-amber-400 font-bold">60-79</span> •{' '}
              <span className="text-rose-400 font-bold">1-59</span>
            </span>
          </div>

          {/* Category Tabs */}
          <div className="flex gap-1 overflow-x-auto pb-1 no-scrollbar mb-2">
            {PES_CATEGORIES.map((cat) => (
              <button
                key={cat.title}
                type="button"
                onClick={() => {
                  sound.playTap();
                  setSelectedCategory(cat.title);
                }}
                className={`px-2 py-1 rounded-lg text-[10px] font-mono font-bold flex-shrink-0 transition-all ${
                  selectedCategory === cat.title
                    ? 'bg-cyan-500/25 text-cyan-300 border border-cyan-400/50'
                    : 'bg-slate-900 text-slate-400 border border-slate-800'
                }`}
              >
                {cat.title}
              </button>
            ))}
          </div>

          {/* Attributes List for Selected Category */}
          {PES_CATEGORIES.filter((c) => c.title === selectedCategory).map((cat) => (
            <div key={cat.title} className="flex flex-col gap-1.5">
              {cat.stats.map((st) => {
                const val = pes[st.key];
                const color = getPesRatingColor(val);
                return (
                  <div
                    key={st.key}
                    className="flex items-center justify-between px-3 py-1.5 rounded-xl bg-slate-900/80 border border-slate-800/80"
                  >
                    <span className="text-xs text-slate-200 font-medium">{st.name}</span>
                    <div className="flex items-center gap-2">
                      <div className="w-14 h-1.5 bg-slate-800 rounded-full overflow-hidden hidden sm:block">
                        <div
                          className="h-full rounded-full transition-all"
                          style={{
                            width: `${val}%`,
                            backgroundColor: color.hex,
                          }}
                        />
                      </div>
                      <span
                        className={`w-9 text-center text-xs font-mono font-black py-0.5 rounded ${color.badgeClass}`}
                      >
                        {val}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          ))}
        </div>

        {/* Actions Grid */}
        <div className="relative z-10 pt-2 border-t border-slate-700/60 flex flex-col gap-2">
          <div className="grid grid-cols-2 gap-2">
            {/* Edit Button */}
            <button
              onClick={() => {
                sound.playTap();
                onEdit(player);
              }}
              className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-cyan-600/30 hover:bg-cyan-600/50 text-cyan-300 border border-cyan-400/40 text-xs font-bold font-mono active:scale-95 transition-all shadow-[0_0_12px_rgba(6,182,212,0.3)]"
            >
              <Edit2 className="w-3.5 h-3.5" />
              <span>Редактировать</span>
            </button>

            {/* Starter / Bench Toggle */}
            <button
              onClick={() => {
                sound.playTap();
                onToggleStarter(player.id);
              }}
              className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 text-slate-200 border border-slate-700 text-xs font-bold font-mono active:scale-95 transition-all"
            >
              <ArrowLeftRight className="w-3.5 h-3.5 text-cyan-400" />
              <span>{player.isStarter ? 'В запас' : 'В основу'}</span>
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2">
            {/* Captain Toggle */}
            <button
              onClick={() => {
                sound.playSuccess();
                onToggleCaptain(player.id);
              }}
              className={`flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl text-xs font-bold font-mono active:scale-95 transition-all border ${
                player.isCaptain
                  ? 'bg-amber-500/20 text-amber-300 border-amber-400/50 shadow-[0_0_10px_rgba(245,158,11,0.3)]'
                  : 'bg-slate-800/80 text-slate-300 border-slate-700 hover:bg-slate-700/80'
              }`}
            >
              <Crown className="w-3.5 h-3.5 text-amber-400" />
              <span>{player.isCaptain ? 'Капитан (C)' : 'Сделать (C)'}</span>
            </button>

            {/* Delete button or confirm */}
            {confirmDelete ? (
              <button
                onClick={() => {
                  sound.playWhistle();
                  onDelete(player.id);
                }}
                className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-red-600 text-white font-bold text-xs font-mono active:scale-95 transition-all shadow-[0_0_15px_rgba(239,68,68,0.5)]"
              >
                <Check className="w-3.5 h-3.5" />
                <span>Точно удалить?</span>
              </button>
            ) : (
              <button
                onClick={() => {
                  sound.playTap();
                  setConfirmDelete(true);
                  setTimeout(() => setConfirmDelete(false), 3500);
                }}
                className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-red-950/40 hover:bg-red-900/60 text-red-300 border border-red-500/40 text-xs font-bold font-mono active:scale-95 transition-all"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Удалить</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
