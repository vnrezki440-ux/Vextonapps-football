import React, { useState } from 'react';
import {
  Player,
  FormationKey,
  PitchStyle,
  ThemeAccent,
  Position,
} from '../types/football';
import {
  FORMATIONS,
  calculateAverageRating,
  calculateChemistry,
  getStarters,
  getBenchPlayers,
} from '../utils/squadUtils';
import {
  Shield,
  Zap,
  ArrowLeftRight,
  Plus,
  Users,
  Trophy,
  SlidersHorizontal,
} from 'lucide-react';
import { sound } from '../utils/audio';

interface VerticalPitchProps {
  players: Player[];
  formation: FormationKey;
  onChangeFormation: (f: FormationKey) => void;
  pitchStyle: PitchStyle;
  accent: ThemeAccent;
  onSelectPlayer: (player: Player) => void;
  onAddNewPlayer: () => void;
  onSwapPlayers: (id1: string, id2: string) => void;
  photos?: Record<string, string>;
}

export const VerticalPitch: React.FC<VerticalPitchProps> = ({
  players,
  formation,
  onChangeFormation,
  pitchStyle,
  accent,
  onSelectPlayer,
  onAddNewPlayer,
  onSwapPlayers,
  photos = {},
}) => {
  const [swapSourceId, setSwapSourceId] = useState<string | null>(null);
  const [showFormationPicker, setShowFormationPicker] = useState(false);

  const starters = getStarters(players);
  const bench = getBenchPlayers(players);
  const formationConfig = FORMATIONS[formation] || FORMATIONS['4-3-3'];
  const avgRating = calculateAverageRating(players);
  const chemistry = calculateChemistry(players, formation);

  const handlePlayerNodeClick = (player: Player) => {
    sound.playTap();
    if (swapSourceId) {
      if (swapSourceId === player.id) {
        setSwapSourceId(null);
      } else {
        onSwapPlayers(swapSourceId, player.id);
        sound.playSuccess();
        setSwapSourceId(null);
      }
    } else {
      onSelectPlayer(player);
    }
  };

  const handleBenchClick = (player: Player) => {
    sound.playTap();
    if (swapSourceId) {
      onSwapPlayers(swapSourceId, player.id);
      sound.playSuccess();
      setSwapSourceId(null);
    } else {
      onSelectPlayer(player);
    }
  };

  const getPitchStyleClass = () => {
    switch (pitchStyle) {
      case 'classic':
        return 'pitch-stripes-classic border-green-800/80 shadow-[0_0_30px_rgba(22,101,52,0.3)]';
      case 'cyber-turf':
        return 'pitch-stripes-cyber border-cyan-800/80 shadow-[0_0_30px_rgba(6,182,212,0.25)]';
      case 'neon-dark':
      default:
        return 'pitch-stripes-neon border-cyan-500/30 shadow-[0_0_35px_rgba(6,182,212,0.3)]';
    }
  };

  // PES rating color tiers: 80-99 Green, 60-79 Orange, 1-59 Red
  const getRatingBadgeColor = (ovr: number) => {
    if (ovr >= 80) {
      return 'from-emerald-400 via-green-500 to-emerald-600 text-slate-950 border-emerald-300 shadow-[0_0_12px_rgba(16,185,129,0.6)]';
    }
    if (ovr >= 60) {
      return 'from-amber-400 via-orange-500 to-amber-600 text-slate-950 border-amber-300 shadow-[0_0_12px_rgba(245,158,11,0.6)]';
    }
    return 'from-rose-500 via-red-600 to-rose-700 text-white border-rose-300 shadow-[0_0_12px_rgba(244,63,94,0.6)]';
  };

  return (
    <div className="w-full flex flex-col items-center pb-24" data-testid="vertical-pitch-container">
      {/* HUD Bar at top: Formation, OVR, Chemistry */}
      <div className="w-full max-w-md px-3 pt-2 pb-2">
        <div className="glass-panel rounded-2xl p-3 border border-cyan-500/25 flex items-center justify-between gap-2 shadow-lg">
          {/* OVR Rating */}
          <div className="flex items-center gap-2">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-amber-500 via-yellow-500 to-amber-700 p-0.5 shadow-[0_0_14px_rgba(245,158,11,0.5)]">
              <div className="w-full h-full bg-[#090e21] rounded-[10px] flex flex-col items-center justify-center">
                <span className="text-[9px] font-bold text-amber-400 uppercase tracking-wider font-mono">OVR</span>
                <span className="text-base font-black text-amber-300 leading-none font-mono-stat">{avgRating}</span>
              </div>
            </div>
            <div className="flex flex-col">
              <span className="text-xs font-bold text-slate-200 flex items-center gap-1 font-heading">
                Рейтинг состава
              </span>
              <span className="text-[10px] text-slate-400">11 стартовых игроков</span>
            </div>
          </div>

          {/* Chemistry Metric */}
          <div className="flex items-center gap-2 px-2 border-x border-slate-700/60">
            <div className="flex flex-col items-end">
              <div className="flex items-center gap-1">
                <Zap className="w-3.5 h-3.5 text-cyan-400 fill-cyan-400" />
                <span className="text-xs font-extrabold text-cyan-300 font-mono">{chemistry}%</span>
              </div>
              <div className="w-16 h-1.5 bg-slate-800 rounded-full overflow-hidden mt-1">
                <div
                  className="h-full bg-gradient-to-r from-blue-500 via-cyan-400 to-emerald-400 rounded-full shadow-[0_0_8px_rgba(6,182,212,0.8)]"
                  style={{ width: `${chemistry}%` }}
                />
              </div>
            </div>
          </div>

          {/* Formation Picker Button */}
          <div className="relative">
            <button
              onClick={() => {
                sound.playTap();
                setShowFormationPicker(!showFormationPicker);
              }}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-800/90 hover:bg-slate-700/90 border border-cyan-500/40 text-cyan-300 text-xs font-bold font-mono active:scale-95 transition-all shadow-[0_0_10px_rgba(6,182,212,0.2)]"
              aria-label="Сменить схему"
            >
              <span>{formation}</span>
              <SlidersHorizontal className="w-3.5 h-3.5 text-cyan-400" />
            </button>

            {/* Formation Dropdown */}
            {showFormationPicker && (
              <div className="absolute right-0 top-11 z-50 w-44 glass-panel rounded-xl p-1.5 border border-cyan-400/40 shadow-2xl backdrop-blur-xl animate-in fade-in zoom-in-95 duration-100">
                <div className="text-[10px] font-bold text-cyan-400 uppercase tracking-wider px-2 py-1">
                  Тактическая схема:
                </div>
                {(['4-3-3', '4-4-2', '3-5-2', '4-2-3-1', '5-3-2'] as FormationKey[]).map((f) => (
                  <button
                    key={f}
                    onClick={() => {
                      sound.playTap();
                      onChangeFormation(f);
                      setShowFormationPicker(false);
                    }}
                    className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-mono font-bold flex items-center justify-between transition-colors ${
                      formation === f
                        ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/30'
                        : 'text-slate-300 hover:bg-white/5'
                    }`}
                  >
                    <span>{f}</span>
                    {formation === f && <span className="text-[10px] text-cyan-400">●</span>}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Swap Mode Notification Banner if active */}
      {swapSourceId && (
        <div className="w-full max-w-md px-3 pb-2 animate-pulse">
          <div className="bg-amber-500/20 border border-amber-400/50 rounded-xl px-3 py-1.5 flex items-center justify-between text-xs text-amber-300">
            <span className="flex items-center gap-1.5 font-medium">
              <ArrowLeftRight className="w-3.5 h-3.5" />
              Выберите второго игрока для обмена позициями
            </span>
            <button
              onClick={() => setSwapSourceId(null)}
              className="text-amber-400 hover:text-white font-bold ml-2 underline text-[11px]"
            >
              Отмена
            </button>
          </div>
        </div>
      )}

      {/* The Pitch Canvas (Realistic Vertical Stadium Pitch) */}
      <div className="w-full max-w-md px-2 flex justify-center">
        <div
          className={`relative w-full rounded-3xl overflow-hidden border-2 ${getPitchStyleClass()} select-none`}
          style={{
            height: '560px',
            boxShadow: 'inset 0 0 50px rgba(0,0,0,0.6), 0 10px 40px rgba(0,0,0,0.8)',
          }}
        >
          {/* SVG Pitch Markings */}
          <svg
            className="absolute inset-0 w-full h-full pointer-events-none opacity-85"
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 100 140"
            preserveAspectRatio="none"
          >
            <defs>
              <filter id="pitchGlow" x="-20%" y="-20%" width="140%" height="140%">
                <feDropShadow dx="0" dy="0" stdDeviation="0.4" floodColor="#38bdf8" floodOpacity="0.6" />
              </filter>
            </defs>

            {/* Outer Pitch Border Line */}
            <rect
              x="3"
              y="3"
              width="94"
              height="134"
              fill="none"
              stroke="rgba(255, 255, 255, 0.75)"
              strokeWidth="0.6"
              filter="url(#pitchGlow)"
            />

            {/* Halfway Line */}
            <line
              x1="3"
              y1="70"
              x2="97"
              y2="70"
              stroke="rgba(255, 255, 255, 0.75)"
              strokeWidth="0.6"
            />

            {/* Center Circle & Spot */}
            <circle
              cx="50"
              cy="70"
              r="13"
              fill="none"
              stroke="rgba(255, 255, 255, 0.75)"
              strokeWidth="0.6"
            />
            <circle cx="50" cy="70" r="0.8" fill="rgba(255, 255, 255, 0.9)" />

            {/* TOP / ATTACKING PENALTY BOX & GOAL */}
            <rect
              x="22"
              y="3"
              width="56"
              height="22"
              fill="none"
              stroke="rgba(255, 255, 255, 0.75)"
              strokeWidth="0.6"
            />
            {/* Top 6-yard box */}
            <rect
              x="34"
              y="3"
              width="32"
              height="8"
              fill="none"
              stroke="rgba(255, 255, 255, 0.75)"
              strokeWidth="0.6"
            />
            {/* Top Penalty Spot */}
            <circle cx="50" cy="15" r="0.7" fill="rgba(255, 255, 255, 0.9)" />
            {/* Top Penalty Arc */}
            <path
              d="M 39 25 A 11 11 0 0 0 61 25"
              fill="none"
              stroke="rgba(255, 255, 255, 0.75)"
              strokeWidth="0.6"
            />
            {/* Top Goal Frame */}
            <rect
              x="38"
              y="0.5"
              width="24"
              height="2.5"
              fill="rgba(255, 255, 255, 0.2)"
              stroke="rgba(255, 255, 255, 0.9)"
              strokeWidth="0.6"
            />

            {/* BOTTOM / DEFENDING PENALTY BOX & GOAL */}
            <rect
              x="22"
              y="115"
              width="56"
              height="22"
              fill="none"
              stroke="rgba(255, 255, 255, 0.75)"
              strokeWidth="0.6"
            />
            {/* Bottom 6-yard box */}
            <rect
              x="34"
              y="129"
              width="32"
              height="8"
              fill="none"
              stroke="rgba(255, 255, 255, 0.75)"
              strokeWidth="0.6"
            />
            {/* Bottom Penalty Spot */}
            <circle cx="50" cy="125" r="0.7" fill="rgba(255, 255, 255, 0.9)" />
            {/* Bottom Penalty Arc */}
            <path
              d="M 39 115 A 11 11 0 0 1 61 115"
              fill="none"
              stroke="rgba(255, 255, 255, 0.75)"
              strokeWidth="0.6"
            />
            {/* Bottom Goal Frame */}
            <rect
              x="38"
              y="137"
              width="24"
              height="2.5"
              fill="rgba(255, 255, 255, 0.2)"
              stroke="rgba(255, 255, 255, 0.9)"
              strokeWidth="0.6"
            />

            {/* Corner Arcs */}
            <path d="M 3 6 A 3 3 0 0 0 6 3" fill="none" stroke="rgba(255, 255, 255, 0.75)" strokeWidth="0.6" />
            <path d="M 94 3 A 3 3 0 0 0 97 6" fill="none" stroke="rgba(255, 255, 255, 0.75)" strokeWidth="0.6" />
            <path d="M 3 134 A 3 3 0 0 1 6 137" fill="none" stroke="rgba(255, 255, 255, 0.75)" strokeWidth="0.6" />
            <path d="M 94 137 A 3 3 0 0 1 97 134" fill="none" stroke="rgba(255, 255, 255, 0.75)" strokeWidth="0.6" />
          </svg>

          {/* Ambient stadium lights overlay */}
          <div className="absolute inset-0 bg-radial from-transparent via-cyan-950/10 to-black/60 pointer-events-none" />

          {/* 11 Tactical Player Nodes on the Pitch */}
          {formationConfig.slots.map((slot) => {
            // Find player assigned to this starter index
            const player = starters.find((p) => p.starterIndex === slot.index) || starters[slot.index];
            const isSwappingThis = player && swapSourceId === player.id;

            return (
              <div
                key={`slot-${slot.index}`}
                className="absolute -translate-x-1/2 -translate-y-1/2 cursor-pointer transition-all duration-300"
                style={{
                  left: `${slot.x}%`,
                  top: `${slot.y}%`,
                  zIndex: isSwappingThis ? 30 : 15,
                }}
              >
                {player ? (
                  <div
                    onClick={() => handlePlayerNodeClick(player)}
                    className="group flex flex-col items-center focus:outline-none"
                    role="button"
                    tabIndex={0}
                    aria-label={`Игрок ${player.name} ${player.surname}, ${slot.code}, рейтинг ${player.rating}`}
                  >
                    {/* Player Badge Container */}
                    <div
                      className={`relative flex items-center justify-center w-12 h-12 rounded-2xl p-0.5 transition-all duration-200 group-hover:scale-110 group-active:scale-95 ${
                        isSwappingThis
                          ? 'ring-4 ring-amber-400 scale-110 shadow-[0_0_20px_rgba(245,158,11,0.8)]'
                          : 'shadow-[0_4px_14px_rgba(0,0,0,0.6)]'
                      }`}
                    >
                      {/* Gradient border */}
                      <div
                        className={`w-full h-full rounded-[14px] bg-gradient-to-b ${getRatingBadgeColor(
                          player.rating
                        )} p-0.5`}
                      >
                        <div className="w-full h-full bg-[#080d1f] rounded-[12px] flex flex-col items-center justify-center relative overflow-hidden">
                          {/* Photo background if available */}
                          {photos[player.id] || player.photoUrl ? (
                            <img
                              src={photos[player.id] || player.photoUrl}
                              alt={player.surname}
                              className="absolute inset-0 w-full h-full object-cover opacity-50"
                            />
                          ) : null}

                          {/* Top jersey number & flag */}
                          <div className="relative z-10 flex items-center gap-0.5 -mt-0.5">
                            <span className="text-[10px] leading-none">{player.flag}</span>
                            <span className="text-[10px] font-black font-mono leading-none text-slate-300">
                              #{player.number}
                            </span>
                          </div>

                          {/* Player OVR Rating */}
                          <span className="relative z-10 text-base font-black leading-none font-mono-stat text-transparent bg-clip-text bg-gradient-to-b from-white to-slate-200 drop-shadow">
                            {player.rating}
                          </span>

                          {/* Slot Position Tag */}
                          <span className="relative z-10 text-[8px] font-bold text-cyan-300 font-mono tracking-tighter uppercase leading-none">
                            {slot.code}
                          </span>

                          {/* Captain Armband Tag */}
                          {player.isCaptain && (
                            <div className="absolute top-0 right-0 w-3.5 h-3.5 bg-amber-500 rounded-bl-md flex items-center justify-center shadow-sm z-20">
                              <span className="text-[8px] font-black text-black leading-none">C</span>
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Swap button hint on hover */}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          sound.playTap();
                          setSwapSourceId(player.id);
                        }}
                        className="absolute -top-1.5 -left-1.5 w-4 h-4 rounded-full bg-slate-900 border border-cyan-400 text-cyan-300 flex items-center justify-center opacity-0 group-hover:opacity-100 hover:bg-cyan-500 hover:text-black transition-opacity text-[8px]"
                        title="Поменять местами"
                      >
                        ⇄
                      </button>
                    </div>

                    {/* Player Surname Label */}
                    <div className="mt-1 px-1.5 py-0.5 rounded-md bg-black/80 backdrop-blur-sm border border-white/10 shadow-md flex items-center gap-1 max-w-[80px]">
                      <span className="text-[10px] font-bold text-white truncate text-center w-full leading-tight">
                        {player.surname}
                      </span>
                    </div>
                  </div>
                ) : (
                  /* Empty Slot to add player */
                  <div
                    onClick={onAddNewPlayer}
                    className="flex flex-col items-center group cursor-pointer"
                    role="button"
                    tabIndex={0}
                    aria-label={`Добавить игрока на позицию ${slot.code}`}
                  >
                    <div className="w-11 h-11 rounded-2xl border-2 border-dashed border-cyan-400/50 bg-black/40 flex flex-col items-center justify-center group-hover:border-cyan-300 group-hover:bg-cyan-950/40 transition-all">
                      <Plus className="w-4 h-4 text-cyan-400 group-hover:scale-125 transition-transform" />
                      <span className="text-[8px] font-mono font-bold text-cyan-400 mt-0.5">
                        {slot.code}
                      </span>
                    </div>
                    <span className="text-[9px] font-medium text-slate-400 mt-1 bg-black/70 px-1 rounded">
                      Пусто
                    </span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Bench / Substitutes Section */}
      <div className="w-full max-w-md px-3 mt-4">
        <div className="glass-panel rounded-2xl p-3 border border-slate-700/60 shadow-lg">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5">
              <Users className="w-4 h-4 text-cyan-400" />
              <span className="text-xs font-bold text-slate-200 font-heading uppercase tracking-wide">
                Запасные ({bench.length})
              </span>
            </div>
            <button
              onClick={() => {
                sound.playTap();
                onAddNewPlayer();
              }}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-cyan-600/30 hover:bg-cyan-600/50 text-cyan-300 border border-cyan-400/40 text-[11px] font-bold active:scale-95 transition-all shadow-[0_0_8px_rgba(6,182,212,0.3)]"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Создать игрока</span>
            </button>
          </div>

          {/* Bench horizontal scrollable strip */}
          <div className="flex gap-2.5 overflow-x-auto pb-1 pt-1 no-scrollbar">
            {bench.map((player) => (
              <div
                key={player.id}
                onClick={() => handleBenchClick(player)}
                className={`flex-shrink-0 flex flex-col items-center p-2 rounded-xl bg-slate-900/80 hover:bg-slate-800/90 border cursor-pointer active:scale-95 transition-all ${
                  swapSourceId === player.id
                    ? 'border-amber-400 ring-2 ring-amber-400/50 bg-amber-950/30'
                    : 'border-slate-800 hover:border-cyan-500/40'
                }`}
                style={{ width: '82px' }}
                role="button"
                tabIndex={0}
                aria-label={`Запасной ${player.name} ${player.surname}, ${player.position}, OVR ${player.rating}`}
              >
                {/* OVR + Flag */}
                <div className="flex items-center justify-between w-full text-[10px] font-mono font-bold text-slate-400 mb-1">
                  <span>{player.flag}</span>
                  <span className="text-amber-400 font-black">{player.rating}</span>
                </div>

                {/* Avatar / Photo badge */}
                <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-slate-700 to-slate-800 flex items-center justify-center text-xs font-mono font-black text-cyan-300 border border-slate-600 mb-1 overflow-hidden relative">
                  {photos[player.id] || player.photoUrl ? (
                    <img
                      src={photos[player.id] || player.photoUrl}
                      alt={player.surname}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <span>#{player.number}</span>
                  )}
                </div>

                {/* Surname */}
                <span className="text-[10px] font-bold text-slate-200 truncate w-full text-center">
                  {player.surname}
                </span>
                {/* Position */}
                <span className="text-[9px] font-mono text-cyan-400 uppercase">
                  {player.position}
                </span>
              </div>
            ))}

            {bench.length === 0 && (
              <div className="w-full py-4 text-center text-xs text-slate-500">
                Все игроки в стартовом составе. Нажмите «Создать игрока», чтобы добавить запасных.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
