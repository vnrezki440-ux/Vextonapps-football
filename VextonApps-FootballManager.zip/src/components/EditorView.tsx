import React, { useState } from 'react';
import { Player, Position } from '../types/football';
import {
  ALL_POSITIONS,
  getPesRatingColor,
  getOrGeneratePesStats,
} from '../utils/squadUtils';
import {
  Plus,
  Edit2,
  Trash2,
  Search,
  Sparkles,
  User,
  Shield,
  Zap,
  Check,
  ChevronRight,
  Eye,
} from 'lucide-react';
import { sound } from '../utils/audio';

interface EditorViewProps {
  players: Player[];
  photos: Record<string, string>;
  onAddNewPlayer: () => void;
  onEditPlayer: (player: Player) => void;
  onSelectPlayer: (player: Player) => void;
  onDeletePlayer: (id: string) => void;
}

export const EditorView: React.FC<EditorViewProps> = ({
  players,
  photos,
  onAddNewPlayer,
  onEditPlayer,
  onSelectPlayer,
  onDeletePlayer,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [positionFilter, setPositionFilter] = useState<string>('ALL');
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const filteredPlayers = players.filter((p) => {
    const matchesSearch =
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.surname.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.number.toString().includes(searchQuery) ||
      p.position.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (p.skills && p.skills.some((s) => s.toLowerCase().includes(searchQuery.toLowerCase())));

    if (!matchesSearch) return false;
    if (positionFilter === 'ALL') return true;
    return p.position === positionFilter;
  });

  return (
    <div className="w-full max-w-md mx-auto px-3 py-3 pb-24 select-none" data-testid="editor-view">
      {/* Top Banner */}
      <div className="glass-panel rounded-2xl p-4 border border-teal-500/30 mb-4 shadow-[0_0_20px_rgba(20,184,166,0.15)] flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-teal-500/20 border border-teal-400/40 flex items-center justify-center text-teal-300 shadow-[0_0_12px_rgba(20,184,166,0.4)]">
            <Edit2 className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white font-heading uppercase">
              Редактирование игроков
            </h2>
            <p className="text-[11px] text-teal-300/80">
              Создание, галерея фото и характеристики в стиле PES
            </p>
          </div>
        </div>

        <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-lg bg-teal-950/70 text-teal-300 border border-teal-500/30">
          {players.length} игроков
        </span>
      </div>

      {/* Prominent "Добавить игрока" Neon Button */}
      <button
        onClick={() => {
          sound.playTap();
          onAddNewPlayer();
        }}
        className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white text-sm font-bold font-mono flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(16,185,129,0.35)] active:scale-95 transition-all mb-4"
        data-testid="add-player-btn"
      >
        <Plus className="w-5 h-5" />
        <span>Добавить игрока</span>
      </button>

      {/* Search Bar */}
      <div className="relative mb-3">
        <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Поиск по имени, номеру, позиции или способностям..."
          className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-900/80 border border-slate-700 focus:border-teal-400 text-xs text-white outline-none font-medium transition-colors"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white text-xs"
          >
            ✕
          </button>
        )}
      </div>

      {/* Position Filter Chips */}
      <div className="flex gap-1.5 overflow-x-auto pb-1.5 no-scrollbar mb-3 text-xs font-mono font-bold">
        <button
          onClick={() => {
            sound.playTap();
            setPositionFilter('ALL');
          }}
          className={`px-2.5 py-1 rounded-lg flex-shrink-0 transition-colors ${
            positionFilter === 'ALL'
              ? 'bg-teal-500/25 text-teal-300 border border-teal-400/50 shadow-sm'
              : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-slate-200'
          }`}
        >
          Все ({players.length})
        </button>
        {ALL_POSITIONS.map((pos) => {
          const count = players.filter((p) => p.position === pos).length;
          if (count === 0) return null;
          return (
            <button
              key={pos}
              onClick={() => {
                sound.playTap();
                setPositionFilter(pos);
              }}
              className={`px-2.5 py-1 rounded-lg flex-shrink-0 transition-colors ${
                positionFilter === pos
                  ? 'bg-teal-500/25 text-teal-300 border border-teal-400/50 shadow-sm'
                  : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-slate-200'
              }`}
            >
              {pos} ({count})
            </button>
          );
        })}
      </div>

      {/* Players List with PES Badges & Photo Thumbnails */}
      <div className="flex flex-col gap-2.5">
        {filteredPlayers.map((player) => {
          const ratingColor = getPesRatingColor(player.rating);
          const photo = photos[player.id] || player.photoUrl;
          const pes = getOrGeneratePesStats(player);
          const isConfirmingDelete = deleteConfirmId === player.id;

          return (
            <div
              key={player.id}
              className="glass-panel rounded-2xl p-3 border border-slate-800 hover:border-teal-500/40 flex flex-col gap-2 transition-all shadow-md"
            >
              <div className="flex items-center justify-between gap-3">
                {/* Left: Photo / Avatar + OVR + Name */}
                <div
                  className="flex items-center gap-3 cursor-pointer flex-1 min-w-0"
                  onClick={() => onSelectPlayer(player)}
                >
                  {/* Photo or Avatar Frame */}
                  <div className="relative w-12 h-12 rounded-xl bg-gradient-to-tr from-slate-800 to-slate-900 border border-slate-700 overflow-hidden flex-shrink-0 flex items-center justify-center">
                    {photo ? (
                      <img src={photo} alt={player.surname} className="w-full h-full object-cover" />
                    ) : (
                      <div className="flex flex-col items-center justify-center text-slate-400">
                        <User className="w-5 h-5 text-cyan-400" />
                        <span className="text-[8px] font-mono">#{player.number}</span>
                      </div>
                    )}
                    {/* Position tag overlay */}
                    <div className="absolute bottom-0 inset-x-0 bg-black/80 text-[8px] font-mono font-bold text-center text-cyan-300 uppercase leading-tight py-0.2">
                      {player.position}
                    </div>
                  </div>

                  {/* Large PES Overall Rating Badge */}
                  <div
                    className={`px-2.5 py-1 rounded-xl text-center flex-shrink-0 ${ratingColor.badgeClass}`}
                  >
                    <span className="text-lg font-black font-mono-stat leading-none">
                      {player.rating}
                    </span>
                    <span className="text-[8px] font-mono uppercase block -mt-0.5 leading-none">
                      OVR
                    </span>
                  </div>

                  {/* Player Name and Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className="text-sm">{player.flag}</span>
                      <span className="text-sm font-bold text-white truncate font-heading">
                        {player.name} {player.surname}
                      </span>
                      {player.isCaptain && (
                        <span className="text-[8px] font-black bg-amber-500 text-black px-1 rounded-sm">
                          C
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-1.5 text-[10px] text-slate-400 font-mono mt-0.5 flex-wrap">
                      <span className="text-cyan-400 font-bold">#{player.number}</span>
                      <span>•</span>
                      <span>{player.isStarter ? 'Основа' : 'Запас'}</span>
                      <span>•</span>
                      <span>Нога: {player.preferredFoot}</span>
                    </div>
                  </div>
                </div>

                {/* Right Actions: Edit, View Card, Delete */}
                <div className="flex items-center gap-1.5 flex-shrink-0">
                  <button
                    onClick={() => {
                      sound.playTap();
                      onSelectPlayer(player);
                    }}
                    className="w-8 h-8 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-cyan-300 flex items-center justify-center border border-slate-700"
                    title="Открыть карточку PES"
                  >
                    <Eye className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => {
                      sound.playTap();
                      onEditPlayer(player);
                    }}
                    className="w-8 h-8 rounded-xl bg-teal-950/60 hover:bg-teal-900/60 text-teal-300 flex items-center justify-center border border-teal-500/40"
                    title="Изменить игрока"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>

                  {isConfirmingDelete ? (
                    <button
                      onClick={() => {
                        sound.playWhistle();
                        onDeletePlayer(player.id);
                        setDeleteConfirmId(null);
                      }}
                      className="px-2 py-1 rounded-xl bg-red-600 text-white font-mono font-bold text-[10px] animate-pulse"
                    >
                      Удалить?
                    </button>
                  ) : (
                    <button
                      onClick={() => {
                        sound.playTap();
                        setDeleteConfirmId(player.id);
                        setTimeout(() => setDeleteConfirmId(null), 3500);
                      }}
                      className="w-8 h-8 rounded-xl bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 flex items-center justify-center border border-rose-500/40"
                      title="Удалить игрока"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>

              {/* Secondary positions & skills tags */}
              <div className="flex items-center gap-1.5 flex-wrap pt-1 border-t border-slate-800/60 text-[10px]">
                {/* Secondary Positions */}
                {player.secondaryPositions && player.secondaryPositions.length > 0 && (
                  <div className="flex items-center gap-1">
                    <span className="text-slate-500 font-mono">Доп:</span>
                    {player.secondaryPositions.map((sp) => (
                      <span
                        key={sp}
                        className="px-1.5 py-0.2 rounded bg-slate-900 text-cyan-300 border border-cyan-500/30 font-mono font-bold"
                      >
                        {sp}
                      </span>
                    ))}
                  </div>
                )}

                {/* Skills tags */}
                {player.skills && player.skills.length > 0 && (
                  <div className="flex items-center gap-1 flex-wrap">
                    {player.skills.slice(0, 3).map((sk) => (
                      <span
                        key={sk}
                        className="px-1.5 py-0.2 rounded bg-amber-950/50 text-amber-300 border border-amber-400/30 text-[9px]"
                      >
                        ★ {sk}
                      </span>
                    ))}
                    {player.skills.length > 3 && (
                      <span className="text-[9px] text-slate-500">
                        +{player.skills.length - 3}
                      </span>
                    )}
                  </div>
                )}
              </div>
            </div>
          );
        })}

        {filteredPlayers.length === 0 && (
          <div className="glass-panel rounded-2xl p-6 text-center text-slate-400 text-xs">
            Игроки не найдены по текущему фильтру.
          </div>
        )}
      </div>
    </div>
  );
};
