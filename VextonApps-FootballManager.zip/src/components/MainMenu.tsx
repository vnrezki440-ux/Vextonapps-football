import React from 'react';
import {
  AppView,
  Player,
  FormationKey,
  ThemeAccent,
} from '../types/football';
import {
  calculateAverageRating,
  calculateChemistry,
  getStarters,
} from '../utils/squadUtils';
import {
  Trophy,
  LayoutGrid,
  Database,
  Flag,
  Headphones,
  Settings,
  UserCheck,
  LogOut,
  ChevronRight,
  Zap,
  Users,
  Activity,
  Edit3,
} from 'lucide-react';
import { sound } from '../utils/audio';

interface MainMenuProps {
  onNavigate: (view: AppView) => void;
  players: Player[];
  formation: FormationKey;
  teamName: string;
  accent: ThemeAccent;
  onOpenExit: () => void;
}

export const MainMenu: React.FC<MainMenuProps> = ({
  onNavigate,
  players,
  formation,
  teamName,
  accent,
  onOpenExit,
}) => {
  const starters = getStarters(players);
  const avgOvr = calculateAverageRating(players);
  const chemistry = calculateChemistry(players, formation);

  const handleMenuClick = (view: AppView) => {
    sound.playTap();
    onNavigate(view);
  };

  return (
    <div className="w-full max-w-md mx-auto px-4 py-4 pb-24 select-none" data-testid="main-menu-view">
      {/* Squad Hero Widget */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#0c1633] via-[#09112a] to-[#050916] border border-cyan-500/30 p-5 shadow-[0_0_30px_rgba(6,182,212,0.2)] mb-5">
        {/* Glow corner circles */}
        <div className="absolute -top-12 -right-12 w-36 h-36 bg-cyan-500/20 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute -bottom-10 -left-10 w-32 h-32 bg-blue-600/20 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 flex items-start justify-between">
          <div>
            <div className="flex items-center gap-1.5 text-xs text-cyan-400 font-mono font-semibold tracking-wider uppercase mb-1">
              <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block animate-pulse" />
              Активный клуб
            </div>
            <h2 className="text-2xl font-black text-white tracking-wide font-heading uppercase drop-shadow-sm">
              {teamName}
            </h2>
            <div className="flex items-center gap-2 mt-1">
              <span className="px-2 py-0.5 rounded-md bg-cyan-950/80 border border-cyan-400/40 text-[11px] font-mono font-bold text-cyan-300">
                {formation}
              </span>
              <span className="text-xs text-slate-400">
                {players.length} игроков в базе
              </span>
            </div>
          </div>

          {/* OVR Shield badge */}
          <div className="flex flex-col items-center">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-500 via-yellow-400 to-amber-600 p-0.5 shadow-[0_0_20px_rgba(245,158,11,0.5)]">
              <div className="w-full h-full bg-[#080d1e] rounded-[14px] flex flex-col items-center justify-center">
                <span className="text-[9px] font-bold text-amber-400 uppercase font-mono">
                  OVR
                </span>
                <span className="text-2xl font-black text-amber-300 leading-none font-mono-stat">
                  {avgOvr}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Quick metrics bar */}
        <div className="grid grid-cols-3 gap-2 mt-4 pt-3 border-t border-slate-700/60">
          <div className="flex flex-col">
            <span className="text-[10px] text-slate-400 uppercase">Стартовые</span>
            <span className="text-sm font-bold font-mono text-cyan-300">
              {starters.length} / 11
            </span>
          </div>
          <div className="flex flex-col">
            <span className="text-[10px] text-slate-400 uppercase">Сыгранность</span>
            <span className="text-sm font-bold font-mono text-emerald-400 flex items-center gap-0.5">
              <Zap className="w-3 h-3 fill-emerald-400" />
              {chemistry}%
            </span>
          </div>
          <div className="flex flex-col">
            <span className="text-[10px] text-slate-400 uppercase">Капитан</span>
            <span className="text-xs font-bold text-amber-300 truncate">
              {players.find((p) => p.isCaptain)?.surname || 'Не назначен'}
            </span>
          </div>
        </div>
      </div>

      {/* Menu Header Label */}
      <div className="flex items-center justify-between mb-3 px-1">
        <span className="text-xs font-bold font-mono tracking-widest uppercase text-cyan-400">
          Главное меню VextonApps
        </span>
        <span className="text-[10px] text-slate-400 font-mono">v2.4.0 NEON</span>
      </div>

      {/* The 7 Requested Buttons Grid */}
      <div className="flex flex-col gap-2">
        {/* 1. Показать состав */}
        <button
          onClick={() => handleMenuClick('pitch')}
          className="group relative w-full overflow-hidden rounded-2xl bg-gradient-to-r from-cyan-950/70 via-[#0d1f3d] to-[#071329] p-3 border border-cyan-400/50 hover:border-cyan-300 shadow-[0_0_15px_rgba(6,182,212,0.25)] hover:shadow-[0_0_20px_rgba(6,182,212,0.35)] active:scale-[0.98] transition-all text-left"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-cyan-500/20 border border-cyan-400/60 flex items-center justify-center text-cyan-300 group-hover:scale-110 transition-transform shadow-[0_0_10px_rgba(6,182,212,0.4)]">
                <LayoutGrid className="w-5 h-5 text-cyan-300" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white group-hover:text-cyan-200 font-heading">
                  Показать состав
                </h3>
                <p className="text-[11px] text-cyan-300/80 font-medium">
                  Вертикальное поле, 11 позиций игроков и тактика
                </p>
              </div>
            </div>
            <div className="w-6 h-6 rounded-lg bg-cyan-900/40 border border-cyan-500/30 flex items-center justify-center text-cyan-300 group-hover:translate-x-0.5 transition-transform">
              <ChevronRight className="w-3.5 h-3.5" />
            </div>
          </div>
        </button>

        {/* 2. Данные */}
        <button
          onClick={() => handleMenuClick('data')}
          className="group relative w-full overflow-hidden rounded-2xl bg-gradient-to-r from-emerald-950/60 via-[#0a2321] to-[#061718] p-3 border border-emerald-400/40 hover:border-emerald-300 shadow-[0_0_12px_rgba(16,185,129,0.2)] hover:shadow-[0_0_18px_rgba(16,185,129,0.35)] active:scale-[0.98] transition-all text-left"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-400/60 flex items-center justify-center text-emerald-300 group-hover:scale-110 transition-transform shadow-[0_0_10px_rgba(16,185,129,0.4)]">
                <Database className="w-5 h-5 text-emerald-300" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white group-hover:text-emerald-200 font-heading">
                  Данные
                </h3>
                <p className="text-[11px] text-emerald-300/80 font-medium">
                  Анализ клуба, фильтры, экспорт и импорт состава
                </p>
              </div>
            </div>
            <div className="w-6 h-6 rounded-lg bg-emerald-900/40 border border-emerald-500/30 flex items-center justify-center text-emerald-300 group-hover:translate-x-0.5 transition-transform">
              <ChevronRight className="w-3.5 h-3.5" />
            </div>
          </div>
        </button>

        {/* 3. Сообщить о пользователе */}
        <button
          onClick={() => handleMenuClick('report')}
          className="group relative w-full overflow-hidden rounded-2xl bg-gradient-to-r from-amber-950/60 via-[#26190e] to-[#170e06] p-3 border border-amber-400/40 hover:border-amber-300 shadow-[0_0_12px_rgba(245,158,11,0.2)] hover:shadow-[0_0_18px_rgba(245,158,11,0.35)] active:scale-[0.98] transition-all text-left"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-400/60 flex items-center justify-center text-amber-300 group-hover:scale-110 transition-transform shadow-[0_0_10px_rgba(245,158,11,0.4)]">
                <Flag className="w-5 h-5 text-amber-300" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white group-hover:text-amber-200 font-heading">
                  Сообщить о пользователе
                </h3>
                <p className="text-[11px] text-amber-300/80 font-medium">
                  Жалоба на неспортивное поведение, читерство или ник
                </p>
              </div>
            </div>
            <div className="w-6 h-6 rounded-lg bg-amber-900/40 border border-amber-500/30 flex items-center justify-center text-amber-300 group-hover:translate-x-0.5 transition-transform">
              <ChevronRight className="w-3.5 h-3.5" />
            </div>
          </div>
        </button>

        {/* 4. Поддержка */}
        <button
          onClick={() => handleMenuClick('support')}
          className="group relative w-full overflow-hidden rounded-2xl bg-gradient-to-r from-blue-950/60 via-[#101b3b] to-[#091024] p-3 border border-blue-400/40 hover:border-blue-300 shadow-[0_0_12px_rgba(59,130,246,0.2)] hover:shadow-[0_0_18px_rgba(59,130,246,0.35)] active:scale-[0.98] transition-all text-left"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-500/20 border border-blue-400/60 flex items-center justify-center text-blue-300 group-hover:scale-110 transition-transform shadow-[0_0_10px_rgba(59,130,246,0.4)]">
                <Headphones className="w-5 h-5 text-blue-300" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white group-hover:text-blue-200 font-heading">
                  Поддержка
                </h3>
                <p className="text-[11px] text-blue-300/80 font-medium">
                  Часто задаваемые вопросы и связь с разработчиком
                </p>
              </div>
            </div>
            <div className="w-6 h-6 rounded-lg bg-blue-900/40 border border-blue-500/30 flex items-center justify-center text-blue-300 group-hover:translate-x-0.5 transition-transform">
              <ChevronRight className="w-3.5 h-3.5" />
            </div>
          </div>
        </button>

        {/* 5. Настройки */}
        <button
          onClick={() => handleMenuClick('settings')}
          className="group relative w-full overflow-hidden rounded-2xl bg-gradient-to-r from-purple-950/60 via-[#1c1236] to-[#0f0920] p-3 border border-purple-400/40 hover:border-purple-300 shadow-[0_0_12px_rgba(168,85,247,0.2)] hover:shadow-[0_0_18px_rgba(168,85,247,0.35)] active:scale-[0.98] transition-all text-left"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-purple-500/20 border border-purple-400/60 flex items-center justify-center text-purple-300 group-hover:scale-110 transition-transform shadow-[0_0_10px_rgba(168,85,247,0.4)]">
                <Settings className="w-5 h-5 text-purple-300" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white group-hover:text-purple-200 font-heading">
                  Настройки
                </h3>
                <p className="text-[11px] text-purple-300/80 font-medium">
                  Схема расстановки, тема неоновой подсветки и звук
                </p>
              </div>
            </div>
            <div className="w-6 h-6 rounded-lg bg-purple-900/40 border border-purple-500/30 flex items-center justify-center text-purple-300 group-hover:translate-x-0.5 transition-transform">
              <ChevronRight className="w-3.5 h-3.5" />
            </div>
          </div>
        </button>

        {/* 6. Редактирование */}
        <button
          onClick={() => handleMenuClick('editor')}
          className="group relative w-full overflow-hidden rounded-2xl bg-gradient-to-r from-teal-950/60 via-[#092833] to-[#061722] p-3 border border-teal-400/40 hover:border-teal-300 shadow-[0_0_12px_rgba(20,184,166,0.2)] hover:shadow-[0_0_18px_rgba(20,184,166,0.35)] active:scale-[0.98] transition-all text-left"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-teal-500/20 border border-teal-400/60 flex items-center justify-center text-teal-300 group-hover:scale-110 transition-transform shadow-[0_0_10px_rgba(20,184,166,0.4)]">
                <Edit3 className="w-5 h-5 text-teal-300" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white group-hover:text-teal-200 font-heading">
                  Редактирование
                </h3>
                <p className="text-[11px] text-teal-300/80 font-medium">
                  Создание, редактирование и удаление игроков
                </p>
              </div>
            </div>
            <div className="w-6 h-6 rounded-lg bg-teal-900/40 border border-teal-500/30 flex items-center justify-center text-teal-300 group-hover:translate-x-0.5 transition-transform">
              <ChevronRight className="w-3.5 h-3.5" />
            </div>
          </div>
        </button>

        {/* 7. Выход */}
        <button
          onClick={() => {
            sound.playTap();
            onOpenExit();
          }}
          className="group relative w-full overflow-hidden rounded-2xl bg-gradient-to-r from-rose-950/60 via-[#260e15] to-[#14060b] p-3 border border-rose-500/40 hover:border-rose-400 shadow-[0_0_12px_rgba(244,63,94,0.2)] hover:shadow-[0_0_18px_rgba(244,63,94,0.35)] active:scale-[0.98] transition-all text-left mt-0.5"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-rose-500/20 border border-rose-400/60 flex items-center justify-center text-rose-300 group-hover:scale-110 transition-transform shadow-[0_0_10px_rgba(244,63,94,0.4)]">
                <LogOut className="w-5 h-5 text-rose-300" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white group-hover:text-rose-200 font-heading">
                  Выход
                </h3>
                <p className="text-[11px] text-rose-300/80 font-medium">
                  Завершить работу и вернуться к заставке
                </p>
              </div>
            </div>
            <div className="w-6 h-6 rounded-lg bg-rose-900/40 border border-rose-500/30 flex items-center justify-center text-rose-300 group-hover:translate-x-0.5 transition-transform">
              <ChevronRight className="w-3.5 h-3.5" />
            </div>
          </div>
        </button>
      </div>
    </div>
  );
};
