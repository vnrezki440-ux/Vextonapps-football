import React from 'react';
import { ThemeAccent } from '../types/football';

interface AnimatedLoaderProps {
  size?: 'sm' | 'md' | 'lg';
  text?: string;
  accent?: ThemeAccent;
}

export const AnimatedLoader: React.FC<AnimatedLoaderProps> = ({
  size = 'md',
  text = 'Загрузка...',
  accent = 'cyan',
}) => {
  const sizeMap = {
    sm: 'w-8 h-8',
    md: 'w-16 h-16',
    lg: 'w-24 h-24',
  };

  const accentColor = {
    cyan: 'border-cyan-400 text-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.5)]',
    emerald: 'border-emerald-400 text-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.5)]',
    purple: 'border-purple-400 text-purple-400 shadow-[0_0_15px_rgba(168,85,247,0.5)]',
    amber: 'border-amber-400 text-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.5)]',
  }[accent];

  return (
    <div className="flex flex-col items-center justify-center gap-3 py-4" data-testid="animated-loader">
      <div className="relative flex items-center justify-center">
        {/* Outer rotating neon ring */}
        <div
          className={`rounded-full border-2 border-t-transparent border-b-transparent animate-spin ${sizeMap[size]} ${accentColor}`}
          style={{ animationDuration: '1.2s' }}
        />
        {/* Inner counter-rotating ring */}
        <div
          className={`absolute rounded-full border border-r-transparent border-l-transparent animate-spin opacity-75 ${
            size === 'lg' ? 'w-16 h-16' : size === 'md' ? 'w-10 h-10' : 'w-5 h-5'
          } ${accentColor}`}
          style={{ animationDirection: 'reverse', animationDuration: '0.8s' }}
        />
        {/* Center glowing football icon */}
        <div className="absolute flex items-center justify-center animate-pulse">
          <svg
            className={`${size === 'lg' ? 'w-8 h-8' : size === 'md' ? 'w-5 h-5' : 'w-3 h-3'} fill-current text-white`}
            viewBox="0 0 24 24"
          >
            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z" />
          </svg>
        </div>
      </div>
      {text && (
        <span className="text-xs uppercase tracking-widest text-slate-400 font-semibold animate-pulse">
          {text}
        </span>
      )}
    </div>
  );
};
