import React, { useState, useRef } from 'react';
import { Player, Position, PesStats } from '../types/football';
import {
  validatePlayer,
  COMMON_FLAGS,
  ALL_POSITIONS,
  AVAILABLE_SKILLS,
  PES_CATEGORIES,
  getPesRatingColor,
  getOrGeneratePesStats,
} from '../utils/squadUtils';
import { processImageFile } from '../utils/photoStorage';
import {
  X,
  Save,
  User,
  Upload,
  Image as ImageIcon,
  Check,
  Plus,
  Trash2,
  Sparkles,
  Shield,
  Zap,
} from 'lucide-react';
import { sound } from '../utils/audio';

interface PlayerEditorModalProps {
  playerToEdit: Player | null; // null if creating new player
  isOpen: boolean;
  onClose: () => void;
  onSave: (player: Player, photoDataUrl?: string) => void;
  nextAvailableNumber?: number;
  initialPhoto?: string | null;
}

export const PlayerEditorModal: React.FC<PlayerEditorModalProps> = ({
  playerToEdit,
  isOpen,
  onClose,
  onSave,
  nextAvailableNumber = 9,
  initialPhoto = null,
}) => {
  if (!isOpen) return null;

  const isEditing = Boolean(playerToEdit);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Form State
  const [name, setName] = useState(playerToEdit?.name || '');
  const [surname, setSurname] = useState(playerToEdit?.surname || '');
  const [number, setNumber] = useState<number>(playerToEdit?.number ?? nextAvailableNumber);
  const [position, setPosition] = useState<Position>(playerToEdit?.position || 'ST');
  const [secondaryPositions, setSecondaryPositions] = useState<Position[]>(
    playerToEdit?.secondaryPositions || []
  );
  const [rating, setRating] = useState<number>(playerToEdit?.rating || 85);
  const [skills, setSkills] = useState<string[]>(
    playerToEdit?.skills || ['Удар в касание', 'Дальний удар']
  );
  const [customSkillInput, setCustomSkillInput] = useState('');
  const [showCustomSkill, setShowCustomSkill] = useState(false);

  // Photo
  const [photoDataUrl, setPhotoDataUrl] = useState<string | null>(
    initialPhoto || playerToEdit?.photoUrl || null
  );
  const [photoError, setPhotoError] = useState<string | null>(null);

  // Preferred foot & nationality
  const [preferredFoot, setPreferredFoot] = useState<'Правая' | 'Левая' | 'Обе'>(
    playerToEdit?.preferredFoot || 'Правая'
  );
  const [nationality, setNationality] = useState(playerToEdit?.nationality || 'Россия');
  const [flag, setFlag] = useState(playerToEdit?.flag || '🇷🇺');
  const [isStarter, setIsStarter] = useState(playerToEdit?.isStarter ?? false);
  const [isCaptain, setIsCaptain] = useState(playerToEdit?.isCaptain ?? false);

  // 28 PES Stats
  const initialPes = getOrGeneratePesStats(playerToEdit || { rating, position });
  const [pesStats, setPesStats] = useState<PesStats>(initialPes);

  // Active Category Tab for PES stats
  const [activeCategoryTab, setActiveCategoryTab] = useState<string>(PES_CATEGORIES[0].title);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleCountryChange = (selectedName: string) => {
    const item = COMMON_FLAGS.find((c) => c.name === selectedName);
    if (item) {
      setNationality(item.name);
      setFlag(item.flag);
    }
  };

  const handlePhotoSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setPhotoError(null);
    try {
      sound.playTap();
      const processed = await processImageFile(file);
      setPhotoDataUrl(processed);
      sound.playSuccess();
    } catch (err: unknown) {
      setPhotoError(err instanceof Error ? err.message : 'Ошибка загрузки фото');
    }
  };

  const handleRemovePhoto = () => {
    sound.playTap();
    setPhotoDataUrl(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const toggleSecondaryPosition = (pos: Position) => {
    sound.playTap();
    if (pos === position) return; // Cannot be both primary and secondary
    if (secondaryPositions.includes(pos)) {
      setSecondaryPositions(secondaryPositions.filter((p) => p !== pos));
    } else {
      if (secondaryPositions.length >= 4) return; // Max 4 secondary
      setSecondaryPositions([...secondaryPositions, pos]);
    }
  };

  const toggleSkill = (skill: string) => {
    sound.playTap();
    if (skills.includes(skill)) {
      setSkills(skills.filter((s) => s !== skill));
    } else {
      setSkills([...skills, skill]);
    }
  };

  const handleAddCustomSkill = () => {
    if (!customSkillInput.trim()) return;
    sound.playTap();
    const clean = customSkillInput.trim();
    if (!skills.includes(clean)) {
      setSkills([...skills, clean]);
    }
    setCustomSkillInput('');
    setShowCustomSkill(false);
  };

  const updatePesStat = (key: keyof PesStats, val: number) => {
    const clamped = Math.min(99, Math.max(1, Math.round(val)));
    setPesStats((prev) => ({ ...prev, [key]: clamped }));
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const candidate: Partial<Player> = {
      name: name.trim(),
      surname: surname.trim(),
      number: Number(number),
      rating: Number(rating),
      pace: pesStats.speed,
      shooting: pesStats.finishing,
      passing: pesStats.lowPass,
      dribbling: pesStats.dribbling,
      defending: pesStats.defensiveProwess,
      physical: pesStats.stamina,
    };

    const validation = validatePlayer(candidate);
    if (!validation.valid) {
      setErrors(validation.errors);
      sound.playTap();
      return;
    }

    const playerId = playerToEdit ? playerToEdit.id : `p-${Date.now()}`;

    const playerResult: Player = {
      id: playerId,
      name: name.trim(),
      surname: surname.trim(),
      number: Number(number),
      position,
      secondaryPositions,
      skills,
      rating: Number(rating),
      photoUrl: photoDataUrl || undefined,
      pace: pesStats.speed,
      shooting: pesStats.finishing,
      passing: pesStats.lowPass,
      dribbling: pesStats.dribbling,
      defending: pesStats.defensiveProwess,
      physical: pesStats.stamina,
      preferredFoot,
      nationality,
      flag,
      isStarter,
      starterIndex: playerToEdit?.starterIndex,
      isCaptain,
      pesStats,
    };

    sound.playSuccess();
    onSave(playerResult, photoDataUrl || undefined);
    onClose();
  };

  const ratingColor = getPesRatingColor(rating);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-md animate-in fade-in duration-200 overflow-y-auto"
      onClick={onClose}
      data-testid="player-editor-modal"
    >
      <div
        className="relative w-full max-w-lg rounded-3xl bg-gradient-to-b from-[#0c1938] via-[#09122c] to-[#040817] border-2 border-cyan-500/40 p-4 sm:p-5 shadow-[0_0_40px_rgba(6,182,212,0.35)] text-white my-auto max-h-[94vh] overflow-y-auto no-scrollbar"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-slate-700/60 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-cyan-300">
              <User className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-black font-heading uppercase text-white">
                {isEditing ? 'Редактирование игрока' : 'Создание игрока PES'}
              </h3>
              <p className="text-[11px] text-cyan-400/80">
                Характеристики 1–99, фото, позиции и способности
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playTap();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-300 transition-colors"
            aria-label="Закрыть"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleFormSubmit} className="mt-4 flex flex-col gap-4">
          {/* Top Section: Photo Uploader & Large Rating Badge */}
          <div className="flex flex-col sm:flex-row items-center gap-4 p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800">
            {/* Photo Avatar Preview */}
            <div className="flex flex-col items-center">
              <div className="relative w-24 h-24 rounded-2xl bg-gradient-to-br from-slate-800 to-slate-900 border-2 border-cyan-400/50 overflow-hidden flex items-center justify-center shadow-[0_0_15px_rgba(6,182,212,0.3)]">
                {photoDataUrl ? (
                  <img
                    src={photoDataUrl}
                    alt="Предварительный просмотр"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="flex flex-col items-center text-slate-500 text-xs">
                    <ImageIcon className="w-8 h-8 text-cyan-400/60 mb-1" />
                    <span className="text-[9px] uppercase font-mono">Нет фото</span>
                  </div>
                )}

                {/* Rating badge overlay on photo corner */}
                <div
                  className={`absolute top-1 left-1 px-1.5 py-0.5 rounded text-[10px] font-black font-mono leading-none ${ratingColor.badgeClass}`}
                >
                  {rating}
                </div>
              </div>

              {/* Photo Actions */}
              <div className="flex items-center gap-1.5 mt-2">
                <input
                  type="file"
                  ref={fileInputRef}
                  accept="image/jpeg,image/png,image/webp"
                  onChange={handlePhotoSelect}
                  className="hidden"
                  id="player-photo-input"
                />
                <label
                  htmlFor="player-photo-input"
                  className="px-2.5 py-1 rounded-lg bg-cyan-600/30 hover:bg-cyan-600/50 text-cyan-300 border border-cyan-400/40 text-[11px] font-mono font-bold cursor-pointer flex items-center gap-1 active:scale-95 transition-all"
                >
                  <Upload className="w-3 h-3" />
                  <span>{photoDataUrl ? 'Сменить' : 'Выбрать из галереи'}</span>
                </label>

                {photoDataUrl && (
                  <button
                    type="button"
                    onClick={handleRemovePhoto}
                    className="p-1 rounded-lg bg-rose-950/60 text-rose-300 border border-rose-500/40 hover:bg-rose-900 text-[11px]"
                    title="Удалить фото"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                )}
              </div>
              <span className="text-[9px] text-slate-500 font-mono mt-0.5">JPG, PNG, WEBP</span>
              {photoError && <span className="text-[10px] text-red-400 mt-1">{photoError}</span>}
            </div>

            {/* Right: Large Overall Rating Display & Controller */}
            <div className="flex-1 w-full flex flex-col justify-center">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-mono uppercase tracking-wider text-slate-300 font-bold">
                  Общий рейтинг (OVR):
                </span>
                <span
                  className={`text-2xl font-black font-mono-stat px-2 py-0.5 rounded-lg border ${ratingColor.badgeClass} ${ratingColor.borderClass}`}
                >
                  {rating}
                </span>
              </div>

              {/* Slider 1 to 99 */}
              <input
                type="range"
                min={1}
                max={99}
                value={rating}
                onChange={(e) => setRating(Number(e.target.value))}
                className="w-full h-2 bg-slate-800 rounded-lg cursor-pointer accent-cyan-400"
              />

              <div className="flex justify-between items-center text-[10px] font-mono text-slate-400 mt-1.5">
                <span className="text-rose-400">1–59 (Красный)</span>
                <span className="text-amber-400">60–79 (Оранжевый)</span>
                <span className="text-emerald-400">80–99 (Зелёный)</span>
              </div>
            </div>
          </div>

          {/* Name & Surname */}
          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="text-[11px] font-mono text-slate-300 font-bold block mb-1">
                ИМЯ ИГРОКА
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => {
                  setName(e.target.value);
                  if (errors.name) setErrors({ ...errors, name: '' });
                }}
                placeholder="Например: Александр"
                className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 focus:border-cyan-400 text-sm text-white font-medium outline-none transition-all placeholder:text-slate-600"
              />
              {errors.name && <span className="text-[10px] text-red-400 mt-0.5 block">{errors.name}</span>}
            </div>

            <div>
              <label className="text-[11px] font-mono text-slate-300 font-bold block mb-1">
                ФАМИЛИЯ
              </label>
              <input
                type="text"
                value={surname}
                onChange={(e) => {
                  setSurname(e.target.value);
                  if (errors.surname) setErrors({ ...errors, surname: '' });
                }}
                placeholder="Например: Головин"
                className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 focus:border-cyan-400 text-sm text-white font-medium outline-none transition-all placeholder:text-slate-600"
              />
              {errors.surname && <span className="text-[10px] text-red-400 mt-0.5 block">{errors.surname}</span>}
            </div>
          </div>

          {/* Number, Primary Position, Nationality */}
          <div className="grid grid-cols-3 gap-2.5">
            <div>
              <label className="text-[11px] font-mono text-slate-300 font-bold block mb-1">
                НОМЕР (#)
              </label>
              <input
                type="number"
                min={1}
                max={99}
                value={number}
                onChange={(e) => setNumber(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 focus:border-cyan-400 text-sm text-white font-mono font-bold outline-none"
              />
            </div>

            <div>
              <label className="text-[11px] font-mono text-slate-300 font-bold block mb-1">
                ОСНОВНАЯ ПОЗИЦИЯ
              </label>
              <select
                value={position}
                onChange={(e) => {
                  const newPos = e.target.value as Position;
                  setPosition(newPos);
                  setSecondaryPositions(secondaryPositions.filter((p) => p !== newPos));
                }}
                className="w-full px-2 py-2 rounded-xl bg-slate-900 border border-slate-700 focus:border-cyan-400 text-sm text-cyan-300 font-mono font-bold outline-none"
              >
                {ALL_POSITIONS.map((pos) => (
                  <option key={pos} value={pos} className="bg-slate-900 text-white">
                    {pos}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[11px] font-mono text-slate-300 font-bold block mb-1">
                НАЦИОНАЛЬНОСТЬ
              </label>
              <select
                value={nationality}
                onChange={(e) => handleCountryChange(e.target.value)}
                className="w-full px-2 py-2 rounded-xl bg-slate-900 border border-slate-700 focus:border-cyan-400 text-xs text-white outline-none"
              >
                {COMMON_FLAGS.map((item) => (
                  <option key={item.name} value={item.name} className="bg-slate-900 text-white">
                    {item.flag} {item.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Secondary Positions (Multi-select) */}
          <div className="p-3 rounded-2xl bg-slate-950/70 border border-slate-800">
            <div className="flex items-center justify-between mb-2">
              <label className="text-[11px] font-mono text-slate-300 font-bold">
                ДОПОЛНИТЕЛЬНЫЕ ПОЗИЦИИ (выберите до 4):
              </label>
              <span className="text-[10px] text-cyan-400 font-mono">
                {secondaryPositions.length}/4
              </span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {ALL_POSITIONS.filter((p) => p !== position).map((pos) => {
                const isSelected = secondaryPositions.includes(pos);
                return (
                  <button
                    key={pos}
                    type="button"
                    onClick={() => toggleSecondaryPosition(pos)}
                    className={`px-2 py-1 rounded-lg text-[11px] font-mono font-bold transition-all ${
                      isSelected
                        ? 'bg-cyan-500/25 text-cyan-300 border border-cyan-400 shadow-sm'
                        : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-slate-200'
                    }`}
                  >
                    {pos} {isSelected && '✓'}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Individual Skills / Abilities (Индивидуальные способности) */}
          <div className="p-3 rounded-2xl bg-slate-950/70 border border-slate-800">
            <div className="flex items-center justify-between mb-2">
              <label className="text-[11px] font-mono text-slate-300 font-bold flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>ИНДИВИДУАЛЬНЫЕ СПОСОБНОСТИ ({skills.length}):</span>
              </label>
              <button
                type="button"
                onClick={() => setShowCustomSkill(!showCustomSkill)}
                className="text-[10px] text-cyan-400 hover:underline flex items-center gap-0.5"
              >
                <Plus className="w-3 h-3" /> Своя способность
              </button>
            </div>

            {/* Custom skill adder input */}
            {showCustomSkill && (
              <div className="flex gap-1.5 mb-2.5">
                <input
                  type="text"
                  value={customSkillInput}
                  onChange={(e) => setCustomSkillInput(e.target.value)}
                  placeholder="Например: Мастер дальних пасов"
                  className="flex-1 px-2.5 py-1 rounded-lg bg-slate-900 border border-cyan-500 text-xs text-white outline-none"
                />
                <button
                  type="button"
                  onClick={handleAddCustomSkill}
                  className="px-2.5 py-1 rounded-lg bg-cyan-600 text-white text-xs font-bold"
                >
                  Добавить
                </button>
              </div>
            )}

            {/* Chips of available skills */}
            <div className="flex flex-wrap gap-1.5 max-h-36 overflow-y-auto no-scrollbar">
              {AVAILABLE_SKILLS.map((sk) => {
                const isSelected = skills.includes(sk);
                return (
                  <button
                    key={sk}
                    type="button"
                    onClick={() => toggleSkill(sk)}
                    className={`px-2 py-1 rounded-lg text-[10px] font-medium transition-all ${
                      isSelected
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-400/60 shadow-sm'
                        : 'bg-slate-900/80 text-slate-400 border border-slate-800 hover:text-slate-300'
                    }`}
                  >
                    {sk} {isSelected && '✓'}
                  </button>
                );
              })}
            </div>
          </div>

          {/* PES Attributes (Характеристики в стиле PES) */}
          <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-mono uppercase tracking-wider text-cyan-400 font-bold">
                Характеристики в стиле PES (1–99):
              </span>
              <span className="text-[10px] font-mono text-slate-400">
                80+ Зеленый • 60+ Оранжевый • &lt;60 Красный
              </span>
            </div>

            {/* Category Tabs */}
            <div className="flex gap-1 overflow-x-auto pb-1 no-scrollbar mb-3">
              {PES_CATEGORIES.map((cat) => (
                <button
                  key={cat.title}
                  type="button"
                  onClick={() => {
                    sound.playTap();
                    setActiveCategoryTab(cat.title);
                  }}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-mono font-bold flex-shrink-0 transition-all ${
                    activeCategoryTab === cat.title
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/50 shadow-sm'
                      : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-slate-300'
                  }`}
                >
                  {cat.title}
                </button>
              ))}
            </div>

            {/* Active Category Attributes List */}
            {PES_CATEGORIES.filter((c) => c.title === activeCategoryTab).map((cat) => (
              <div key={cat.title} className="flex flex-col gap-2.5">
                {cat.stats.map((stat) => {
                  const val = pesStats[stat.key];
                  const color = getPesRatingColor(val);
                  return (
                    <div
                      key={stat.key}
                      className="flex items-center justify-between gap-3 p-2 rounded-xl bg-slate-900/70 border border-slate-800/80"
                    >
                      <div className="flex-1">
                        <div className="flex justify-between items-center mb-1">
                          <span className="text-xs text-slate-200 font-medium">
                            {stat.name}
                          </span>
                          <span
                            className={`text-xs font-mono font-black px-1.5 py-0.5 rounded ${color.badgeClass}`}
                          >
                            {val}
                          </span>
                        </div>
                        {/* Dual Slider & Input */}
                        <div className="flex items-center gap-2">
                          <input
                            type="range"
                            min={1}
                            max={99}
                            value={val}
                            onChange={(e) => updatePesStat(stat.key, Number(e.target.value))}
                            className="flex-1 h-1.5 bg-slate-800 rounded-lg cursor-pointer accent-cyan-400"
                          />
                          <input
                            type="number"
                            min={1}
                            max={99}
                            value={val}
                            onChange={(e) => updatePesStat(stat.key, Number(e.target.value))}
                            className="w-12 px-1.5 py-0.5 rounded bg-slate-950 border border-slate-700 text-center text-xs font-mono font-bold text-white outline-none"
                          />
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ))}
          </div>

          {/* Toggles: Starter & Captain */}
          <div className="grid grid-cols-2 gap-2">
            <label className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-900 border border-slate-800 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={isStarter}
                onChange={(e) => setIsStarter(e.target.checked)}
                className="w-4 h-4 rounded accent-cyan-500 cursor-pointer"
              />
              <span className="text-xs font-semibold text-slate-300">
                Стартовый состав
              </span>
            </label>

            <label className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-900 border border-slate-800 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={isCaptain}
                onChange={(e) => setIsCaptain(e.target.checked)}
                className="w-4 h-4 rounded accent-amber-500 cursor-pointer"
              />
              <span className="text-xs font-semibold text-amber-300">
                Капитан команды (C)
              </span>
            </label>
          </div>

          {/* Actions: Save & Cancel */}
          <div className="flex items-center gap-2 pt-2 border-t border-slate-800 mt-1">
            <button
              type="button"
              onClick={() => {
                sound.playTap();
                onClose();
              }}
              className="w-1/3 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs font-mono transition-colors"
            >
              Отмена
            </button>

            <button
              type="submit"
              className="w-2/3 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 via-teal-600 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 font-black text-xs font-mono flex items-center justify-center gap-1.5 shadow-[0_0_15px_rgba(16,185,129,0.4)] active:scale-95 transition-all"
            >
              <Save className="w-4 h-4 text-slate-950" />
              <span>{isEditing ? 'Сохранить изменения' : 'Добавить игрока'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
