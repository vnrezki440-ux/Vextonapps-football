import React, { useState } from 'react';
import {
  Headphones,
  ChevronDown,
  ChevronUp,
  MessageSquare,
  Mail,
  Send,
  HelpCircle,
  ExternalLink,
  CheckCircle2,
  Cpu,
} from 'lucide-react';
import { sound } from '../utils/audio';

const FAQ_LIST = [
  {
    q: 'Как расставлять игроков и менять тактическую схему?',
    a: 'Перейдите в раздел «Показать состав». В верхнем правом углу нажмите на плашку схемы (например, 4-3-3) и выберите нужную расстановку (4-4-2, 3-5-2, 4-2-3-1, 5-3-2). Чтобы поменять игроков местами, нажмите на игрока на поле и выберите другого игрока или используйте кнопку быстрого обмена (⇄).',
  },
  {
    q: 'Как рассчитывается показатель сыгранности (Chemistry)?',
    a: 'Сыгранность зависит от трех ключевых факторов: 1) соответствие позиции игрока тактическому слоту (например, ST в атаке дает максимум очков); 2) синергия по национальностям (два и более игрока из одной страны дают бонус связки); 3) наличие назначенного капитана (C) и заполненность всех 11 слотов.',
  },
  {
    q: 'Где сохраняются созданные и отредактированные игроки?',
    a: 'Все данные сохраняются локально на вашем устройстве в браузере (LocalStorage). Никаких внешних серверов не требуется — ваши данные полностью приватны и доступны в автономном режиме.',
  },
  {
    q: 'Как назначить капитана команды?',
    a: 'Нажмите на любого игрока на поле или в разделе «Данные». В открывшейся карточке нажмите кнопку «Сделать (C)». Капитан получает золотую повязку и дает бонус к сыгранности всего клуба.',
  },
  {
    q: 'Как сделать резервную копию или перенести состав?',
    a: 'Откройте раздел «Данные» в главном меню и нажмите кнопку «JSON». Вы можете скопировать текстовый код состава в буфер обмена или вставить его на другом телефоне через импорт.',
  },
];

export const SupportView: React.FC = () => {
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);
  const [ticketSubject, setTicketSubject] = useState('');
  const [ticketMessage, setTicketMessage] = useState('');
  const [ticketSent, setTicketSent] = useState(false);

  const toggleFaq = (idx: number) => {
    sound.playTap();
    setOpenFaqIndex(openFaqIndex === idx ? null : idx);
  };

  const handleSendTicket = (e: React.FormEvent) => {
    e.preventDefault();
    if (!ticketSubject.trim() || !ticketMessage.trim()) return;

    sound.playSuccess();
    setTicketSent(true);
    setTimeout(() => {
      setTicketSubject('');
      setTicketMessage('');
      setTicketSent(false);
    }, 4000);
  };

  return (
    <div className="w-full max-w-md mx-auto px-4 py-4 pb-24 select-none" data-testid="support-view">
      {/* Support Hero */}
      <div className="glass-panel rounded-2xl p-4 border border-blue-500/30 mb-4 shadow-[0_0_20px_rgba(59,130,246,0.15)] flex items-center gap-3">
        <div className="w-12 h-12 rounded-xl bg-blue-500/20 border border-blue-400/40 flex items-center justify-center text-blue-300 shadow-[0_0_12px_rgba(59,130,246,0.4)]">
          <Headphones className="w-6 h-6" />
        </div>
        <div>
          <h2 className="text-base font-bold text-white font-heading uppercase">
            Центр поддержки VextonApps
          </h2>
          <p className="text-[11px] text-blue-300/80">
            База знаний, инструкции и круглосуточная помощь
          </p>
        </div>
      </div>

      {/* FAQ Accordion */}
      <div className="mb-5">
        <span className="text-xs font-mono uppercase tracking-wider text-cyan-400 font-bold block mb-2 px-1">
          Часто задаваемые вопросы:
        </span>

        <div className="flex flex-col gap-2">
          {FAQ_LIST.map((item, idx) => {
            const isOpen = openFaqIndex === idx;
            return (
              <div
                key={idx}
                className="glass-panel rounded-xl border border-slate-800 overflow-hidden transition-all"
              >
                <button
                  onClick={() => toggleFaq(idx)}
                  className="w-full px-3.5 py-3 flex items-center justify-between text-left gap-2 text-xs font-bold text-slate-200 hover:text-cyan-300 transition-colors"
                >
                  <span className="flex items-center gap-2">
                    <HelpCircle className="w-3.5 h-3.5 text-cyan-400 flex-shrink-0" />
                    <span>{item.q}</span>
                  </span>
                  {isOpen ? (
                    <ChevronUp className="w-4 h-4 text-cyan-400 flex-shrink-0" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-slate-400 flex-shrink-0" />
                  )}
                </button>

                {isOpen && (
                  <div className="px-3.5 pb-3 pt-1 text-[11px] text-slate-300 leading-relaxed border-t border-slate-800/60 bg-black/30">
                    {item.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Direct Ticket Submission */}
      <div className="glass-panel rounded-2xl p-4 border border-slate-800 mb-4">
        <div className="flex items-center gap-2 mb-2">
          <MessageSquare className="w-4 h-4 text-blue-400" />
          <h3 className="text-xs font-bold text-white font-heading uppercase">
            Задать вопрос разработчику
          </h3>
        </div>

        {ticketSent ? (
          <div className="py-4 text-center flex flex-col items-center">
            <CheckCircle2 className="w-8 h-8 text-emerald-400 mb-1.5" />
            <span className="text-xs font-bold text-emerald-300">
              Сообщение отправлено!
            </span>
            <span className="text-[10px] text-slate-400 mt-0.5">
              Служба поддержки ответит в ближайшее время.
            </span>
          </div>
        ) : (
          <form onSubmit={handleSendTicket} className="flex flex-col gap-2.5">
            <input
              type="text"
              value={ticketSubject}
              onChange={(e) => setTicketSubject(e.target.value)}
              placeholder="Тема обращения (например, идея по тактике)"
              className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white outline-none focus:border-blue-400"
            />
            <textarea
              value={ticketMessage}
              onChange={(e) => setTicketMessage(e.target.value)}
              rows={3}
              placeholder="Текст вашего сообщения..."
              className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white outline-none focus:border-blue-400"
            />
            <button
              type="submit"
              className="py-2 px-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-mono font-bold flex items-center justify-center gap-1.5 shadow-[0_0_12px_rgba(59,130,246,0.3)] active:scale-95 transition-all"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Отправить тикет</span>
            </button>
          </form>
        )}
      </div>

      {/* Direct Contact Channels & Diagnostics */}
      <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/80 flex flex-col gap-2 text-[11px] text-slate-400 font-mono">
        <div className="flex items-center justify-between">
          <span className="flex items-center gap-1.5">
            <Mail className="w-3.5 h-3.5 text-cyan-400" />
            <span>Email:</span>
          </span>
          <span className="text-slate-300">support@vextonapps.io</span>
        </div>
        <div className="flex items-center justify-between">
          <span className="flex items-center gap-1.5">
            <Cpu className="w-3.5 h-3.5 text-emerald-400" />
            <span>Версия движка:</span>
          </span>
          <span className="text-cyan-300">v2.4.0-neon (Build 2026.11)</span>
        </div>
      </div>
    </div>
  );
};
