import React, { useState } from 'react';
import {
  AppSettings,
  FormationKey,
  ThemeAccent,
  PitchStyle,
} from '../types/football';
import { FORMATIONS } from '../utils/squadUtils';
import {
  Settings,
  Volume2,
  VolumeX,
  Vibrate,
  Palette,
  Shield,
  Layers,
  RotateCcw,
  Check,
  CheckCircle,
  Download,
  FolderArchive,
  FileCode,
} from 'lucide-react';
import { sound } from '../utils/audio';
import { downloadFullZipBlob } from '../utils/projectZipData';

interface SettingsViewProps {
  settings: AppSettings;
  onUpdateSettings: (newSettings: AppSettings) => void;
  onResetSquad: () => void;
  playersCount: number;
  onOpenFilesModal?: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  onUpdateSettings,
  onResetSquad,
  playersCount,
  onOpenFilesModal,
}) => {
  const [teamNameInput, setTeamNameInput] = useState(settings.teamName);
  const [savedBadge, setSavedBadge] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);

  const handleUpdate = (partial: Partial<AppSettings>) => {
    sound.playTap();
    const updated = { ...settings, ...partial };
    onUpdateSettings(updated);
    setSavedBadge(true);
    setTimeout(() => setSavedBadge(false), 1500);
  };

  const handleSaveTeamName = (e: React.FormEvent) => {
    e.preventDefault();
    if (!teamNameInput.trim()) return;
    handleUpdate({ teamName: teamNameInput.trim() });
    sound.playSuccess();
  };

  return (
    <div className="w-full max-w-md mx-auto px-4 py-4 pb-24 select-none" data-testid="settings-view">
      {/* Header */}
      <div className="glass-panel rounded-2xl p-4 border border-purple-500/30 mb-4 shadow-[0_0_20px_rgba(168,85,247,0.15)] flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-500/20 border border-purple-400/40 flex items-center justify-center text-purple-300 shadow-[0_0_12px_rgba(168,85,247,0.4)]">
            <Settings className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white font-heading uppercase">
              Настройки приложения
            </h2>
            <p className="text-[11px] text-purple-300/80">
              Тактика, тема, звук и параметры VextonApps
            </p>
          </div>
        </div>

        {savedBadge && (
          <span className="flex items-center gap-1 text-[11px] font-mono text-emerald-400 font-bold bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/30 animate-pulse">
            <Check className="w-3 h-3" />
            Сохранено
          </span>
        )}
      </div>

      {/* Club Name Form */}
      <div className="glass-panel rounded-2xl p-4 border border-slate-800 mb-4">
        <span className="text-xs font-mono uppercase tracking-wider text-cyan-400 font-bold block mb-2">
          Название футбольного клуба:
        </span>
        <form onSubmit={handleSaveTeamName} className="flex gap-2">
          <input
            type="text"
            value={teamNameInput}
            onChange={(e) => setTeamNameInput(e.target.value)}
            className="flex-1 px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white font-bold outline-none focus:border-cyan-400"
          />
          <button
            type="submit"
            className="px-3.5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-mono font-bold text-xs shadow-[0_0_10px_rgba(6,182,212,0.3)] active:scale-95 transition-all"
          >
            Сохранить
          </button>
        </form>
      </div>

      {/* Formation Selector */}
      <div className="glass-panel rounded-2xl p-4 border border-slate-800 mb-4">
        <span className="text-xs font-mono uppercase tracking-wider text-cyan-400 font-bold block mb-2.5">
          Тактическая схема по умолчанию:
        </span>
        <div className="grid grid-cols-2 gap-2">
          {(['4-3-3', '4-4-2', '3-5-2', '4-2-3-1', '5-3-2'] as FormationKey[]).map((fKey) => {
            const form = FORMATIONS[fKey];
            const isSelected = settings.formation === fKey;
            return (
              <button
                key={fKey}
                onClick={() => handleUpdate({ formation: fKey })}
                className={`p-2.5 rounded-xl border text-left transition-all ${
                  isSelected
                    ? 'bg-cyan-500/20 border-cyan-400 text-white shadow-[0_0_12px_rgba(6,182,212,0.3)]'
                    : 'bg-slate-900/60 border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between mb-0.5">
                  <span className="font-mono font-black text-sm">{fKey}</span>
                  {isSelected && <span className="text-[10px] text-cyan-400 font-bold">✓ АКТИВНО</span>}
                </div>
                <span className="text-[10px] text-slate-400 block truncate">
                  {form.name}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Neon Color Accent */}
      <div className="glass-panel rounded-2xl p-4 border border-slate-800 mb-4">
        <span className="text-xs font-mono uppercase tracking-wider text-cyan-400 font-bold block mb-2.5">
          Неоновый акцент интерфейса:
        </span>
        <div className="grid grid-cols-4 gap-2">
          {[
            { key: 'cyan', label: 'Cyan', color: 'bg-cyan-400', glow: 'shadow-[0_0_12px_rgba(6,182,212,0.6)]' },
            { key: 'emerald', label: 'Emerald', color: 'bg-emerald-400', glow: 'shadow-[0_0_12px_rgba(16,185,129,0.6)]' },
            { key: 'purple', label: 'Purple', color: 'bg-purple-400', glow: 'shadow-[0_0_12px_rgba(168,85,247,0.6)]' },
            { key: 'amber', label: 'Amber', color: 'bg-amber-400', glow: 'shadow-[0_0_12px_rgba(245,158,11,0.6)]' },
          ].map((theme) => {
            const isSelected = settings.accent === theme.key;
            return (
              <button
                key={theme.key}
                onClick={() => handleUpdate({ accent: theme.key as ThemeAccent })}
                className={`py-2 px-2 rounded-xl border flex flex-col items-center gap-1.5 transition-all ${
                  isSelected
                    ? 'border-white bg-white/10 shadow-md'
                    : 'border-slate-800 bg-slate-900/40 hover:border-slate-700'
                }`}
              >
                <div className={`w-4 h-4 rounded-full ${theme.color} ${isSelected ? theme.glow : ''}`} />
                <span className="text-[10px] font-mono font-bold text-slate-300">
                  {theme.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Pitch Theme */}
      <div className="glass-panel rounded-2xl p-4 border border-slate-800 mb-4">
        <span className="text-xs font-mono uppercase tracking-wider text-cyan-400 font-bold block mb-2.5">
          Стиль футбольного поля:
        </span>
        <div className="grid grid-cols-3 gap-2">
          {[
            { key: 'neon-dark', label: 'Темный неон' },
            { key: 'classic', label: 'Классика' },
            { key: 'cyber-turf', label: 'Кибер газон' },
          ].map((style) => {
            const isSelected = settings.pitchStyle === style.key;
            return (
              <button
                key={style.key}
                onClick={() => handleUpdate({ pitchStyle: style.key as PitchStyle })}
                className={`py-2 px-1 rounded-xl border text-center transition-all ${
                  isSelected
                    ? 'bg-cyan-500/20 border-cyan-400 text-cyan-200 shadow-[0_0_10px_rgba(6,182,212,0.3)]'
                    : 'bg-slate-900/60 border-slate-800 text-slate-400'
                }`}
              >
                <span className="text-[11px] font-mono font-bold block">{style.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Audio & Haptic Toggles */}
      <div className="glass-panel rounded-2xl p-4 border border-slate-800 mb-4 flex flex-col gap-3">
        <span className="text-xs font-mono uppercase tracking-wider text-cyan-400 font-bold block">
          Звук и тактильный отклик:
        </span>

        {/* Sound toggle */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            {settings.soundEnabled ? (
              <Volume2 className="w-4 h-4 text-cyan-400" />
            ) : (
              <VolumeX className="w-4 h-4 text-slate-500" />
            )}
            <span className="text-xs text-slate-200 font-medium">Звуковые эффекты свистка и клика</span>
          </div>
          <button
            onClick={() => handleUpdate({ soundEnabled: !settings.soundEnabled })}
            className={`w-11 h-6 rounded-full transition-colors relative ${
              settings.soundEnabled ? 'bg-cyan-500' : 'bg-slate-800'
            }`}
          >
            <div
              className={`w-5 h-5 rounded-full bg-white shadow-md absolute top-0.5 transition-transform ${
                settings.soundEnabled ? 'right-0.5' : 'left-0.5'
              }`}
            />
          </button>
        </div>

        {/* Vibration toggle */}
        <div className="flex items-center justify-between border-t border-slate-800 pt-3">
          <div className="flex items-center gap-2">
            <Vibrate className="w-4 h-4 text-cyan-400" />
            <span className="text-xs text-slate-200 font-medium">Вибрация Android при действиях</span>
          </div>
          <button
            onClick={() => handleUpdate({ vibrationEnabled: !settings.vibrationEnabled })}
            className={`w-11 h-6 rounded-full transition-colors relative ${
              settings.vibrationEnabled ? 'bg-cyan-500' : 'bg-slate-800'
            }`}
          >
            <div
              className={`w-5 h-5 rounded-full bg-white shadow-md absolute top-0.5 transition-transform ${
                settings.vibrationEnabled ? 'right-0.5' : 'left-0.5'
              }`}
            />
          </button>
        </div>
      </div>

      {/* Android APK & Offline Source ZIP */}
      <div className="glass-panel rounded-2xl p-4 border border-cyan-500/50 mb-4 shadow-[0_0_20px_rgba(6,182,212,0.25)]">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-mono uppercase tracking-wider text-cyan-400 font-bold block">
            Сборка Android APK:
          </span>
          <span className="text-[10px] font-mono text-emerald-400 font-bold">
            0.47 MB • ZIP
          </span>
        </div>
        <p className="text-[11px] text-slate-300 mb-3 leading-relaxed">
          Полный ZIP-архив с кодом, нативной платформой Android, Gradle, Capacitor и инструкцией по сборке APK.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          <button
            onClick={() => {
              sound.playSuccess();
              downloadFullZipBlob();
            }}
            className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-cyan-400 via-teal-400 to-emerald-400 hover:from-cyan-300 hover:to-emerald-300 text-slate-950 font-black text-xs font-mono flex items-center justify-center gap-1.5 shadow-[0_0_15px_rgba(6,182,212,0.4)] active:scale-95 transition-all cursor-pointer"
          >
            <Download className="w-4 h-4 text-slate-950" />
            <span>Скачать весь ZIP</span>
          </button>

          <button
            onClick={() => {
              sound.playTap();
              onOpenFilesModal?.();
            }}
            className="w-full py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-cyan-500/40 font-black text-xs font-mono flex items-center justify-center gap-1.5 active:scale-95 transition-all cursor-pointer"
          >
            <FileCode className="w-4 h-4 text-cyan-400" />
            <span>Каталог файлов</span>
          </button>
        </div>
      </div>

      {/* Storage and Data Reset */}
      <div className="glass-panel rounded-2xl p-4 border border-slate-800 mb-4">
        <span className="text-xs font-mono uppercase tracking-wider text-rose-400 font-bold block mb-2">
          Локальное хранилище данных:
        </span>
        <p className="text-[11px] text-slate-400 mb-3">
          Все ваши {playersCount} игроков хранятся автономно на этом мобильном устройстве (LocalStorage).
        </p>

        {confirmReset ? (
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                sound.playWhistle();
                onResetSquad();
                setConfirmReset(false);
              }}
              className="flex-1 py-2 px-3 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-mono font-bold shadow-[0_0_15px_rgba(239,68,68,0.5)] active:scale-95 transition-all"
            >
              Подтвердить сброс
            </button>
            <button
              onClick={() => setConfirmReset(false)}
              className="py-2 px-3 rounded-xl bg-slate-800 text-slate-300 text-xs font-mono"
            >
              Отмена
            </button>
          </div>
        ) : (
          <button
            onClick={() => {
              sound.playTap();
              setConfirmReset(true);
            }}
            className="w-full py-2 px-3 rounded-xl bg-red-950/40 hover:bg-red-900/60 border border-red-500/40 text-red-300 text-xs font-mono font-bold flex items-center justify-center gap-2 active:scale-95 transition-all"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Сбросить состав к заводским настройкам</span>
          </button>
        )}
      </div>
    </div>
  );
};
