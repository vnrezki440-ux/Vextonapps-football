import React from 'react';
import { AppView, ThemeAccent } from '../types/football';
import {
  Menu,
  LayoutGrid,
  Database,
  Edit3,
  Settings,
} from 'lucide-react';
import { sound } from '../utils/audio';

interface BottomNavBarProps {
  currentView: AppView;
  onNavigate: (view: AppView) => void;
  accent: ThemeAccent;
}

export const BottomNavBar: React.FC<BottomNavBarProps> = ({
  currentView,
  onNavigate,
  accent,
}) => {
  const tabs: { view: AppView; label: string; icon: React.ReactNode }[] = [
    { view: 'menu', label: 'Меню', icon: <Menu className="w-5 h-5" /> },
    { view: 'pitch', label: 'Поле', icon: <LayoutGrid className="w-5 h-5" /> },
    { view: 'data', label: 'Данные', icon: <Database className="w-5 h-5" /> },
    { view: 'editor', label: 'Игроки', icon: <Edit3 className="w-5 h-5" /> },
    { view: 'settings', label: 'Опции', icon: <Settings className="w-5 h-5" /> },
  ];

  const getAccentStyles = () => {
    switch (accent) {
      case 'emerald':
        return 'text-emerald-400 border-emerald-400/50 shadow-[0_0_12px_rgba(16,185,129,0.5)]';
      case 'purple':
        return 'text-purple-400 border-purple-400/50 shadow-[0_0_12px_rgba(168,85,247,0.5)]';
      case 'amber':
        return 'text-amber-400 border-amber-400/50 shadow-[0_0_12px_rgba(245,158,11,0.5)]';
      case 'cyan':
      default:
        return 'text-cyan-400 border-cyan-400/50 shadow-[0_0_12px_rgba(6,182,212,0.5)]';
    }
  };

  return (
    <nav
      className="fixed bottom-0 left-0 right-0 z-40 bg-[#070b1a]/95 backdrop-blur-xl border-t border-slate-800/80 px-2 py-1.5 select-none"
      data-testid="bottom-nav-bar"
    >
      <div className="max-w-md mx-auto flex items-center justify-around">
        {tabs.map((tab) => {
          const isActive = currentView === tab.view;
          return (
            <button
              key={tab.view}
              onClick={() => {
                sound.playTap();
                onNavigate(tab.view);
              }}
              className={`flex flex-col items-center justify-center py-1 px-3 rounded-2xl transition-all relative ${
                isActive
                  ? `bg-white/5 ${getAccentStyles()}`
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              aria-label={tab.label}
            >
              <div className={`${isActive ? 'scale-110' : ''} transition-transform`}>
                {tab.icon}
              </div>
              <span className="text-[10px] font-mono font-bold mt-0.5 tracking-tight">
                {tab.label}
              </span>
              {isActive && (
                <div className="w-1 h-1 rounded-full bg-cyan-400 absolute -bottom-0.5" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
