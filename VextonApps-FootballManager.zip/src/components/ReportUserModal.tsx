import React, { useState } from 'react';
import {
  Flag,
  X,
  Send,
  AlertTriangle,
  CheckCircle,
  UploadCloud,
  FileCheck,
} from 'lucide-react';
import { sound } from '../utils/audio';

interface ReportUserModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ReportUserModal: React.FC<ReportUserModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const [targetUser, setTargetUser] = useState('');
  const [category, setCategory] = useState('Читерство / Сторонний софт');
  const [description, setDescription] = useState('');
  const [hasAttachment, setHasAttachment] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [ticketId, setTicketId] = useState<string | null>(null);
  const [error, setError] = useState('');

  const categories = [
    'Читерство / Сторонний софт',
    'Неспортивное поведение',
    'Оскорбления и нецензурная брань',
    'Неприемлемое название клуба/игрока',
    'Абуз игровых механик',
    'Спам / Мошенничество',
    'Другое нарушение',
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!targetUser.trim() || targetUser.trim().length < 3) {
      setError('Укажите никнейм или ID нарушителя (минимум 3 символа)');
      sound.playTap();
      return;
    }
    if (!description.trim() || description.trim().length < 5) {
      setError('Опишите суть инцидента подробнее (минимум 5 символов)');
      sound.playTap();
      return;
    }

    setError('');
    setIsSubmitting(true);
    sound.playTap();

    setTimeout(() => {
      const generatedTicket = `VX-${Math.floor(1000 + Math.random() * 9000)}`;
      setTicketId(generatedTicket);
      setIsSubmitting(false);
      sound.playSuccess();
    }, 700);
  };

  const handleResetAndClose = () => {
    sound.playTap();
    setTicketId(null);
    setTargetUser('');
    setDescription('');
    setHasAttachment(false);
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-md animate-in fade-in"
      onClick={handleResetAndClose}
      data-testid="report-user-modal"
    >
      <div
        className="relative w-full max-w-md rounded-3xl bg-gradient-to-b from-[#1c120c] via-[#140b08] to-[#0a0504] border-2 border-amber-500/40 p-5 shadow-[0_0_40px_rgba(245,158,11,0.25)] text-white overflow-hidden my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={handleResetAndClose}
          className="absolute top-4 right-4 w-8 h-8 rounded-full bg-slate-800/80 hover:bg-slate-700 flex items-center justify-center text-slate-300 transition-colors"
          aria-label="Закрыть"
        >
          <X className="w-4 h-4" />
        </button>

        {!ticketId ? (
          <div>
            {/* Header */}
            <div className="flex items-center gap-3 border-b border-amber-500/20 pb-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-300 shadow-[0_0_12px_rgba(245,158,11,0.3)]">
                <Flag className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-black font-heading uppercase text-white">
                  Сообщить о пользователе
                </h3>
                <p className="text-[11px] text-amber-300/80">
                  Служба модерации и честной игры VextonApps
                </p>
              </div>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="mt-4 flex flex-col gap-3">
              <div>
                <label className="text-[11px] font-mono text-slate-300 font-bold block mb-1">
                  НИКНЕЙМ ИЛИ ID ПОЛЬЗОВАТЕЛЯ
                </label>
                <input
                  type="text"
                  value={targetUser}
                  onChange={(e) => setTargetUser(e.target.value)}
                  placeholder="Например: Player_777 или ID #4920"
                  className="w-full px-3 py-2 rounded-xl bg-black/60 border border-slate-700 focus:border-amber-400 text-sm text-white outline-none"
                />
              </div>

              <div>
                <label className="text-[11px] font-mono text-slate-300 font-bold block mb-1">
                  КАТЕГОРИЯ НАРУШЕНИЯ
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-black/60 border border-slate-700 focus:border-amber-400 text-xs text-amber-300 outline-none"
                >
                  {categories.map((c) => (
                    <option key={c} value={c} className="bg-slate-900 text-white">
                      {c}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[11px] font-mono text-slate-300 font-bold block mb-1">
                  ПОДРОБНОСТИ НАРУШЕНИЯ
                </label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={3}
                  placeholder="Опишите, что именно произошло во время матча или формирования команды..."
                  className="w-full px-3 py-2 rounded-xl bg-black/60 border border-slate-700 focus:border-amber-400 text-xs text-white outline-none"
                />
              </div>

              {/* Mock screenshot attachment */}
              <div>
                <button
                  type="button"
                  onClick={() => {
                    sound.playTap();
                    setHasAttachment(!hasAttachment);
                  }}
                  className={`w-full py-2 px-3 rounded-xl border text-xs font-mono flex items-center justify-center gap-2 transition-all ${
                    hasAttachment
                      ? 'bg-amber-950/60 border-amber-400/60 text-amber-300'
                      : 'bg-black/40 border-slate-700 text-slate-400 hover:text-slate-300'
                  }`}
                >
                  {hasAttachment ? (
                    <>
                      <FileCheck className="w-4 h-4 text-emerald-400" />
                      <span>Скриншот экрана прикреплён (screenshot.png)</span>
                    </>
                  ) : (
                    <>
                      <UploadCloud className="w-4 h-4" />
                      <span>Прикрепить скриншот нарушения (опционально)</span>
                    </>
                  )}
                </button>
              </div>

              {error && (
                <div className="flex items-center gap-1.5 text-xs text-red-400 bg-red-950/40 p-2 rounded-lg border border-red-500/30">
                  <AlertTriangle className="w-4 h-4 flex-shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              {/* Submit Buttons */}
              <div className="flex items-center gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={handleResetAndClose}
                  className="w-1/3 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-mono font-bold"
                >
                  Отмена
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-2/3 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 via-orange-600 to-amber-700 text-slate-950 font-bold text-xs font-mono flex items-center justify-center gap-1.5 shadow-[0_0_15px_rgba(245,158,11,0.4)] active:scale-95 transition-all"
                >
                  <Send className="w-3.5 h-3.5 text-slate-950" />
                  <span>{isSubmitting ? 'Отправка...' : 'Отправить жалобу'}</span>
                </button>
              </div>
            </form>
          </div>
        ) : (
          /* Confirmation Screen */
          <div className="text-center py-4 flex flex-col items-center">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 border-2 border-emerald-400 flex items-center justify-center text-emerald-400 mb-3 shadow-[0_0_20px_rgba(16,185,129,0.4)] animate-bounce">
              <CheckCircle className="w-8 h-8" />
            </div>

            <h3 className="text-xl font-bold font-heading uppercase text-white">
              Жалоба зарегистрирована!
            </h3>
            <p className="text-xs text-slate-300 mt-1 max-w-xs">
              Номер вашего обращения:{' '}
              <span className="font-mono font-bold text-amber-400">{ticketId}</span>
            </p>
            <div className="mt-3 p-3 rounded-xl bg-black/60 border border-slate-800 text-[11px] text-slate-400 text-left w-full space-y-1">
              <div>
                <span className="text-slate-500">Нарушитель:</span> {targetUser}
              </div>
              <div>
                <span className="text-slate-500">Причина:</span> {category}
              </div>
              <div>
                <span className="text-slate-500">Статус:</span> В очереди модерации
              </div>
            </div>

            <button
              onClick={handleResetAndClose}
              className="mt-5 w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs font-mono shadow-[0_0_15px_rgba(16,185,129,0.3)] active:scale-95 transition-all"
            >
              Вернуться в приложение
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
