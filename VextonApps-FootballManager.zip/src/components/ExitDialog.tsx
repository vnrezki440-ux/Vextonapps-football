import React from 'react';
import { LogOut, RotateCcw, X, ShieldAlert, Check } from 'lucide-react';
import { sound } from '../utils/audio';

interface ExitDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onRestartSplash: () => void;
}

export const ExitDialog: React.FC<ExitDialogProps> = ({
  isOpen,
  onClose,
  onRestartSplash,
}) => {
  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in"
      onClick={onClose}
      data-testid="exit-dialog"
    >
      <div
        className="relative w-full max-w-sm rounded-3xl bg-gradient-to-b from-[#1c0d12] via-[#14080c] to-[#0a0305] border-2 border-rose-500/40 p-5 shadow-[0_0_40px_rgba(244,63,94,0.3)] text-white text-center overflow-hidden my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Glow ambient */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-40 h-40 bg-rose-500/15 rounded-full blur-2xl pointer-events-none" />

        {/* Exit Icon */}
        <div className="mx-auto w-14 h-14 rounded-2xl bg-rose-500/20 border border-rose-400/50 flex items-center justify-center text-rose-400 mb-3 shadow-[0_0_20px_rgba(244,63,94,0.4)]">
          <LogOut className="w-7 h-7" />
        </div>

        <h3 className="text-xl font-black font-heading uppercase text-white">
          Выход из VextonApps
        </h3>
        <p className="text-xs text-slate-300 mt-1.5 leading-relaxed">
          Все ваши игроки, расстановка и тактические настройки надёжно сохранены в локальной памяти устройства.
        </p>

        <div className="mt-5 flex flex-col gap-2.5">
          {/* Restart Splash Button */}
          <button
            onClick={() => {
              sound.playWhistle();
              onRestartSplash();
            }}
            className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-rose-600 via-red-600 to-rose-700 hover:from-rose-500 hover:to-rose-600 text-white font-mono font-bold text-xs flex items-center justify-center gap-2 shadow-[0_0_15px_rgba(244,63,94,0.4)] active:scale-95 transition-all"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Перезапустить заставку (3 сек)</span>
          </button>

          {/* Cancel button */}
          <button
            onClick={() => {
              sound.playTap();
              onClose();
            }}
            className="w-full py-2.5 px-4 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 font-mono font-bold text-xs transition-colors"
          >
            Остаться в приложении
          </button>
        </div>
      </div>
    </div>
  );
};
