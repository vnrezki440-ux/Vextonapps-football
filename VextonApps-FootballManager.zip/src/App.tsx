import React, { useState, useEffect } from 'react';
import {
  Player,
  AppView,
  AppSettings,
  FormationKey,
} from './types/football';
import {
  loadSquadFromStorage,
  saveSquadToStorage,
  loadSettingsFromStorage,
  saveSettingsToStorage,
  resetSquadToDefault,
  swapPlayers,
} from './utils/squadUtils';
import {
  getAllPlayerPhotos,
  savePlayerPhoto,
  deletePlayerPhoto,
} from './utils/photoStorage';
import { sound } from './utils/audio';
import { SplashScreen } from './components/SplashScreen';
import { HeaderNav } from './components/HeaderNav';
import { MainMenu } from './components/MainMenu';
import { VerticalPitch } from './components/VerticalPitch';
import { DataView } from './components/DataView';
import { EditorView } from './components/EditorView';
import { SettingsView } from './components/SettingsView';
import { SupportView } from './components/SupportView';
import { ReportUserModal } from './components/ReportUserModal';
import { PlayerCardModal } from './components/PlayerCardModal';
import { PlayerEditorModal } from './components/PlayerEditorModal';
import { ExitDialog } from './components/ExitDialog';
import { ProjectFilesModal } from './components/ProjectFilesModal';
import { BottomNavBar } from './components/BottomNavBar';
import { Check } from 'lucide-react';

export default function App() {
  // Check if ?autostart=1 is present in URL
  const [hasAutoStart] = useState(() => {
    if (typeof window === 'undefined') return false;
    return new URLSearchParams(window.location.search).get('autostart') === '1';
  });

  const [currentView, setCurrentView] = useState<AppView>(() => {
    return hasAutoStart ? 'menu' : 'splash';
  });

  const [players, setPlayers] = useState<Player[]>(() => loadSquadFromStorage());
  const [settings, setSettings] = useState<AppSettings>(() => loadSettingsFromStorage());
  const [photos, setPhotos] = useState<Record<string, string>>({});

  // Modals state
  const [selectedPlayer, setSelectedPlayer] = useState<Player | null>(null);
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [playerToEdit, setPlayerToEdit] = useState<Player | null>(null);
  const [isExitOpen, setIsExitOpen] = useState(false);
  const [isReportOpen, setIsReportOpen] = useState(false);
  const [isFilesModalOpen, setIsFilesModalOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Load photos from IndexedDB on initial mount
  useEffect(() => {
    getAllPlayerPhotos().then((stored) => {
      if (stored && Object.keys(stored).length > 0) {
        setPhotos(stored);
      }
    });
  }, []);

  // Sync audio with settings
  useEffect(() => {
    sound.enabled = settings.soundEnabled;
  }, [settings.soundEnabled]);

  // Persist squad on change to localStorage
  useEffect(() => {
    saveSquadToStorage(players);
  }, [players]);

  // Persist settings on change to localStorage
  useEffect(() => {
    saveSettingsToStorage(settings);
  }, [settings]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 2500);
  };

  const handleNavigate = (view: AppView) => {
    if (view === 'report') {
      setIsReportOpen(true);
    } else {
      setCurrentView(view);
    }
  };

  const handleSelectPlayer = (player: Player) => {
    setSelectedPlayer(player);
  };

  const handleAddNewPlayer = () => {
    setPlayerToEdit(null);
    setIsEditorOpen(true);
  };

  const handleEditPlayer = (player: Player) => {
    setSelectedPlayer(null);
    setPlayerToEdit(player);
    setIsEditorOpen(true);
  };

  const handleSavePlayer = async (savedPlayer: Player, photoDataUrl?: string) => {
    if (photoDataUrl) {
      try {
        await savePlayerPhoto(savedPlayer.id, photoDataUrl);
        setPhotos((prev) => ({ ...prev, [savedPlayer.id]: photoDataUrl }));
        savedPlayer.photoUrl = photoDataUrl;
      } catch (err) {
        console.warn('Failed to save photo to IndexedDB:', err);
      }
    }

    setPlayers((prev) => {
      const exists = prev.some((p) => p.id === savedPlayer.id);
      if (exists) {
        return prev.map((p) => (p.id === savedPlayer.id ? savedPlayer : p));
      } else {
        // If set as starter, assign next available starterIndex
        let assignedStarterIndex = savedPlayer.starterIndex;
        if (savedPlayer.isStarter && assignedStarterIndex === undefined) {
          const usedIndexes = prev.filter((p) => p.isStarter).map((p) => p.starterIndex ?? 0);
          for (let i = 0; i < 11; i++) {
            if (!usedIndexes.includes(i)) {
              assignedStarterIndex = i;
              break;
            }
          }
        }
        return [...prev, { ...savedPlayer, starterIndex: assignedStarterIndex }];
      }
    });

    showToast(`Игрок ${savedPlayer.surname} сохранён!`);
  };

  const handleDeletePlayer = async (id: string) => {
    const playerToDelete = players.find((p) => p.id === id);
    try {
      await deletePlayerPhoto(id);
      setPhotos((prev) => {
        const copy = { ...prev };
        delete copy[id];
        return copy;
      });
    } catch {
      // ignore
    }

    setPlayers((prev) => prev.filter((p) => p.id !== id));
    setSelectedPlayer(null);
    showToast(`Игрок ${playerToDelete?.surname || ''} удалён.`);
  };

  const handleSwapPlayers = (id1: string, id2: string) => {
    setPlayers((prev) => swapPlayers(prev, id1, id2));
    const p1 = players.find((p) => p.id === id1);
    const p2 = players.find((p) => p.id === id2);
    if (p1 && p2) {
      showToast(`Обмен позициями: ${p1.surname} ⇄ ${p2.surname}`);
    }
  };

  const handleToggleCaptain = (id: string) => {
    setPlayers((prev) =>
      prev.map((p) => ({
        ...p,
        isCaptain: p.id === id ? !p.isCaptain : false, // Only 1 captain
      }))
    );
    setSelectedPlayer((prev) => (prev?.id === id ? { ...prev, isCaptain: !prev.isCaptain } : prev));
    showToast('Капитан команды обновлён!');
  };

  const handleToggleStarter = (id: string) => {
    const targetPlayer = players.find((p) => p.id === id);
    if (!targetPlayer) return;

    if (!targetPlayer.isStarter) {
      const starters = players.filter((p) => p.isStarter);
      if (starters.length >= 11) {
        showToast('В стартовом составе уже 11 игроков! Сначала переместите кого-то в запас.');
        return;
      }
      const usedSlots = new Set(starters.map((p) => p.starterIndex ?? 0));
      let freeSlot = 0;
      for (let i = 0; i < 11; i++) {
        if (!usedSlots.has(i)) {
          freeSlot = i;
          break;
        }
      }
      setPlayers((prev) =>
        prev.map((p) => (p.id === id ? { ...p, isStarter: true, starterIndex: freeSlot } : p))
      );
      setSelectedPlayer((prev) => (prev?.id === id ? { ...prev, isStarter: true } : prev));
      showToast('Игрок переведён в стартовый состав!');
    } else {
      setPlayers((prev) =>
        prev.map((p) => (p.id === id ? { ...p, isStarter: false, starterIndex: undefined } : p))
      );
      setSelectedPlayer((prev) => (prev?.id === id ? { ...prev, isStarter: false } : prev));
      showToast('Игрок переведён в запас.');
    }
  };

  const handleImportSquad = (imported: Player[]) => {
    setPlayers(imported);
    showToast('Состав успешно импортирован!');
  };

  const handleResetSquad = () => {
    const defaults = resetSquadToDefault();
    setPlayers(defaults);
    showToast('Состав сброшен к исходным игрокам!');
  };

  const handleRestartSplash = () => {
    setIsExitOpen(false);
    setCurrentView('splash');
  };

  return (
    <div className="min-h-screen bg-[#050814] text-slate-100 flex justify-center">
      {/* Mobile Screen Shell container (fluid on mobile, phone-aspect framed on desktop) */}
      <div className="w-full max-w-md min-h-screen flex flex-col bg-[#070b1a] relative shadow-2xl overflow-x-hidden">
        {/* Splash Screen */}
        {currentView === 'splash' ? (
          <SplashScreen
            onFinish={() => setCurrentView('menu')}
            autoSkip={hasAutoStart}
          />
        ) : (
          <>
            {/* Header / Android Status Bar */}
            <HeaderNav
              currentView={currentView}
              onNavigate={handleNavigate}
              accent={settings.accent}
              soundEnabled={settings.soundEnabled}
              onToggleSound={() =>
                setSettings((prev) => ({ ...prev, soundEnabled: !prev.soundEnabled }))
              }
              teamName={settings.teamName}
            />

            {/* Main Content by Current View */}
            <main className="flex-1 overflow-y-auto no-scrollbar">
              {currentView === 'menu' && (
                <MainMenu
                  onNavigate={handleNavigate}
                  players={players}
                  formation={settings.formation}
                  teamName={settings.teamName}
                  accent={settings.accent}
                  onOpenExit={() => setIsExitOpen(true)}
                />
              )}

              {currentView === 'pitch' && (
                <VerticalPitch
                  players={players}
                  formation={settings.formation}
                  onChangeFormation={(f: FormationKey) =>
                    setSettings((prev) => ({ ...prev, formation: f }))
                  }
                  pitchStyle={settings.pitchStyle}
                  accent={settings.accent}
                  onSelectPlayer={handleSelectPlayer}
                  onAddNewPlayer={handleAddNewPlayer}
                  onSwapPlayers={handleSwapPlayers}
                  photos={photos}
                />
              )}

              {currentView === 'data' && (
                <DataView
                  players={players}
                  onSelectPlayer={handleSelectPlayer}
                  onEditPlayer={handleEditPlayer}
                  onDeletePlayer={handleDeletePlayer}
                  onAddNewPlayer={handleAddNewPlayer}
                  onImportSquad={handleImportSquad}
                  onResetSquad={handleResetSquad}
                  onOpenFilesModal={() => setIsFilesModalOpen(true)}
                />
              )}

              {currentView === 'editor' && (
                <EditorView
                  players={players}
                  photos={photos}
                  onAddNewPlayer={handleAddNewPlayer}
                  onEditPlayer={handleEditPlayer}
                  onSelectPlayer={handleSelectPlayer}
                  onDeletePlayer={handleDeletePlayer}
                />
              )}

              {currentView === 'settings' && (
                <SettingsView
                  settings={settings}
                  onUpdateSettings={setSettings}
                  onResetSquad={handleResetSquad}
                  playersCount={players.length}
                  onOpenFilesModal={() => setIsFilesModalOpen(true)}
                />
              )}

              {currentView === 'support' && <SupportView />}
            </main>

            {/* Bottom Nav Bar */}
            <BottomNavBar
              currentView={currentView}
              onNavigate={handleNavigate}
              accent={settings.accent}
            />
          </>
        )}

        {/* Floating Toast Notification */}
        {toastMessage && (
          <div className="fixed top-14 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-xl bg-cyan-950/90 border border-cyan-400 text-cyan-200 text-xs font-mono font-bold shadow-[0_0_20px_rgba(6,182,212,0.5)] flex items-center gap-2 animate-in fade-in slide-in-from-top-2">
            <Check className="w-3.5 h-3.5 text-cyan-400" />
            <span>{toastMessage}</span>
          </div>
        )}

        {/* Player Details Card Modal */}
        <PlayerCardModal
          player={selectedPlayer}
          onClose={() => setSelectedPlayer(null)}
          onEdit={handleEditPlayer}
          onDelete={handleDeletePlayer}
          onToggleCaptain={handleToggleCaptain}
          onToggleStarter={handleToggleStarter}
          photoUrl={selectedPlayer ? photos[selectedPlayer.id] || selectedPlayer.photoUrl : null}
        />

        {/* Player Creator / Editor Modal */}
        <PlayerEditorModal
          playerToEdit={playerToEdit}
          isOpen={isEditorOpen}
          onClose={() => {
            setIsEditorOpen(false);
            setPlayerToEdit(null);
          }}
          onSave={handleSavePlayer}
          nextAvailableNumber={(() => {
            const used = new Set(players.map((p) => p.number));
            for (let i = 1; i <= 99; i++) {
              if (!used.has(i)) return i;
            }
            return 99;
          })()}
          initialPhoto={playerToEdit ? photos[playerToEdit.id] || playerToEdit.photoUrl : null}
        />

        {/* Report User Modal */}
        <ReportUserModal
          isOpen={isReportOpen}
          onClose={() => setIsReportOpen(false)}
        />

        {/* Exit App Confirmation Dialog */}
        <ExitDialog
          isOpen={isExitOpen}
          onClose={() => setIsExitOpen(false)}
          onRestartSplash={handleRestartSplash}
        />

        {/* Project Files & Single-file Downloads Modal */}
        <ProjectFilesModal
          isOpen={isFilesModalOpen}
          onClose={() => setIsFilesModalOpen(false)}
        />
      </div>
    </div>
  );
}
