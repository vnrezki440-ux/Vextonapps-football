export type Position =
  | 'GK'
  | 'LB'
  | 'CB'
  | 'RB'
  | 'LWB'
  | 'RWB'
  | 'CDM'
  | 'CM'
  | 'CAM'
  | 'LM'
  | 'RM'
  | 'LW'
  | 'RW'
  | 'ST'
  | 'CF';

export type PositionCategory = 'GK' | 'DEF' | 'MID' | 'ATT';

export interface PlayerStats {
  pace: number; // PAC
  shooting: number; // SHO
  passing: number; // PAS
  dribbling: number; // DRI
  defending: number; // DEF
  physical: number; // PHY
}

// Full PES-style 28 attributes across 5 categories
export interface PesStats {
  // Атака и техника
  attackingProwess: number; // Умение атаковать
  ballControl: number; // Контроль мяча
  dribbling: number; // Дриблинг
  lowPass: number; // Пас низом
  loftedPass: number; // Пас навесом
  finishing: number; // Реализация
  placeKicking: number; // Удары по воротам
  swerve: number; // Закручивание
  header: number; // Игра головой

  // Защита
  defensiveProwess: number; // Умение защищаться
  ballWinning: number; // Отбор мяча
  aggression: number; // Агрессивность

  // Физические способности
  kickingPower: number; // Сила удара
  speed: number; // Скорость
  explosivePower: number; // Взрывная скорость
  bodyControl: number; // Устойчивость
  physicalContact: number; // Устойчивость при толчках
  jump: number; // Прыгучесть
  stamina: number; // Выносливость

  // Вратарские способности
  goalkeeping: number; // Вратарский навык
  catching: number; // Ловля мяча
  clearing: number; // Вынос мяча
  reflexes: number; // Реакция
  coverage: number; // Зона отражения мяча

  // Дополнительные способности
  weakFootUsage: number; // Частота использования слабой ноги (1-99)
  weakFootAccuracy: number; // Точность слабой ноги (1-99)
  form: number; // Физическая форма (1-99)
  injuryResistance: number; // Травмоустойчивость (1-99)
}

export interface Player extends PlayerStats {
  id: string;
  name: string;
  surname: string;
  number: number; // 1-99
  position: Position;
  secondaryPositions?: Position[]; // Дополнительные позиции
  skills?: string[]; // Индивидуальные способности
  rating: number; // 1-99 (Общий рейтинг в стиле PES)
  photoUrl?: string; // IndexedDB photo or data URL
  preferredFoot: 'Правая' | 'Левая' | 'Обе';
  nationality: string;
  flag: string;
  isStarter: boolean;
  starterIndex?: number; // 0 to 10 on the pitch
  isCaptain?: boolean;
  avatarColor?: string;
  pesStats?: PesStats;
}

export type FormationKey = '4-3-3' | '4-4-2' | '3-5-2' | '4-2-3-1' | '5-3-2';

export interface PitchSlot {
  index: number; // 0-10
  code: Position;
  label: string;
  x: number; // 0-100 (%) from left
  y: number; // 0-100 (%) from top (0 = attacking goal, 100 = defending goal)
  category: PositionCategory;
}

export interface FormationConfig {
  key: FormationKey;
  name: string;
  description: string;
  slots: PitchSlot[];
}

export type ThemeAccent = 'cyan' | 'emerald' | 'purple' | 'amber';
export type PitchStyle = 'classic' | 'neon-dark' | 'cyber-turf';

export type AppView =
  | 'splash'
  | 'menu'
  | 'pitch'
  | 'data'
  | 'editor'
  | 'settings'
  | 'support'
  | 'report';

export interface ReportUserData {
  targetUser: string;
  reason: string;
  description: string;
  category: string;
  timestamp: string;
}

export interface AppSettings {
  formation: FormationKey;
  accent: ThemeAccent;
  pitchStyle: PitchStyle;
  soundEnabled: boolean;
  vibrationEnabled: boolean;
  showChemistryLines: boolean;
  teamName: string;
}
