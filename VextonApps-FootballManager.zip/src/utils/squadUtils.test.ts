import test from 'node:test';
import assert from 'node:assert/strict';
import {
  INITIAL_PLAYERS,
  FORMATIONS,
  calculateAverageRating,
  calculateChemistry,
  calculateSquadStats,
  validatePlayer,
  swapPlayers,
  getStarters,
  getBenchPlayers,
} from './squadUtils';
import { Player, FormationKey } from '../types/football';

test('formations config contains valid 11 tactical slots for all formations', () => {
  const formationKeys: FormationKey[] = ['4-3-3', '4-4-2', '3-5-2', '4-2-3-1', '5-3-2'];
  for (const key of formationKeys) {
    const formation = FORMATIONS[key];
    assert.ok(formation, `Formation ${key} should exist`);
    assert.equal(formation.slots.length, 11, `Formation ${key} must have exactly 11 slots`);

    const indexes = formation.slots.map((s) => s.index).sort((a, b) => a - b);
    assert.deepEqual(indexes, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]);

    // Goalkeeper must always be in slot 0 at bottom
    const gkSlot = formation.slots[0];
    assert.equal(gkSlot.code, 'GK');
    assert.equal(gkSlot.category, 'GK');
    assert.ok(gkSlot.y > 80, 'GK should be positioned near bottom of pitch');
  }
});

test('calculateAverageRating accurately computes mean OVR for starters', () => {
  const starters = getStarters(INITIAL_PLAYERS);
  assert.equal(starters.length, 11);

  const avg = calculateAverageRating(INITIAL_PLAYERS);
  assert.ok(avg >= 85 && avg <= 95, `Average rating should be around 89, got ${avg}`);

  // Test empty array
  assert.equal(calculateAverageRating([]), 0);
});

test('calculateChemistry produces reasonable score between 0 and 100', () => {
  const chemistry = calculateChemistry(INITIAL_PLAYERS, '4-3-3');
  assert.ok(chemistry >= 50 && chemistry <= 100, `Chemistry score should be high for dream squad, got ${chemistry}`);

  // Empty team should have 0 chemistry
  assert.equal(calculateChemistry([], '4-3-3'), 0);
});

test('calculateSquadStats calculates valid team average stats', () => {
  const stats = calculateSquadStats(INITIAL_PLAYERS);
  assert.ok(stats.pace >= 40 && stats.pace <= 99);
  assert.ok(stats.shooting >= 40 && stats.shooting <= 99);
  assert.ok(stats.passing >= 40 && stats.passing <= 99);
  assert.ok(stats.dribbling >= 40 && stats.dribbling <= 99);
  assert.ok(stats.defending >= 40 && stats.defending <= 99);
  assert.ok(stats.physical >= 40 && stats.physical <= 99);
});

test('validatePlayer enforces minimum lengths and ranges (1-99)', () => {
  const validPlayer: Partial<Player> = {
    name: 'Лионель',
    surname: 'Месси',
    number: 10,
    rating: 94,
    pace: 85,
    shooting: 92,
    passing: 91,
    dribbling: 95,
    defending: 38,
    physical: 68,
  };
  const validResult = validatePlayer(validPlayer);
  assert.equal(validResult.valid, true);
  assert.equal(Object.keys(validResult.errors).length, 0);

  // Test rating of 1 is valid (1-99 range)
  const lowRated: Partial<Player> = {
    ...validPlayer,
    rating: 1,
  };
  assert.equal(validatePlayer(lowRated).valid, true);

  const invalidPlayer: Partial<Player> = {
    name: 'A',
    surname: '',
    number: 150,
    rating: 120,
    pace: 5,
  };
  const invalidResult = validatePlayer(invalidPlayer);
  assert.equal(invalidResult.valid, false);
  assert.ok(invalidResult.errors.name, 'Short name should error');
  assert.ok(invalidResult.errors.surname, 'Empty surname should error');
  assert.ok(invalidResult.errors.number, 'Out-of-range number should error');
  assert.ok(invalidResult.errors.rating, 'Out-of-range rating should error');
});

test('getPesRatingColor accurately maps 80-99 to green, 60-79 to orange, 1-59 to red', () => {
  import('./squadUtils').then(({ getPesRatingColor }) => {
    assert.equal(getPesRatingColor(99).tier, 'green');
    assert.equal(getPesRatingColor(80).tier, 'green');
    assert.equal(getPesRatingColor(79).tier, 'orange');
    assert.equal(getPesRatingColor(60).tier, 'orange');
    assert.equal(getPesRatingColor(59).tier, 'red');
    assert.equal(getPesRatingColor(1).tier, 'red');
  });
});

test('getOrGeneratePesStats generates all 28 PES attributes within 1-99', () => {
  import('./squadUtils').then(({ getOrGeneratePesStats, PES_CATEGORIES }) => {
    const pes = getOrGeneratePesStats({ rating: 88, position: 'ST', pace: 90, shooting: 89 });
    let totalAttributes = 0;
    PES_CATEGORIES.forEach((cat) => {
      cat.stats.forEach((st) => {
        totalAttributes++;
        const val = pes[st.key];
        assert.ok(val >= 1 && val <= 99, `Stat ${st.key} must be in 1-99, got ${val}`);
      });
    });
    assert.equal(totalAttributes, 28, 'PES attributes count must be 28');
  });
});

test('swapPlayers cleanly swaps starter positions between starter and bench', () => {
  const starter = INITIAL_PLAYERS.find((p) => p.isStarter)!;
  const bench = INITIAL_PLAYERS.find((p) => !p.isStarter)!;

  const originalStarterIdx = starter.starterIndex;
  const swapped = swapPlayers(INITIAL_PLAYERS, starter.id, bench.id);

  const newStarter = swapped.find((p) => p.id === bench.id)!;
  const newBench = swapped.find((p) => p.id === starter.id)!;

  assert.equal(newStarter.isStarter, true);
  assert.equal(newStarter.starterIndex, originalStarterIdx);
  assert.equal(newBench.isStarter, false);
});
