import {
  Player,
  PlayerStats,
  PesStats,
  Position,
  PositionCategory,
  FormationKey,
  FormationConfig,
  AppSettings,
} from '../types/football';

export const ALL_POSITIONS: Position[] = [
  'GK',
  'LB',
  'CB',
  'RB',
  'LWB',
  'RWB',
  'CDM',
  'CM',
  'CAM',
  'LM',
  'RM',
  'LW',
  'RW',
  'ST',
  'CF',
];

export const AVAILABLE_SKILLS: string[] = [
  'Финт Марселя',
  'Эластико',
  'Удар ножницами',
  'Удар в касание',
  'Дальний удар',
  'Ныряющий удар',
  'Пас в одно касание',
  'Разрезающий пас',
  'Навес с подкруткой',
  'Ввод мяча рукой',
  'Игра на перехвате',
  'Опека',
  'Акробатическое спасение',
  'Лидерство',
  'Капитан',
  'Пенальтист',
  'Суперзапас',
  'Боевой дух',
];

export interface PesStatMeta {
  key: keyof PesStats;
  name: string;
}

export interface PesCategoryMeta {
  title: string;
  stats: PesStatMeta[];
}

export const PES_CATEGORIES: PesCategoryMeta[] = [
  {
    title: 'Атака и техника',
    stats: [
      { key: 'attackingProwess', name: 'Умение атаковать' },
      { key: 'ballControl', name: 'Контроль мяча' },
      { key: 'dribbling', name: 'Дриблинг' },
      { key: 'lowPass', name: 'Пас низом' },
      { key: 'loftedPass', name: 'Пас навесом' },
      { key: 'finishing', name: 'Реализация' },
      { key: 'placeKicking', name: 'Удары по воротам' },
      { key: 'swerve', name: 'Закручивание' },
      { key: 'header', name: 'Игра головой' },
    ],
  },
  {
    title: 'Защита',
    stats: [
      { key: 'defensiveProwess', name: 'Умение защищаться' },
      { key: 'ballWinning', name: 'Отбор мяча' },
      { key: 'aggression', name: 'Агрессивность' },
    ],
  },
  {
    title: 'Физические способности',
    stats: [
      { key: 'kickingPower', name: 'Сила удара' },
      { key: 'speed', name: 'Скорость' },
      { key: 'explosivePower', name: 'Взрывная скорость' },
      { key: 'bodyControl', name: 'Устойчивость' },
      { key: 'physicalContact', name: 'Устойчивость при толчках' },
      { key: 'jump', name: 'Прыгучесть' },
      { key: 'stamina', name: 'Выносливость' },
    ],
  },
  {
    title: 'Вратарские способности',
    stats: [
      { key: 'goalkeeping', name: 'Вратарский навык' },
      { key: 'catching', name: 'Ловля мяча' },
      { key: 'clearing', name: 'Вынос мяча' },
      { key: 'reflexes', name: 'Реакция' },
      { key: 'coverage', name: 'Зона отражения мяча' },
    ],
  },
  {
    title: 'Дополнительные способности',
    stats: [
      { key: 'weakFootUsage', name: 'Частота использования слабой ноги' },
      { key: 'weakFootAccuracy', name: 'Точность слабой ноги' },
      { key: 'form', name: 'Физическая форма' },
      { key: 'injuryResistance', name: 'Травмоустойчивость' },
    ],
  },
];

// PES Color tiers:
// 80–99 — зеленый цвет
// 60–79 — оранжевый цвет
// 1–59 — красный цвет
export function getPesRatingColor(value: number): {
  tier: 'green' | 'orange' | 'red';
  textClass: string;
  badgeClass: string;
  borderClass: string;
  bgClass: string;
  hex: string;
} {
  const v = Math.min(99, Math.max(1, Math.round(value)));
  if (v >= 80) {
    return {
      tier: 'green',
      textClass: 'text-emerald-400',
      badgeClass: 'bg-emerald-500 text-slate-950 font-black shadow-[0_0_12px_rgba(16,185,129,0.5)]',
      borderClass: 'border-emerald-500',
      bgClass: 'bg-emerald-950/70',
      hex: '#22c55e',
    };
  }
  if (v >= 60) {
    return {
      tier: 'orange',
      textClass: 'text-amber-400',
      badgeClass: 'bg-amber-500 text-slate-950 font-black shadow-[0_0_12px_rgba(245,158,11,0.5)]',
      borderClass: 'border-amber-500',
      bgClass: 'bg-amber-950/70',
      hex: '#f59e0b',
    };
  }
  return {
    tier: 'red',
    textClass: 'text-rose-400',
    badgeClass: 'bg-rose-500 text-white font-black shadow-[0_0_12px_rgba(244,63,94,0.5)]',
    borderClass: 'border-rose-500',
    bgClass: 'bg-rose-950/70',
    hex: '#ef4444',
  };
}

export function getOrGeneratePesStats(player: Partial<Player>): PesStats {
  if (player.pesStats) {
    return { ...player.pesStats };
  }

  const baseOvr = player.rating || 80;
  const isGk = player.position === 'GK';
  const isDef = ['CB', 'LB', 'RB', 'LWB', 'RWB'].includes(player.position || '');
  const isAtt = ['ST', 'CF', 'LW', 'RW'].includes(player.position || '');

  const clampStat = (val: number) => Math.min(99, Math.max(1, Math.round(val)));

  return {
    // Атака и техника
    attackingProwess: clampStat(isAtt ? baseOvr : isGk ? 40 : baseOvr - 8),
    ballControl: clampStat(player.dribbling || baseOvr - 2),
    dribbling: clampStat(player.dribbling || baseOvr - 4),
    lowPass: clampStat(player.passing || baseOvr - 5),
    loftedPass: clampStat(player.passing ? player.passing - 2 : baseOvr - 6),
    finishing: clampStat(isAtt ? (player.shooting || baseOvr) : isGk ? 35 : baseOvr - 12),
    placeKicking: clampStat(player.passing ? player.passing - 5 : baseOvr - 10),
    swerve: clampStat(player.passing ? player.passing - 4 : baseOvr - 8),
    header: clampStat(isDef || isAtt ? baseOvr - 3 : baseOvr - 12),

    // Защита
    defensiveProwess: clampStat(isDef ? baseOvr : isGk ? 50 : player.defending || 65),
    ballWinning: clampStat(isDef ? baseOvr - 2 : player.defending || 62),
    aggression: clampStat(player.physical || baseOvr - 6),

    // Физические способности
    kickingPower: clampStat(player.shooting || baseOvr - 3),
    speed: clampStat(player.pace || baseOvr),
    explosivePower: clampStat(player.pace ? player.pace - 2 : baseOvr - 2),
    bodyControl: clampStat(player.dribbling || baseOvr - 4),
    physicalContact: clampStat(player.physical || baseOvr - 5),
    jump: clampStat(player.physical ? player.physical + 2 : baseOvr - 2),
    stamina: clampStat(isGk ? 65 : player.physical || baseOvr - 2),

    // Вратарские способности
    goalkeeping: clampStat(isGk ? baseOvr : 40),
    catching: clampStat(isGk ? baseOvr - 2 : 40),
    clearing: clampStat(isGk ? baseOvr - 3 : 40),
    reflexes: clampStat(isGk ? baseOvr + 1 : 45),
    coverage: clampStat(isGk ? baseOvr - 1 : 40),

    // Дополнительные способности
    weakFootUsage: clampStat(player.preferredFoot === 'Обе' ? 88 : 65),
    weakFootAccuracy: clampStat(player.preferredFoot === 'Обе' ? 88 : 68),
    form: clampStat(75),
    injuryResistance: clampStat(78),
  };
}

export const POSITION_CATEGORIES: Record<Position, PositionCategory> = {
  GK: 'GK',
  LB: 'DEF',
  CB: 'DEF',
  RB: 'DEF',
  LWB: 'DEF',
  RWB: 'DEF',
  CDM: 'MID',
  CM: 'MID',
  CAM: 'MID',
  LM: 'MID',
  RM: 'MID',
  LW: 'ATT',
  RW: 'ATT',
  ST: 'ATT',
  CF: 'ATT',
};

// Formations with 11 tactical slots on a vertical pitch (x: 0-100% from left, y: 0-100% from top)
// y: 0 = Opponent Goal (top attack), y: 100 = Own Goal (bottom goalkeeper)
export const FORMATIONS: Record<FormationKey, FormationConfig> = {
  '4-3-3': {
    key: '4-3-3',
    name: '4-3-3 Атакующая',
    description: 'Классическая сбалансированная схема с быстрыми вингерами и центральным нападающим',
    slots: [
      { index: 0, code: 'GK', label: 'ВРТ', x: 50, y: 91, category: 'GK' },
      { index: 1, code: 'LB', label: 'ЛЗ', x: 15, y: 74, category: 'DEF' },
      { index: 2, code: 'CB', label: 'ЦЗ', x: 38, y: 76, category: 'DEF' },
      { index: 3, code: 'CB', label: 'ЦЗ', x: 62, y: 76, category: 'DEF' },
      { index: 4, code: 'RB', label: 'ПЗ', x: 85, y: 74, category: 'DEF' },
      { index: 5, code: 'CM', label: 'ЦП', x: 28, y: 52, category: 'MID' },
      { index: 6, code: 'CDM', label: 'ОПЗ', x: 50, y: 58, category: 'MID' },
      { index: 7, code: 'CM', label: 'ЦП', x: 72, y: 52, category: 'MID' },
      { index: 8, code: 'LW', label: 'ЛВ', x: 20, y: 22, category: 'ATT' },
      { index: 9, code: 'ST', label: 'ФРВ', x: 50, y: 16, category: 'ATT' },
      { index: 10, code: 'RW', label: 'ПВ', x: 80, y: 22, category: 'ATT' },
    ],
  },
  '4-4-2': {
    key: '4-4-2',
    name: '4-4-2 Классическая',
    description: 'Традиционная схема с двумя форвардами и плотной полузащитой',
    slots: [
      { index: 0, code: 'GK', label: 'ВРТ', x: 50, y: 91, category: 'GK' },
      { index: 1, code: 'LB', label: 'ЛЗ', x: 15, y: 74, category: 'DEF' },
      { index: 2, code: 'CB', label: 'ЦЗ', x: 38, y: 76, category: 'DEF' },
      { index: 3, code: 'CB', label: 'ЦЗ', x: 62, y: 76, category: 'DEF' },
      { index: 4, code: 'RB', label: 'ПЗ', x: 85, y: 74, category: 'DEF' },
      { index: 5, code: 'LM', label: 'ЛП', x: 16, y: 48, category: 'MID' },
      { index: 6, code: 'CM', label: 'ЦП', x: 38, y: 52, category: 'MID' },
      { index: 7, code: 'CM', label: 'ЦП', x: 62, y: 52, category: 'MID' },
      { index: 8, code: 'RM', label: 'ПП', x: 84, y: 48, category: 'MID' },
      { index: 9, code: 'ST', label: 'ФРВ', x: 36, y: 18, category: 'ATT' },
      { index: 10, code: 'ST', label: 'ФРВ', x: 64, y: 18, category: 'ATT' },
    ],
  },
  '3-5-2': {
    key: '3-5-2',
    name: '3-5-2 Контроль мяча',
    description: 'Схема с тремя центральными защитниками и тотальным контролем центра поля',
    slots: [
      { index: 0, code: 'GK', label: 'ВРТ', x: 50, y: 91, category: 'GK' },
      { index: 1, code: 'CB', label: 'ЛЦЗ', x: 26, y: 76, category: 'DEF' },
      { index: 2, code: 'CB', label: 'ЦЗ', x: 50, y: 78, category: 'DEF' },
      { index: 3, code: 'CB', label: 'ПЦЗ', x: 74, y: 76, category: 'DEF' },
      { index: 4, code: 'LWB', label: 'ЛКЗ', x: 14, y: 52, category: 'MID' },
      { index: 5, code: 'CDM', label: 'ОПЗ', x: 36, y: 57, category: 'MID' },
      { index: 6, code: 'CAM', label: 'АПЗ', x: 50, y: 42, category: 'MID' },
      { index: 7, code: 'CDM', label: 'ОПЗ', x: 64, y: 57, category: 'MID' },
      { index: 8, code: 'RWB', label: 'ПКЗ', x: 86, y: 52, category: 'MID' },
      { index: 9, code: 'ST', label: 'ФРВ', x: 36, y: 18, category: 'ATT' },
      { index: 10, code: 'CF', label: 'ЦФ', x: 64, y: 18, category: 'ATT' },
    ],
  },
  '4-2-3-1': {
    key: '4-2-3-1',
    name: '4-2-3-1 Тактическая',
    description: 'Два опорных полузащитника и плеймейкер под единственным нападающим',
    slots: [
      { index: 0, code: 'GK', label: 'ВРТ', x: 50, y: 91, category: 'GK' },
      { index: 1, code: 'LB', label: 'ЛЗ', x: 15, y: 74, category: 'DEF' },
      { index: 2, code: 'CB', label: 'ЦЗ', x: 38, y: 76, category: 'DEF' },
      { index: 3, code: 'CB', label: 'ЦЗ', x: 62, y: 76, category: 'DEF' },
      { index: 4, code: 'RB', label: 'ПЗ', x: 85, y: 74, category: 'DEF' },
      { index: 5, code: 'CDM', label: 'ОПЗ', x: 36, y: 60, category: 'MID' },
      { index: 6, code: 'CDM', label: 'ОПЗ', x: 64, y: 60, category: 'MID' },
      { index: 7, code: 'LM', label: 'ЛП', x: 18, y: 38, category: 'MID' },
      { index: 8, code: 'CAM', label: 'АПЗ', x: 50, y: 35, category: 'MID' },
      { index: 9, code: 'RM', label: 'ПП', x: 82, y: 38, category: 'MID' },
      { index: 10, code: 'ST', label: 'ФРВ', x: 50, y: 16, category: 'ATT' },
    ],
  },
  '5-3-2': {
    key: '5-3-2',
    name: '5-3-2 Оборонительная',
    description: 'Надежная стена с активными латералями и резкими контратаками',
    slots: [
      { index: 0, code: 'GK', label: 'ВРТ', x: 50, y: 91, category: 'GK' },
      { index: 1, code: 'LWB', label: 'ЛКЗ', x: 12, y: 66, category: 'DEF' },
      { index: 2, code: 'CB', label: 'ЛЦЗ', x: 30, y: 76, category: 'DEF' },
      { index: 3, code: 'CB', label: 'ЦЗ', x: 50, y: 78, category: 'DEF' },
      { index: 4, code: 'CB', label: 'ПЦЗ', x: 70, y: 76, category: 'DEF' },
      { index: 5, code: 'RWB', label: 'ПКЗ', x: 88, y: 66, category: 'DEF' },
      { index: 6, code: 'CM', label: 'ЦП', x: 30, y: 48, category: 'MID' },
      { index: 7, code: 'CDM', label: 'ОПЗ', x: 50, y: 54, category: 'MID' },
      { index: 8, code: 'CM', label: 'ЦП', x: 70, y: 48, category: 'MID' },
      { index: 9, code: 'ST', label: 'ФРВ', x: 38, y: 18, category: 'ATT' },
      { index: 10, code: 'ST', label: 'ФРВ', x: 62, y: 18, category: 'ATT' },
    ],
  },
};

export const INITIAL_PLAYERS: Player[] = [
  // 11 Starters (indexes 0 to 10 for 4-3-3)
  {
    id: 'p-01',
    name: 'Тибо',
    surname: 'Куртуа',
    number: 1,
    position: 'GK',
    rating: 90,
    pace: 52,
    shooting: 40,
    passing: 74,
    dribbling: 48,
    defending: 89,
    physical: 84,
    preferredFoot: 'Левая',
    nationality: 'Бельгия',
    flag: '🇧🇪',
    isStarter: true,
    starterIndex: 0,
    avatarColor: 'from-amber-500 to-yellow-600',
  },
  {
    id: 'p-02',
    name: 'Тео',
    surname: 'Эрнандес',
    number: 19,
    position: 'LB',
    rating: 87,
    pace: 93,
    shooting: 72,
    passing: 76,
    dribbling: 82,
    defending: 81,
    physical: 88,
    preferredFoot: 'Левая',
    nationality: 'Франция',
    flag: '🇫🇷',
    isStarter: true,
    starterIndex: 1,
    avatarColor: 'from-blue-600 to-indigo-700',
  },
  {
    id: 'p-03',
    name: 'Вирджил',
    surname: 'ван Дейк',
    number: 4,
    position: 'CB',
    rating: 89,
    pace: 78,
    shooting: 60,
    passing: 72,
    dribbling: 71,
    defending: 91,
    physical: 89,
    preferredFoot: 'Правая',
    nationality: 'Нидерланды',
    flag: '🇳🇱',
    isStarter: true,
    starterIndex: 2,
    isCaptain: true,
    avatarColor: 'from-orange-500 to-amber-600',
  },
  {
    id: 'p-04',
    name: 'Рубен',
    surname: 'Диаш',
    number: 3,
    position: 'CB',
    rating: 88,
    pace: 68,
    shooting: 45,
    passing: 70,
    dribbling: 69,
    defending: 89,
    physical: 87,
    preferredFoot: 'Правая',
    nationality: 'Португалия',
    flag: '🇵🇹',
    isStarter: true,
    starterIndex: 3,
    avatarColor: 'from-red-600 to-rose-700',
  },
  {
    id: 'p-05',
    name: 'Дани',
    surname: 'Карвахаль',
    number: 2,
    position: 'RB',
    rating: 86,
    pace: 82,
    shooting: 55,
    passing: 80,
    dribbling: 81,
    defending: 83,
    physical: 81,
    preferredFoot: 'Правая',
    nationality: 'Испания',
    flag: '🇪🇸',
    isStarter: true,
    starterIndex: 4,
    avatarColor: 'from-amber-600 to-red-600',
  },
  {
    id: 'p-06',
    name: 'Кевин',
    surname: 'Де Брёйне',
    number: 17,
    position: 'CM',
    rating: 91,
    pace: 72,
    shooting: 88,
    passing: 94,
    dribbling: 87,
    defending: 65,
    physical: 76,
    preferredFoot: 'Правая',
    nationality: 'Бельгия',
    flag: '🇧🇪',
    isStarter: true,
    starterIndex: 5,
    avatarColor: 'from-sky-500 to-blue-600',
  },
  {
    id: 'p-07',
    name: 'Родри',
    surname: 'Эрнандес',
    number: 16,
    position: 'CDM',
    rating: 91,
    pace: 66,
    shooting: 80,
    passing: 86,
    dribbling: 82,
    defending: 87,
    physical: 85,
    preferredFoot: 'Правая',
    nationality: 'Испания',
    flag: '🇪🇸',
    isStarter: true,
    starterIndex: 6,
    avatarColor: 'from-cyan-600 to-teal-700',
  },
  {
    id: 'p-08',
    name: 'Джуд',
    surname: 'Беллингем',
    number: 5,
    position: 'CM',
    rating: 90,
    pace: 80,
    shooting: 85,
    passing: 85,
    dribbling: 88,
    defending: 78,
    physical: 84,
    preferredFoot: 'Правая',
    nationality: 'Англия',
    flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿',
    isStarter: true,
    starterIndex: 7,
    avatarColor: 'from-emerald-500 to-teal-600',
  },
  {
    id: 'p-09',
    name: 'Винисиус',
    surname: 'Жуниор',
    number: 7,
    position: 'LW',
    rating: 90,
    pace: 95,
    shooting: 84,
    passing: 81,
    dribbling: 91,
    defending: 32,
    physical: 69,
    preferredFoot: 'Правая',
    nationality: 'Бразилия',
    flag: '🇧🇷',
    isStarter: true,
    starterIndex: 8,
    avatarColor: 'from-yellow-500 to-green-600',
  },
  {
    id: 'p-10',
    name: 'Килиан',
    surname: 'Мбаппе',
    number: 9,
    position: 'ST',
    rating: 91,
    pace: 97,
    shooting: 90,
    passing: 80,
    dribbling: 92,
    defending: 36,
    physical: 78,
    preferredFoot: 'Правая',
    nationality: 'Франция',
    flag: '🇫🇷',
    isStarter: true,
    starterIndex: 9,
    avatarColor: 'from-blue-600 to-purple-700',
  },
  {
    id: 'p-11',
    name: 'Мохамед',
    surname: 'Салах',
    number: 11,
    position: 'RW',
    rating: 89,
    pace: 89,
    shooting: 87,
    passing: 82,
    dribbling: 88,
    defending: 45,
    physical: 76,
    preferredFoot: 'Левая',
    nationality: 'Египет',
    flag: '🇪🇬',
    isStarter: true,
    starterIndex: 10,
    avatarColor: 'from-red-600 to-amber-600',
  },

  // Substitutes & Reserves (Bench)
  {
    id: 'p-12',
    name: 'Эрлинг',
    surname: 'Холанн',
    number: 99,
    position: 'ST',
    rating: 91,
    pace: 89,
    shooting: 93,
    passing: 66,
    dribbling: 81,
    defending: 45,
    physical: 88,
    preferredFoot: 'Левая',
    nationality: 'Норвегия',
    flag: '🇳🇴',
    isStarter: false,
    avatarColor: 'from-sky-400 to-blue-600',
  },
  {
    id: 'p-13',
    name: 'Харри',
    surname: 'Кейн',
    number: 10,
    position: 'ST',
    rating: 90,
    pace: 69,
    shooting: 93,
    passing: 84,
    dribbling: 83,
    defending: 49,
    physical: 83,
    preferredFoot: 'Правая',
    nationality: 'Англия',
    flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿',
    isStarter: false,
    avatarColor: 'from-red-500 to-indigo-600',
  },
  {
    id: 'p-14',
    name: 'Педри',
    surname: 'Гонсалес',
    number: 8,
    position: 'CM',
    rating: 86,
    pace: 79,
    shooting: 69,
    passing: 85,
    dribbling: 89,
    defending: 68,
    physical: 67,
    preferredFoot: 'Правая',
    nationality: 'Испания',
    flag: '🇪🇸',
    isStarter: false,
    avatarColor: 'from-blue-600 to-rose-600',
  },
  {
    id: 'p-15',
    name: 'Вильям',
    surname: 'Салиба',
    number: 12,
    position: 'CB',
    rating: 87,
    pace: 82,
    shooting: 30,
    passing: 71,
    dribbling: 72,
    defending: 88,
    physical: 83,
    preferredFoot: 'Правая',
    nationality: 'Франция',
    flag: '🇫🇷',
    isStarter: false,
    avatarColor: 'from-red-600 to-blue-700',
  },
  {
    id: 'p-16',
    name: 'Алиссон',
    surname: 'Бекер',
    number: 13,
    position: 'GK',
    rating: 89,
    pace: 86,
    shooting: 85,
    passing: 85,
    dribbling: 89,
    defending: 54,
    physical: 90,
    preferredFoot: 'Правая',
    nationality: 'Бразилия',
    flag: '🇧🇷',
    isStarter: false,
    avatarColor: 'from-amber-600 to-green-700',
  },
  {
    id: 'p-17',
    name: 'Федерико',
    surname: 'Вальверде',
    number: 15,
    position: 'CM',
    rating: 88,
    pace: 88,
    shooting: 82,
    passing: 84,
    dribbling: 84,
    defending: 80,
    physical: 84,
    preferredFoot: 'Правая',
    nationality: 'Уругвай',
    flag: '🇺🇾',
    isStarter: false,
    avatarColor: 'from-cyan-500 to-sky-700',
  },
  {
    id: 'p-18',
    name: 'Флориан',
    surname: 'Вирц',
    number: 14,
    position: 'CAM',
    rating: 88,
    pace: 81,
    shooting: 81,
    passing: 86,
    dribbling: 89,
    defending: 52,
    physical: 68,
    preferredFoot: 'Правая',
    nationality: 'Германия',
    flag: '🇩🇪',
    isStarter: false,
    avatarColor: 'from-red-600 to-amber-700',
  },
];

export const DEFAULT_SETTINGS: AppSettings = {
  formation: '4-3-3',
  accent: 'cyan',
  pitchStyle: 'neon-dark',
  soundEnabled: true,
  vibrationEnabled: true,
  showChemistryLines: true,
  teamName: 'Vexton FC',
};

const STORAGE_PLAYERS_KEY = 'vexton_squad_players_v1';
const STORAGE_SETTINGS_KEY = 'vexton_squad_settings_v1';

export function calculateAverageRating(players: Player[]): number {
  const starters = getStarters(players);
  if (starters.length === 0) return 0;
  const sum = starters.reduce((acc, p) => acc + p.rating, 0);
  return Math.round(sum / starters.length);
}

export function getStarters(players: Player[]): Player[] {
  return players
    .filter((p) => p.isStarter)
    .sort((a, b) => (a.starterIndex ?? 0) - (b.starterIndex ?? 0));
}

export function getBenchPlayers(players: Player[]): Player[] {
  return players.filter((p) => !p.isStarter);
}

// Chemistry calculation:
// 1. Position match against formation slot (30 pts max)
// 2. Nationality synergies between adjacent players (35 pts max)
// 3. Rating & Captain presence (35 pts max)
export function calculateChemistry(players: Player[], formationKey: FormationKey): number {
  const starters = getStarters(players);
  if (starters.length === 0) return 0;

  const formation = FORMATIONS[formationKey] || FORMATIONS['4-3-3'];
  let positionScore = 0;
  let nationalitySynergy = 0;

  starters.forEach((player, idx) => {
    const slot = formation.slots[idx];
    if (slot) {
      if (player.position === slot.code) {
        positionScore += 1;
      } else if (POSITION_CATEGORIES[player.position] === slot.category) {
        positionScore += 0.6;
      } else {
        positionScore += 0.2;
      }
    }
  });

  const positionPct = (positionScore / 11) * 40;

  // Synergies: check shared nationalities
  const natCounts: Record<string, number> = {};
  starters.forEach((p) => {
    natCounts[p.nationality] = (natCounts[p.nationality] || 0) + 1;
  });

  Object.values(natCounts).forEach((count) => {
    if (count >= 2) nationalitySynergy += count * 5;
  });
  const natPct = Math.min(35, nationalitySynergy);

  // Captain boost
  const hasCaptain = starters.some((p) => p.isCaptain);
  const captainPct = hasCaptain ? 15 : 5;

  // Starters completion (are all 11 filled?)
  const fullTeamPct = (starters.length / 11) * 10;

  const total = Math.min(100, Math.round(positionPct + natPct + captainPct + fullTeamPct));
  return total;
}

export function calculateSquadStats(players: Player[]) {
  const starters = getStarters(players);
  const count = starters.length || 1;

  const stats = {
    pace: Math.round(starters.reduce((acc, p) => acc + p.pace, 0) / count),
    shooting: Math.round(starters.reduce((acc, p) => acc + p.shooting, 0) / count),
    passing: Math.round(starters.reduce((acc, p) => acc + p.passing, 0) / count),
    dribbling: Math.round(starters.reduce((acc, p) => acc + p.dribbling, 0) / count),
    defending: Math.round(starters.reduce((acc, p) => acc + p.defending, 0) / count),
    physical: Math.round(starters.reduce((acc, p) => acc + p.physical, 0) / count),
  };

  return stats;
}

export function validatePlayer(player: Partial<Player>): {
  valid: boolean;
  errors: Record<string, string>;
} {
  const errors: Record<string, string> = {};

  if (!player.name || player.name.trim().length < 2) {
    errors.name = 'Имя должно содержать минимум 2 символа';
  }
  if (!player.surname || player.surname.trim().length < 2) {
    errors.surname = 'Фамилия должна содержать минимум 2 символа';
  }
  if (player.number === undefined || player.number < 1 || player.number > 99) {
    errors.number = 'Номер игрока должен быть от 1 до 99';
  }
  if (player.rating === undefined || player.rating < 1 || player.rating > 99) {
    errors.rating = 'Рейтинг должен быть от 1 до 99';
  }

  const statFields: (keyof PlayerStats)[] = [
    'pace',
    'shooting',
    'passing',
    'dribbling',
    'defending',
    'physical',
  ];
  for (const field of statFields) {
    const val = player[field];
    if (val === undefined || val < 10 || val > 99) {
      errors[field as string] = `Характеристика ${String(field).toUpperCase()} должна быть от 10 до 99`;
    }
  }

  return {
    valid: Object.keys(errors).length === 0,
    errors,
  };
}

export function swapPlayers(players: Player[], id1: string, id2: string): Player[] {
  const p1 = players.find((p) => p.id === id1);
  const p2 = players.find((p) => p.id === id2);
  if (!p1 || !p2) return players;

  return players.map((p) => {
    if (p.id === id1) {
      return {
        ...p,
        isStarter: p2.isStarter,
        starterIndex: p2.starterIndex,
      };
    }
    if (p.id === id2) {
      return {
        ...p,
        isStarter: p1.isStarter,
        starterIndex: p1.starterIndex,
      };
    }
    return p;
  });
}

export function loadSquadFromStorage(): Player[] {
  if (typeof window === 'undefined') return INITIAL_PLAYERS;
  try {
    const raw = localStorage.getItem(STORAGE_PLAYERS_KEY);
    if (!raw) {
      localStorage.setItem(STORAGE_PLAYERS_KEY, JSON.stringify(INITIAL_PLAYERS));
      return INITIAL_PLAYERS;
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) {
      return parsed;
    }
    return INITIAL_PLAYERS;
  } catch {
    return INITIAL_PLAYERS;
  }
}

export function saveSquadToStorage(players: Player[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_PLAYERS_KEY, JSON.stringify(players));
  } catch (err) {
    console.error('Failed to save squad:', err);
  }
}

export function loadSettingsFromStorage(): AppSettings {
  if (typeof window === 'undefined') return DEFAULT_SETTINGS;
  try {
    const raw = localStorage.getItem(STORAGE_SETTINGS_KEY);
    if (!raw) {
      localStorage.setItem(STORAGE_SETTINGS_KEY, JSON.stringify(DEFAULT_SETTINGS));
      return DEFAULT_SETTINGS;
    }
    return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettingsToStorage(settings: AppSettings): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_SETTINGS_KEY, JSON.stringify(settings));
  } catch (err) {
    console.error('Failed to save settings:', err);
  }
}

export function resetSquadToDefault(): Player[] {
  if (typeof window !== 'undefined') {
    localStorage.setItem(STORAGE_PLAYERS_KEY, JSON.stringify(INITIAL_PLAYERS));
  }
  return [...INITIAL_PLAYERS];
}

export const COMMON_FLAGS = [
  { name: 'Россия', flag: '🇷🇺' },
  { name: 'Франция', flag: '🇫🇷' },
  { name: 'Бразилия', flag: '🇧🇷' },
  { name: 'Аргентина', flag: '🇦🇷' },
  { name: 'Испания', flag: '🇪🇸' },
  { name: 'Германия', flag: '🇩🇪' },
  { name: 'Англия', flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿' },
  { name: 'Португалия', flag: '🇵🇹' },
  { name: 'Италия', flag: '🇮🇹' },
  { name: 'Нидерланды', flag: '🇳🇱' },
  { name: 'Бельгия', flag: '🇧🇪' },
  { name: 'Норвегия', flag: '🇳🇴' },
  { name: 'Уругвай', flag: '🇺🇾' },
  { name: 'Хорватия', flag: '🇭🇷' },
  { name: 'Узбекистан', flag: '🇺🇿' },
  { name: 'Казахстан', flag: '🇰🇿' },
];
