# VextonApps — Футбольный менеджер (Сборка Offline Android APK)

Полное руководство по сборке автономного мобильного приложения Android (APK) с помощью **Capacitor**.

---

## 📱 Архитектура офлайн-работы приложения

Приложение спроектировано для **100% автономной работы без интернета**:
- **Никаких внешних API или серверов**: нет запросов `fetch`, `axios` или внешних бэкендов.
- **Локальное хранилище данных**:
  - `localStorage`: составы, расстановки, тактики, 28 характеристик PES, настройки неонового стиля, параметры звука и вибрации.
  - `IndexedDB` (`VextonApps_DB` / `player_photos`): фотографии футболистов из галереи Android (JPG, PNG, WEBP) хранятся в бинарном/base64 виде в защищённой локальной базе устройства без ограничений квоты 5MB.
- **Синтезатор звука (Web Audio API)**: все звуковые эффекты (свисток, удары по мячу, неоновые клики, успех) генерируются встроенным программным осциллятором браузера без скачивания внешних MP3-файлов.
- **Шрифты и стили**: при отсутствии подключения к сети Tailwind v4 и резервные системные шрифты (`system-ui`, `-apple-system`, `Impact`, `Trebuchet MS`, `monospace`) сохраняют фирменный PES/неоновый кибер-стиль.

---

## 🛠 Требования для сборки на компьютере

1. **Node.js** (версия 18+ или 20+) и **npm**.
2. **Java Development Kit (JDK)**: версия 17 или 21.
3. **Android Studio** (Ladybug, Koala или новее) с установленными:
   - Android SDK Platform (API 34 / 35).
   - Android SDK Build-Tools.
   - Android SDK Command-line Tools.

---

## 🚀 Пошаговая инструкция по сборке APK

### Шаг 1. Установка зависимостей проекта
В терминале корня проекта выполните:
```bash
npm install
```

### Шаг 2. Сборка веб-части и синхронизация с Android
Команда компилирует React/TypeScript в директорию `dist/` и копирует все ассеты в нативную платформу Android:
```bash
npm run cap:build
```
*(Или раздельно: `npm run build && npx cap sync android`)*

---

### Шаг 3. Сборка готового APK-файла

#### Вариант A. Через консоль / командную строку (Самый быстрый способ)

1. Перейдите в папку `android`:
   ```bash
   cd android
   ```
2. Запустите сборку отладочного APK:
   - **Linux / macOS**:
     ```bash
     ./gradlew assembleDebug
     ```
   - **Windows (PowerShell / CMD)**:
     ```cmd
     gradlew.bat assembleDebug
     ```
3. Готовый APK-файл будет находиться по пути:
   ```
   android/app/build/outputs/apk/debug/app-debug.apk
   ```
4. Установите его на телефон Android:
   ```bash
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```
   (или просто скопируйте файл `app-debug.apk` на телефон и откройте в проводнике).

---

#### Вариант B. Через интерфейс Android Studio

1. Откройте проект Android в Android Studio:
   ```bash
   npx cap open android
   ```
   (или запустите Android Studio и выберите папку `android`).
2. Дождитесь окончания синхронизации Gradle (в правом нижнем углу появится надпись *Gradle sync finished*).
3. В верхнем меню выберите:
   **Build** → **Build Bundle(s) / APK(s)** → **Build APK(s)**.
4. После окончания сборки в появившемся окне в правом нижнем углу нажмите **locate** — вы увидите собранный `app-debug.apk`.
5. Для сборки релизного подписанного APK (для публикации или постоянной установки):
   **Build** → **Generate Signed Bundle / APK** → выберите **APK** → укажите ваш Keystore.

---

## 📂 Структура проекта

```
/
├── capacitor.config.ts        # Конфигурация Capacitor для Android
├── package.json               # Скрипты и зависимости (React 19, Capacitor 8, Tailwind v4)
├── vite.config.ts             # Конфиг сборки с относительными путями (base: './')
├── index.html                 # HTML с viewport-fit=cover под вырезы и жесты Android
├── android/                   # Полный нативный проект Android (Gradle, Manifest, Java/Kotlin)
│   ├── app/
│   │   ├── src/main/
│   │   │   ├── AndroidManifest.xml   # Настройки прав и активности Android
│   │   │   ├── assets/public/        # Скомпилированный оффлайн веб-код приложения
│   │   │   └── res/                  # Иконки, заставка, стили и strings.xml
│   │   └── build.gradle
│   ├── build.gradle
│   └── gradlew
└── src/                       # Исходный код приложения
    ├── main.tsx               # Точка входа React
    ├── App.tsx                # Корневой компонент (управление экранами, IndexedDB, localStorage)
    ├── index.css              # Стили Tailwind v4, неоновые эффекты и текстуры газона
    ├── components/
    │   ├── SplashScreen.tsx       # 3-секундная заставка VextonApps
    │   ├── AnimatedLoader.tsx     # Анимированный неоновый загрузчик
    │   ├── MainMenu.tsx           # Главное меню с 7 кнопками
    │   ├── VerticalPitch.tsx      # Вертикальное футбольное поле (11 позиций, тактики, замены)
    │   ├── EditorView.tsx         # Экран «Редактирование» (список, фильтры, быстрые действия)
    │   ├── PlayerEditorModal.tsx  # Форма создания/редактирования: фото из галереи, 28 статов PES
    │   ├── PlayerCardModal.tsx    # Карточка футболиста в стиле PES (цвета 80-99, 60-79, 1-59)
    │   ├── DataView.tsx           # Экран «Данные» (анализ состава, экспорт/импорт JSON)
    │   ├── SettingsView.tsx       # Экран «Настройки» (схемы 4-3-3, 4-4-2, неоновые темы)
    │   ├── SupportView.tsx        # Экран «Поддержка» (FAQ, база знаний)
    │   ├── ReportUserModal.tsx    # Экран «Сообщить о пользователе»
    │   ├── ExitDialog.tsx         # Диалог выхода и перезапуска
    │   ├── HeaderNav.tsx          # Верхняя строка состояния в стиле Android
    │   └── BottomNavBar.tsx       # Нижняя панель быстрого перехода
    ├── types/
    │   └── football.ts        # TypeScript интерфейсы (Player, PesStats, Position, Tactics)
    └── utils/
        ├── audio.ts           # Оффлайн аудио-синтезатор (Web Audio API)
        ├── photoStorage.ts    # Хранилище фотографий игроков в IndexedDB
        └── squadUtils.ts      # Тактический движок, расчет сыгранности, градация цветов PES
```

---

## 🔒 Разрешения Android (`AndroidManifest.xml`)

Приложение требует минимальные права:
- Доступ к галерее (`READ_MEDIA_IMAGES` / выбор файлов через стандартный Android Photo Picker).
- Приложение работает в авиарежиме (без сети Wi-Fi и мобильных данных).
