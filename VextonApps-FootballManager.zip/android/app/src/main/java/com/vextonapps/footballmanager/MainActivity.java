package com.vextonapps.footballmanager;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
